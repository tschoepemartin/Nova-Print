# BauDetail 0.9.54 – Grundstückseditor
- Eigenes Grundstücksmenü beim Anlegen und über den Inspector.
- Kantenzahl 3–12, Standard 4.
- Geometrische Vorschau mit Kanten- und Winkelbeschriftung.
- Eingabefelder für Kantenlängen (m) und Innenwinkel (°), individuelle Fixierungen.
- Numerische Anpassung mit Prüfung der Fixierungen; bei widersprüchlichen Vorgaben kein Speichern.
- Fläche und Umfang; Lock-Zustand als Objektparameter gespeichert.
- Bestehende Snap-Logik und PDF-Export unverändert.

Hinweis: Lokaler Gradle-Build nicht möglich, weil die Gradle-Distribution offline nicht verfügbar ist. GitHub Actions muss die Kompilierung bestätigen.
