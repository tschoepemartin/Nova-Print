# BauDetail 0.9.37

- Kantenverschiebung in „Bearbeiten“ ausschließlich senkrecht zur Kante: horizontal gezeichnete Kanten nur vertikal, vertikale Kanten nur horizontal. Unabhängig von Snap und Ortho.
- Eine einzige Live-Maßlinie vom Mittelpunkt der bewegten Kante bis zum nächsten tatsächlichen gegenüberliegenden Polygonsegment entlang der Normalen. Kein Bounding-Box-Maß.
- Zusätzliche Δ-/Tiefenhinweise und automatische Live-Breiten-/Längenbeschriftungen im Konturmodus entfernt.
- Eckpunktgriffe verkleinert. Einzelne Eckpunkte weiterhin frei verschiebbar.
- Nicht auf Android kompiliert oder am Gerät getestet.
