# BauDetail 0.9.67

Inspector-Dialoglogik in vier separate Composable-Funktionen zerlegt, um die JVM-Methodengrößengrenze nachhaltig zu entschärfen. Bestehende Dialogzweige und deren Reihenfolge unverändert übernommen.

Build nicht lokal ausgeführt; GitHub Actions muss Kompilierung bestätigen.
