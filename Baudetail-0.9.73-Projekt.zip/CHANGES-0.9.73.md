# BauDetail 0.9.73

- Schräg verformte Bordsteinreihen: echte Außenkontur für Auswahlrahmen, Bounds und Snap-Endpunkte/-Kanten.
- Pflasterflächen: Polygonkontur statt ursprünglichem Rechteck für Hit-Test und Verschiebe-Snapping.
- Snapping und Auswahl referenzieren die sichtbare Geometrie.

Nicht lokal kompiliert oder auf Android getestet.
