package de.baudetail.core

import de.baudetail.geometry.Vec
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import org.junit.Test
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue

class Cad033Test {
 @Test fun stairSlopeIncreasesTotalHeightPerStep() {
  val stair=Entity(kind="assembly",points=listOf(Vec(100.0,200.0)),params=buildJsonObject{
   put("assemblyType","stair");put("stepCount",8);put("riseMm",150.0);put("goingMm",350.0);put("depthMm",400.0);put("slope",2.0)
  })
  assertEquals(7.0,stairSlopeDrop(stair),.001)
  assertEquals(157.0,stairEffectiveRise(stair),.001)
  assertEquals(1256.0,stairTotalHeight(stair),.001)
  val pts=stairLocalPoints(stair,"section")
  assertEquals(-1256.0,pts.last().y,.001)
  // Ende jedes Auftritts ist zugleich der Start der naechsten Stufe.
  for(i in 0 until stairCount(stair)-1) assertEquals(pts[i*3+2],pts[(i+1)*3])
 }

 @Test fun fixedTotalHeightStaysFixedWithSlope() {
  val stair=Entity(kind="assembly",params=buildJsonObject{
   put("assemblyType","stair");put("stepCount",8);put("heightMode","total");put("totalHeightMm",1200.0);put("goingMm",350.0);put("depthMm",400.0);put("slope",2.0)
  })
  assertEquals(143.0,stairRise(stair),.001)
  assertEquals(150.0,stairEffectiveRise(stair),.001)
  assertEquals(1200.0,stairTotalHeight(stair),.001)
 }

 @Test fun smartComponentRotationKeepsAnchor() {
  val e=Entity(kind="component",points=listOf(Vec(500.0,700.0)),params=buildJsonObject{
   put("componentFamily","curb");put("widthMm",80.0);put("heightMm",200.0)
  })
  val rotated=transform(e,angle=90.0)
  assertEquals(Vec(500.0,700.0),rotated.points.first())
  assertEquals(90.0,rotated.rotation,.001)
 }

 @Test fun retainingWallSectionIsRealLShape() {
  val e=Entity(kind="component",params=buildJsonObject{
   put("componentFamily","retaining_wall");put("wallHeightMm",800.0);put("footDepthMm",400.0);put("wallThicknessMm",70.0);put("footThicknessMm",100.0);put("footSide","right")
  })
  val pts=retainingWallSection(e)
  assertEquals(6,pts.size)
  assertTrue(pts.contains(Vec(70.0,700.0)))
  assertTrue(pts.contains(Vec(400.0,700.0)))
  assertTrue(pts.contains(Vec(400.0,800.0)))
 }
}
