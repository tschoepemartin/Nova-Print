package de.baudetail.core

import de.baudetail.geometry.Vec
import org.junit.Assert.*
import org.junit.Test

class BuildUpJoinLevel0839Test {
 @Test fun snappedSurfaceReconcilesActualHeightsWithoutChangingSlopeOrGeometry() {
  val target=Entity(kind="stack",points=listOf(Vec(0.0,0.0)))
   .withNum("buildUpSectionLengthMm",1000.0).withNum("buildUpRealLengthMm",6500.0)
   .withStr("buildUpRealLengthEnabled","true")
   .withNum("buildUpSlopePct",1.65).withStr("buildUpSlopeFixedSide","right")
  val targetJoin=buildUpSurfaceEdge(target).first
  val slab=Entity(kind="stack",points=listOf(Vec(-1000.0,targetJoin.y)))
   .withNum("buildUpSectionLengthMm",1000.0).withNum("buildUpLevelOffsetMm",-90.0)
  val aligned=buildUpAlignLevelAtJoin(slab,target,1,0,0.0)
  assertEquals(buildUpSurfaceLevelMm(target,0,0.0),buildUpSurfaceLevelMm(aligned,1,0.0),1e-7)
  assertEquals(buildUpSurfaceEdge(slab),buildUpSurfaceEdge(aligned))
  assertEquals(buildUpSlopePercent(slab),buildUpSlopePercent(aligned),1e-7)
 }
}
