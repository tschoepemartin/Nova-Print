package de.baudetail.core

import de.baudetail.geometry.Vec
import org.junit.Assert.*
import org.junit.Test

class ElevationSharedSurface0837Test {
 @Test fun sharedEndpointPrefersRealLengthCorrectedSurfaceRegardlessOfEntityOrder() {
  val short=Entity(kind="stack",points=listOf(Vec(0.0,0.0)))
   .withNum("buildUpSectionLengthMm",1000.0)
  val long=Entity(kind="stack",points=listOf(Vec(1000.0,0.0)))
   .withNum("buildUpSectionLengthMm",1000.0).withNum("buildUpRealLengthMm",6500.0)
   .withStr("buildUpRealLengthEnabled","true")
   .withNum("buildUpSlopePct",1.65).withStr("buildUpSlopeFixedSide","right")
  // Both surfaces are near the same graphic joint. A height marker must
  // attach to the section with the real-length height correction.
  for (entities in listOf(listOf(short,long),listOf(long,short))) {
   val drawing=Drawing(entities=entities).withViewMode("section")
   val joint=buildUpSurfaceEdge(long).first
   val snap=elevationSurfaceSnap(joint,drawing,25.0)
   assertNotNull(snap)
   assertEquals(long.id,snap!!.anchor?.entityId)
  }
 }
}
