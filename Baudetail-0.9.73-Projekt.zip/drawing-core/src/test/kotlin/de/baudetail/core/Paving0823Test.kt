package de.baudetail.core

import org.junit.Test
import org.junit.Assert.assertTrue
import org.junit.Assert.assertNotEquals

class Paving0823Test {
 @Test fun extendedMaterialsHaveDifferentVisuals() {
  assertTrue(pavingMaterialChoices.containsAll(listOf("Feinsteinzeug","Dränpflaster","Großkopfsteinpflaster","Kleinsteinpflaster","Mosaikpflaster")))
  assertNotEquals(pavingVisualColor("Jurakalk"),pavingVisualColor("Betonpflaster"))
  assertNotEquals(pavingStoneSize("Mosaikpflaster"),pavingStoneSize("Feinsteinzeug"))
 }
}
