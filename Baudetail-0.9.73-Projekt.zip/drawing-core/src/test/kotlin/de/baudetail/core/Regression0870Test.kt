package de.baudetail.core

import de.baudetail.geometry.*
import org.junit.Assert.*
import org.junit.Test

class Regression0870Test {
 private fun stair()=Entity(kind="assembly",points=listOf(Vec(100.0,200.0)))
  .withStr("assemblyType","stair").withNum("stepCount",4.0)
  .withNum("goingMm",350.0).withNum("depthMm",350.0)
  .withNum("widthMm",1000.0).withNum("riseMm",145.0).withNum("slope",2.0)

 @Test fun eachTreadProvidesSnappableConstructionEdges() {
  val e=stair();val d=Drawing(entities=listOf(e)).withViewMode("top")
  assertEquals(4,stairPlanTreads(e).size)
  val edges=smartSnapSegments(e,d)
  assertEquals(16,edges.size)
  for(i in 1..3){
   val point=assemblyPoint(e,Vec(i*350.0,500.0),"top")
   assertTrue(edges.any{(a,b)->closestOnSegment(point,a,b).distance(point)<0.001})
   assertEquals(point,planHeightEdgeSnap(point+Vec(2.0,0.0),d,10.0).point)
  }
 }
 @Test fun treadHeightIsDiscontinuousAtRiserAndVariesAlongTread() {
  val e=stair()
  val a=assemblyPoint(e,Vec(10.0,500.0),"top")
  val b=assemblyPoint(e,Vec(340.0,500.0),"top")
  val next=assemblyPoint(e,Vec(360.0,500.0),"top")
  assertEquals(-6.6,stairPlanRelativeZMm(e,b)-stairPlanRelativeZMm(e,a),0.001)
  assertTrue(stairPlanRelativeZMm(e,next)>stairPlanRelativeZMm(e,b))
 }
 @Test fun markerCoordinatesAreNotReplacedByHeightReference() {
  val e=stair();val d=Drawing(entities=listOf(e)).withViewMode("top")
  val point=assemblyPoint(e,Vec(400.0,500.0),"top")
  val marker=Entity(kind="plan-height",points=listOf(point),anchors=listOf(planElevationAnchor(point,d)!!))
  assertEquals(point,resolvedPoints(marker,d).first())
  assertEquals(point,planElevationPoint(marker,d))
 }
}
