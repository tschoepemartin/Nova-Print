package de.baudetail.core

import de.baudetail.geometry.*
import kotlin.math.*

/** True only for physically touching plan footprints with a shared boundary segment.
 * A corner-only touch is not sufficient for a continuous laying bond.
 * Coordinates are never rounded or changed by this predicate. */
fun adjacentPavingFootprints(a:Entity,b:Entity,toleranceMm:Double=0.5):Boolean {
 if(a.id==b.id || a.kind!="stack" || b.kind!="stack")return false
 fun outline(e:Entity):List<Vec> {
  val w=e.num("planGraphicWidthMm",e.num("widthMm",1500.0))
  val h=e.num("topDepthMm",1000.0)
  if(w<=0 || h<=0)return emptyList()
  val origin=buildUpPlanOrigin(e)
  val angle=buildUpPlanAngle(e)
  return rectangle(Vec(),Vec(w,h)).map{origin+it.rotate(angle)}
 }
 val pa=outline(a);val pb=outline(b)
 if(pa.size!=4 || pb.size!=4)return false
 for(i in pa.indices)for(j in pb.indices){
  val p=pa[i];val q=pa[(i+1)%pa.size]
  val r=pb[j];val s=pb[(j+1)%pb.size]
  val u=q-p;val v=s-r
  val len=u.length();val lenV=v.length()
  if(len<1e-6 || lenV<1e-6)continue
  if(abs(u.x*v.y-u.y*v.x)>toleranceMm*max(len,lenV))continue
  if(abs(u.x*(r.y-p.y)-u.y*(r.x-p.x))/len>toleranceMm)continue
  if(abs(u.x*(s.y-p.y)-u.y*(s.x-p.x))/len>toleranceMm)continue
  val t0=((r.x-p.x)*u.x+(r.y-p.y)*u.y)/len
  val t1=((s.x-p.x)*u.x+(s.y-p.y)*u.y)/len
  if(min(len,max(t0,t1))-max(0.0,min(t0,t1))>toleranceMm)return true
 }
 return false
}
