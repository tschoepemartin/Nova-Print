# BauDetail 0.9.25 – Snapping: Priorisierung korrigiert

- Bei mehr als 250 nahegelegenen Kanten werden für Schnittpunktprüfungen jetzt die **räumlich nächstgelegenen** Kanten berücksichtigt, nicht mehr die ersten 250 in Objekt-Reihenfolge.
- Schnittpunkte und Endpunkte erhalten im aktiven Fangbereich Vorrang vor einfachen Kantenprojektionen; explizite Objektpriorität bleibt als weiteres Kriterium erhalten.
- Bestehende Objektgeometrien, Flächenvereinigung, Verlegeverbandsreferenzen und Herstellerbibliotheken bleiben unverändert.

## Noch offen
- Allgemeine Positionssprünge bei Maßänderungen sind nicht für sämtliche Objektarten korrigiert.
- Vollständige geometrische Kanten-/Schnittpunkt-Snap-Überarbeitung sowie die Prüfung der Pflaster-Referenzen auf echte Nachbarschaft stehen aus.
- Android-Build und Geräteprüfung sind noch nicht durchgeführt.
