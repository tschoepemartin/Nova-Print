# BauDetail 0.9.48 – Grundstück

- Neues Werkzeug Grundstück unmittelbar unter Gebäude. Zeichnet zunächst ein orthogonales Rechteck ohne Füllung.
- Geschlossener Polygonumriss mit vorhandener universeller Snap- und Bearbeiten-Logik für Kanten und Eckpunkte.
- Grundstück-Menü zeigt tatsächliche Fläche und Umfang und ermöglicht numerische Eingabe der Kantenlängen in Metern.
- Die Eingabe einer Kantenlänge verschiebt einen Endpunkt in bestehender Kantenrichtung; das Polygon bleibt geschlossen. Die Maße anderer Kanten können sich dadurch ändern. Eine vollständig vermessungstechnisch überbestimmte Konstruktion ist nicht implementiert.
- Keine bewussten Änderungen am Performance-/Snapping-Code der Version 0.9.47.

Build und Android-Praxistest stehen noch aus.
