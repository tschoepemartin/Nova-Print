# BauDetail 0.9.42 – Entwicklungsstand
- Auswahl der zuletzt bearbeiteten Kante bleibt beim Wechsel des Zeichenwerkzeugs im Canvas-Zustand erhalten, solange das Objekt ausgewählt bleibt.
- Feststehende, jederzeit sichtbare Kantenmaßanzeige mit Schaltfläche „Ändern“ am unteren Rand des Zeichenbereichs; funktioniert auch bei außerhalb des Bildschirms liegenden Kantenmitten.
- Beim Verschieben einzelner Objekte werden unabhängige X- und Y-Fangkorrekturen aus Objektpunkten und Kantenmitten kombiniert. Die bestehende Speziallogik für Kanäle und Baugruppen bleibt bestehen.
- Zielpunkte und das gefilterte Snap-Zeichnungsmodell werden pro Dokument-/Auswahländerung zwischengespeichert.

## Noch zu prüfen
- Android-Compile und Laufzeittest sind nicht durchgeführt.
- X/Y-Fang-Hysterese und vollständige Linien-zu-Linien-Schnittpunktsuche sind noch nicht implementiert.
- Kein universeller Snap aller Spezialobjekte, keine garantierte Verbesserung für große Pläne.

## Fortsetzung: X/Y-Fang
- Unabhängige X- und Y-Fangbindungen beim Ziehen.
- Fang-Hysterese: eingerastete Achse bleibt bis zum 1,8-fachen Fangradius aktiv.
- Auch einzelne Achsen können einrasten, ohne die andere Richtung zu blockieren.
- Fangbindungen werden zu Beginn und Ende eines Drags zurückgesetzt.
- Android-Build und Laufzeittest sind noch nicht durchgeführt.
