# BauDetail 0.9.27 – Pflanzdarstellung (Entwicklungsstand)

- Großbaum-Kronen als organisch gerundete Vektorform mit Laubdetails und Ästen statt Kreuzen/überlagerten Kreisen.
- Bei Wuchsform Strauch/Heister andere Kronendarstellung ohne Baumstamm.
- Eigenes Pflanzung-anpassen-Menü mit Kronendurchmesser, Name, Wuchsform, Stammumfang, Verpflanzung, Pflanzenhöhe und Stammzahl.
- Bruns-Auswahl für einzelne Baumobjekte über den bereits vorhandenen externen Katalog.
- Größenänderung verändert nur den Kronenparameter, nicht die Objektposition.

Nicht erledigt:
- Geometrische Bereinigung der künstlichen Pflaster-Schnittkante.
- Strauchobjekte außerhalb des Typs 'tree' vollständig umgestellt.
- Keine lokale Android-Kompilierung oder Gerätetests.
