# BauDetail 0.9.60 – Hauptthread-Diagnose

Auf Grundlage von 0.9.59. Zusätzliche Messpunkte ohne Eingriff in Geometrie, Snapping oder PDF:

- `input_queue_delay`: Verzögerung zwischen Android-Touchzeitstempel und Verarbeitung im Zeichenbereich.
- `scene_build`: tatsächliche CPU-Zeit zum Erzeugen der Zeichenprimitive bei einer neuen Zeichnungsversion.
- `canvas_composition`: Anzahl der Compose-Neuzusammensetzungen des Zeichenbereichs.
- Bestehende Messpunkte `canvas_draw`, `canvas_interval`, `render_*` und `touch_move` bleiben erhalten.
- Messungen nur bei aktivierter Performance-Diagnose, sonst kein zusätzlicher Trace-Aufwand.

**Keine nachgewiesene Beschleunigung:** Diese Version grenzt den mehrsekündigen Stillstand genauer ein. Ein Android-Build wurde lokal nicht durchgeführt.
