# BauDetail 0.9.31 – Pflasterflächen zusammenführen (Entwicklungsstand)

- Werkzeug Zusammenführen unterstützt nun auch mehrere kompatible Belagsaufbauten (stack) und bereits vereinigte Pflasterpolygone.
- Vor der Vereinigung werden die tatsächlichen gedrehten Draufsicht-Rechtecke in Modellkoordinaten berechnet.
- Exakte geometrische Polygonvereinigung mit der vorhandenen unionAreaContours-Logik; bei getrennten Flächen, Löchern oder nicht einfacher Außenkontur kein Merge.
- Ergebnis ist ein editierbares Polygonflächenobjekt (area) mit mergedPaving=true, originalen Schichtdaten und Pflasterparametern.
- Verlegemuster, Steintexturen und Randfuge werden auf dem gesamten vereinigten Polygon berechnet. Ursprüngliche innere Schnittkanten entfallen.
- Der Verband erhält den globalen Ursprung und Winkel der ersten Fläche, sodass keine Neuausrichtung auf das Bounding-Rechteck stattfindet.
- Die unabhängige Verknüpfung benachbarter Pflasterflächen bleibt für nicht vereinigte Objekte bestehen.

Einschränkungen:
- Die vereinigte Fläche ist ein Draufsicht-Polygon, kein vollwertiger parametrischer Schnitt-Belagsaufbau. Schnittdarstellung und Stack-spezifische Einstellungsdialoge müssen für mergedPaving noch ergänzt werden.
- Nicht lokal kompiliert (Gradle-Distribution nicht erreichbar), nicht auf Android getestet.
