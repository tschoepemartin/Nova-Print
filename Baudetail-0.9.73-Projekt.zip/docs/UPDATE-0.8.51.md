# BauDetail 0.8.51

- Schnitt: Rasen-Vorschau beim Verschieben aktualisiert die eigenen grassSectionDxMm/DyMm-Parameter analog zur finalen Verschiebung; die Plan-Geometrie bleibt unangetastet.
- Externe Texturen: Kräuterrasen bleibt als sichtbarer Typ bestehen, Dateipfad verwendet Kraeuterrasen-1.webp bis Kraeuterrasen-4.webp.
- Die übrigen 28 Draufsicht-Texturpfade und der gesamte Draufsicht-Renderer bleiben unverändert.
