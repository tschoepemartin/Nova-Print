# BauDetail 0.8.80 – maßhaltige Pflaster-Außenfugen

- Pflasterkontur bleibt das geometrische Rechteck aus `planGraphicWidthMm` und `topDepthMm`.
- Die Grundfüllung zeichnet keinen zentrierten Außenstrich mehr.
- Die Außenfuge wird durch vier geschlossene, innerhalb der Kontur liegende Flächen gebildet. Jede Randfläche ist eine halbe Fugenbreite stark. Ecken sind rechtwinklig, ohne Round-Cap-Überstand.
- Innenfugen-Strichbreite ist auf die eingestellte Fugenbreite begrenzt und wird nicht unbeschränkt mit dem Planmaßstab vergrößert.
- Beim Kanten-Snapping muss eine tatsächliche positive gemeinsame Kantenlänge vorhanden sein. Punktkontakte sind keine Kantenanschlüsse.
- Vorhandene SAT-Überlappungsprüfung und gemeinsamer Rasterursprung aus 0.8.79 bleiben erhalten.

Nicht lokal kompiliert; GitHub Actions führt den Build durch. Bei verschiedenen Objektwinkeln, Materialien und Sonderverbänden ist eine Sichtprüfung weiterhin erforderlich.
