package de.baudetail.ui.panels

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import de.baudetail.core.Entity
import de.baudetail.geometry.*
import kotlin.math.*

private val edgeNames = ('a'..'l').map{it.toString()}
private val angleNames = listOf("α","β","γ","δ","ε","ζ","η","θ","ι","κ","λ","μ")
private fun angleAt(p:List<Vec>,i:Int):Double {
 val a=p[(i+p.size-1)%p.size]-p[i];val b=p[(i+1)%p.size]-p[i]
 return Math.toDegrees(acos(((a.x*b.x+a.y*b.y)/(a.length()*b.length()).coerceAtLeast(1e-9)).coerceIn(-1.0,1.0)))
}
private fun regularAround(p:List<Vec>,n:Int):List<Vec>{
 val center=Bounds.of(p).center;val r=(p.map{it.distance(center)}.average()).coerceAtLeast(1000.0)
 val start=atan2(p.first().y-center.y,p.first().x-center.x)
 val orientation=if(p.indices.sumOf{i->val a=p[i];val b=p[(i+1)%p.size];a.x*b.y-b.x*a.y}>=0)1 else -1
 return List(n){i->center+Vec(r*cos(start+orientation*i*2*PI/n),r*sin(start+orientation*i*2*PI/n))}
}
/** Constrained geometric adjustment. Unlocked dimensions are free, locked ones are verified before save. */
private fun solveProperty(initial:List<Vec>, lengths:List<Double>, angles:List<Double>, fixedL:List<Boolean>,fixedA:List<Boolean>):List<Vec>? {
 val n=initial.size
 if(n<3||lengths.any{it<=0.0||!it.isFinite()}||angles.any{it<=0.0||it>=180.0||!it.isFinite()})return null
 if(fixedA.all{it} && abs(angles.sum()-(n-2)*180.0)>0.02)return null
 // Exact construction for a quadrilateral with two adjacent right angles.
 // This is a common survey case: three locked edges and the remaining edge/angles free.
 // The numerical solver can get trapped in a near-degenerate local minimum here.
 if(n==4 && fixedA[0] && fixedA[1] &&
    abs(angles[0]-90.0)<0.001 && abs(angles[1]-90.0)<0.001 &&
    fixedL[0] && fixedL[1] && fixedL[3] && !fixedL[2] &&
    !fixedA[2] && !fixedA[3]) {
  val a=lengths[0];val b=lengths[1];val d=lengths[3]
  val direction=(initial[1]-initial[0]);val directionLength=direction.length()
  val u=if(directionLength>1e-6)direction*(1.0/directionLength) else Vec(1.0,0.0)
  val clockwise=initial.indices.sumOf{i->val p=initial[i];val q=initial[(i+1)%4];p.x*q.y-q.x*p.y}>=0.0
  val normal=if(clockwise)Vec(-u.y,u.x) else Vec(u.y,-u.x)
  val p0=initial[0];val p1=p0+u*a
  val candidate=listOf(p0,p1,p1+normal*b,p0+normal*d)
  if(area(candidate)>1.0 && candidate.indices.all{i->
    (!fixedL[i] || abs(candidate[i].distance(candidate[(i+1)%4])-lengths[i])<2.0) &&
    (!fixedA[i] || abs(angleAt(candidate,i)-angles[i])<0.05)
   })return candidate
 }
 val anchor=initial.first();val scale=(length(initial,true)/n).coerceAtLeast(100.0)
 var x=DoubleArray(2*n){i->if(i%2==0)(initial[i/2].x-anchor.x)/scale else (initial[i/2].y-anchor.y)/scale}
 fun pts(v:DoubleArray)=List(n){i->Vec(v[2*i]*scale+anchor.x,v[2*i+1]*scale+anchor.y)}
 fun residual(v:DoubleArray):DoubleArray{
  val p=pts(v);val out=ArrayList<Double>()
  for(i in 0 until n){if(fixedL[i])out.add((p[i].distance(p[(i+1)%n])-lengths[i])/scale)}
  for(i in 0 until n){if(fixedA[i])out.add((angleAt(p,i)-angles[i])/90.0)}
  // Stabilize the solution to the current shape without overriding locked dimensions.
  for(i in 1 until n){out.add((v[2*i]-(initial[i].x-anchor.x)/scale)*0.0001);out.add((v[2*i+1]-(initial[i].y-anchor.y)/scale)*0.0001)}
  out.add(v[0]*0.01);out.add(v[1]*0.01)
  return out.toDoubleArray()
 }
 if(!fixedL.any{it}&&!fixedA.any{it})return initial
 // Damped least-squares numerical gradient, small system (up to 12 vertices).
 repeat(150){
  val base=residual(x);val cost=base.sumOf{it*it};if(cost<1e-12)return@repeat
  val grads=Array(x.size){j->val temp=x.copyOf();temp[j]+=1e-5;val shifted=residual(temp);DoubleArray(base.size){k->(shifted[k]-base[k])/1e-5}}
  val grad=DoubleArray(x.size){j->2*base.indices.sumOf{k->base[k]*grads[j][k]}}
  val norm=sqrt(grad.sumOf{it*it});if(norm<1e-10)return@repeat
  var step=0.2;var accepted=false
  repeat(20){if(!accepted){val trial=DoubleArray(x.size){j->x[j]-step*grad[j]/norm};val c=residual(trial).sumOf{it*it};if(c<cost){x=trial;accepted=true}else step*=0.5}}
 }
 val p=pts(x)
 if(p.indices.any{i->p[i].distance(p[(i+1)%n])<1.0})return null
 if(fixedL.indices.any{i->fixedL[i]&&abs(p[i].distance(p[(i+1)%n])-lengths[i])>2.0})return null
 if(fixedA.indices.any{i->fixedA[i]&&abs(angleAt(p,i)-angles[i])>0.05})return null
 if(area(p)<1.0)return null
 return p
}

@Composable
fun PropertyEditorDialog(entity:Entity,onDismiss:()->Unit,onSave:(Entity)->Unit){
 var points by remember(entity.id){mutableStateOf(entity.points)}
 var edgeTexts by remember(entity.id){mutableStateOf(points.indices.map{String.format(java.util.Locale.GERMANY,"%.3f",points[it].distance(points[(it+1)%points.size])/1000)})}
 var angleTexts by remember(entity.id){mutableStateOf(points.indices.map{String.format(java.util.Locale.GERMANY,"%.2f",angleAt(points,it))})}
 var edgeLocks by remember(entity.id){mutableStateOf(points.indices.map{entity.str("propertyEdgeLock$it","false")=="true"})}
 var angleLocks by remember(entity.id){mutableStateOf(points.indices.map{entity.str("propertyAngleLock$it","false")=="true"})}
 var message by remember(entity.id){mutableStateOf("")}
 fun resize(n:Int){
  if(n !in 3..12)return
  val p=regularAround(points,n);points=p
  edgeTexts=p.indices.map{String.format(java.util.Locale.GERMANY,"%.3f",p[it].distance(p[(it+1)%n])/1000)}
  angleTexts=p.indices.map{String.format(java.util.Locale.GERMANY,"%.2f",angleAt(p,it))}
  edgeLocks=List(n){false};angleLocks=List(n){false};message="Kantenzahl geändert: Maße und Fixierungen neu festlegen."
 }
 fun refresh(p:List<Vec>){points=p;edgeTexts=p.indices.map{String.format(java.util.Locale.GERMANY,"%.3f",p[it].distance(p[(it+1)%p.size])/1000)};angleTexts=p.indices.map{String.format(java.util.Locale.GERMANY,"%.2f",angleAt(p,it))}}
 fun compute():List<Vec>?{
  val ls=edgeTexts.map{parseNumber(it)?.times(1000.0)};val as_=angleTexts.map{parseNumber(it)}
  if(ls.any{it==null}||as_.any{it==null}){message="Bitte gültige Zahlen eingeben.";return null}
  val result=solveProperty(points,ls.map{it!!},as_.map{it!!},edgeLocks,angleLocks)
  if(result==null)message="Die fixierten Maße und Winkel sind geometrisch nicht gemeinsam erfüllbar. Bitte Fixierungen lösen oder Werte korrigieren."
  else message=""
  return result
 }
 AlertDialog(onDismissRequest=onDismiss,title={Text("Grundstück bearbeiten")},text={Column(Modifier.fillMaxWidth().heightIn(max=620.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)){
  Row(verticalAlignment=Alignment.CenterVertically){Text("Anzahl der Kanten",Modifier.weight(1f));OutlinedButton(onClick={resize(points.size-1)},enabled=points.size>3){Text("−")};Text(" ${points.size} ");OutlinedButton(onClick={resize(points.size+1)},enabled=points.size<12){Text("+")}}
  Text("Grundstücksvorschau",style=MaterialTheme.typography.titleSmall)
  Canvas(Modifier.fillMaxWidth().height(215.dp)){
   val bounds=Bounds.of(points);val w=bounds.width.coerceAtLeast(1.0);val h=bounds.height.coerceAtLeast(1.0)
   val factor=min((size.width-44f)/w,(size.height-44f)/h).toFloat().coerceAtLeast(0.000001f)
   fun pos(p:Vec)=Offset(size.width/2+((p.x-bounds.center.x)*factor).toFloat(),size.height/2+((p.y-bounds.center.y)*factor).toFloat())
   val path=Path();points.forEachIndexed{i,p->val v=pos(p);if(i==0)path.moveTo(v.x,v.y)else path.lineTo(v.x,v.y)};path.close()
   drawPath(path,Color(0xFF168B9A),style=Stroke(2.5.dp.toPx()))
   points.forEachIndexed{i,p->val v=pos(p);drawCircle(Color(0xFF168B9A),3.dp.toPx(),v)}
   val paint=android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply{color=android.graphics.Color.rgb(22,139,154);textSize=12.dp.toPx();textAlign=android.graphics.Paint.Align.CENTER}
   val c=drawContext.canvas.nativeCanvas
   points.indices.forEach{i->
    val a=pos(points[i]);val b=pos(points[(i+1)%points.size]);val mid=Offset((a.x+b.x)/2,(a.y+b.y)/2)
    val outward=Offset(mid.x-size.width/2,mid.y-size.height/2);val norm=hypot(outward.x,outward.y).coerceAtLeast(1f)
    c.drawText("${edgeNames[i]} ${edgeTexts[i]} m",mid.x+outward.x/norm*17f,mid.y+outward.y/norm*17f,paint)
    val center=pos(Bounds.of(points).center);val corner=pos(points[i]);val dx=center.x-corner.x;val dy=center.y-corner.y;val len=hypot(dx,dy).coerceAtLeast(1f)
    c.drawText("${angleNames[i]} ${angleTexts[i]}°",corner.x+dx/len*24f,corner.y+dy/len*24f,paint)
   }
  }
  Text("Kanten und Innenwinkel (a beginnt an Ecke α)",style=MaterialTheme.typography.labelMedium)
  Row{Text("Länge (m)",Modifier.weight(1f));Spacer(Modifier.width(8.dp));Text("Innenwinkel (°)",Modifier.weight(1f))}
  points.indices.forEach{i->Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(3.dp)){
   Text(edgeNames[i],Modifier.width(15.dp));OutlinedTextField(edgeTexts[i],{v->edgeTexts=edgeTexts.toMutableList().also{it[i]=v};edgeLocks=edgeLocks.toMutableList().also{it[i]=true}},Modifier.weight(1f),singleLine=true)
   IconButton(onClick={edgeLocks=edgeLocks.toMutableList().also{it[i]=!it[i]}}){Icon(if(edgeLocks[i])Icons.Default.Lock else Icons.Default.LockOpen,"Länge fixieren")}
   Text(angleNames[i],Modifier.width(17.dp));OutlinedTextField(angleTexts[i],{v->angleTexts=angleTexts.toMutableList().also{it[i]=v};angleLocks=angleLocks.toMutableList().also{it[i]=true}},Modifier.weight(1f),singleLine=true)
   IconButton(onClick={angleLocks=angleLocks.toMutableList().also{it[i]=!it[i]}}){Icon(if(angleLocks[i])Icons.Default.Lock else Icons.Default.LockOpen,"Winkel fixieren")}
  }}
  Text("🔒 Fixiert · offenes Schloss: berechnet",style=MaterialTheme.typography.labelSmall)
  Text("Fläche: ${String.format(java.util.Locale.GERMANY,"%.2f",area(points)/1e6)} m² · Umfang: ${String.format(java.util.Locale.GERMANY,"%.2f",length(points,true)/1000)} m")
  if(message.isNotBlank())Text(message,color=MaterialTheme.colorScheme.error)
  OutlinedButton(onClick={compute()?.let{refresh(it)}},modifier=Modifier.fillMaxWidth()){Text("Geometrie berechnen / Vorschau aktualisieren")}
 }},confirmButton={TextButton(onClick={val p=compute();if(p!=null){var e=entity.copy(points=p);p.indices.forEach{i->e=e.withStr("propertyEdgeLock$i",edgeLocks[i].toString()).withStr("propertyAngleLock$i",angleLocks[i].toString())};onSave(e)}}){Text("Übernehmen")}},dismissButton={TextButton(onClick=onDismiss){Text("Abbrechen")}})
}
