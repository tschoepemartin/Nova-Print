package de.baudetail.ui.dialogs

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject

private const val PREFS="bruns_external_catalog"
private const val KEY_URI="folder_uri"
private const val DATA_FILE="bruns-pflanzen-2026-2027.json"
private data class BrunsPlant(val botanical:String,val german:String,val number:String)

private fun locateBrunsJson(folder:DocumentFile,depth:Int=0):DocumentFile? {
 if(depth>3)return null
 folder.listFiles().firstOrNull{it.isFile&&it.name.equals(DATA_FILE,true)}?.let{return it}
 for(child in folder.listFiles())if(child.isDirectory){locateBrunsJson(child,depth+1)?.let{return it}}
 return null
}

private fun loadBruns(context:Context,uri:Uri):List<BrunsPlant> {
 val root=DocumentFile.fromTreeUri(context,uri)?:error("Ordner nicht erreichbar")
 val file=locateBrunsJson(root)?:error("$DATA_FILE im gewählten Ordner nicht gefunden")
 val raw=context.contentResolver.openInputStream(file.uri)?.bufferedReader(Charsets.UTF_8)?.use{it.readText()}
  ?:error("Bruns-Datei konnte nicht gelesen werden")
 val entries=JSONObject(raw).getJSONArray("pflanzen")
 return (0 until entries.length()).map { i ->
  val entry=entries.getJSONObject(i)
  BrunsPlant(entry.optString("botanisch"),entry.optString("deutsch"),entry.optString("pflanzenNummer"))
 }
}

/** External offline manufacturer catalog, accessed via Android's persisted Storage Access Framework grant. */
@Composable
fun BrunsPlantPicker(onDismiss:()->Unit,onSelect:(String)->Unit) {
 val context=LocalContext.current
 val prefs=remember(context){context.getSharedPreferences(PREFS,Context.MODE_PRIVATE)}
 var folderUri by remember { mutableStateOf(prefs.getString(KEY_URI,null)) }
 var plants by remember { mutableStateOf<List<BrunsPlant>>(emptyList()) }
 var loading by remember { mutableStateOf(false) }
 var message by remember { mutableStateOf<String?>(null) }
 val choose=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()){uri->
  if(uri!=null){
   runCatching{context.contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)}
   prefs.edit().putString(KEY_URI,uri.toString()).apply()
   folderUri=uri.toString()
  }
 }
 LaunchedEffect(folderUri){
  plants=emptyList()
  if(folderUri!=null){
   loading=true
   val result=withContext(Dispatchers.IO){runCatching{loadBruns(context,Uri.parse(folderUri))}}
   result.onSuccess{plants=it;message=null}.onFailure{message=it.message?:"Katalog nicht lesbar"}
   loading=false
  }
 }
 var query by remember { mutableStateOf("") }
 val matches=remember(plants,query) {
  if(query.isBlank()) plants.take(80)
  else plants.asSequence().filter {
   it.botanical.contains(query,true)||it.german.contains(query,true)||it.number.contains(query,true)
  }.take(100).toList()
 }
 AlertDialog(onDismissRequest=onDismiss,title={Text("Bruns Baumschulen · Pflanzenkatalog")},
  text={Column(Modifier.fillMaxWidth().heightIn(max=500.dp)) {
   Text(if(folderUri==null)"Einmalig den Ordner ›Bruns Baumschulen‹ mit den entpackten Pflanzendaten auswählen." else "Herstellerkatalog aus dem gewählten Ordner",style=MaterialTheme.typography.bodySmall)
   TextButton(onClick={choose.launch(null)}){Text(if(folderUri==null)"Bruns-Ordner auswählen" else "Bruns-Ordner wechseln")}
   if(loading)LinearProgressIndicator(Modifier.fillMaxWidth())
   message?.let{Text(it,color=MaterialTheme.colorScheme.error)}
   if(plants.isNotEmpty()){
    OutlinedTextField(value=query,onValueChange={query=it},label={Text("Pflanzenname oder Artikelnummer")},singleLine=true,modifier=Modifier.fillMaxWidth())
    Text("${matches.size} Treffer angezeigt · ${plants.size} Einträge offline",style=MaterialTheme.typography.bodySmall)
    LazyColumn(Modifier.weight(1f)) {
     items(matches,key={it.number+it.botanical}) { plant ->
      TextButton(onClick={onSelect(plant.botanical.ifBlank{plant.german})},modifier=Modifier.fillMaxWidth()) {
       Column(Modifier.fillMaxWidth()) {
        Text(plant.botanical)
        if(plant.german.isNotBlank())Text(plant.german,style=MaterialTheme.typography.bodySmall)
        Text("Bruns-Nr. ${plant.number}",style=MaterialTheme.typography.labelSmall)
       }
      }
     }
    }
   }
  }},confirmButton={TextButton(onClick=onDismiss){Text("Schließen")}})
}
