package de.baudetail.ui.panels

import androidx.compose.foundation.layout.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import de.baudetail.core.*
import de.baudetail.geometry.*
import de.baudetail.ui.*
import de.baudetail.ui.dialogs.*
import kotlinx.serialization.json.*

@Composable
internal fun StairAndSurfaceDialogs(dialog:String,e:Entity,vm:BaudetailViewModel,setDialog:(String)->Unit,onAddCut:(String)->Unit){
 val d=vm.drawing?:return
 when(dialog){
 "stair"->if(e!=null)StairDialog(vm.catalog.entries()+vm.project!!.libraryEntries,e,{setDialog("")},vm::saveStair)
 "variant"->{
  val all=(vm.catalog.entries()+vm.project!!.libraryEntries).distinctBy{it.id};val source=all.find{it.id==e.libraryId};val family=if(e.smartFamily()!="component")e.smartFamily() else source?.smartFamily() ?: "component";val group=e.str("variantGroup").ifBlank{source?.variantGroup().orEmpty()}
  val options=all.filter{it.type=="component"&&it.smartFamily()==family&&(group.isBlank()||it.variantGroup()==group)}.sortedBy{it.name}
  if(options.isEmpty())AlertDialog(onDismissRequest={setDialog("")},text={Text("Keine kompatiblen Varianten in der geladenen Bibliothek.")},confirmButton={TextButton(onClick={setDialog("")}){Text("OK")}})
  else ChoiceDialog("Bauteiltyp ändern · Bezugspunkt bleibt erhalten",options.map{it.name},{setDialog("")}){i->val base=if(e.smartFamily()=="component")e.withStr("componentFamily",family).withStr("variantGroup",group)else e;val changed=replaceComponentVariant(base,options[i]);vm.project?.let{p->vm.update(changed);if(p.libraryEntries.none{it.id==options[i].id})vm.attachLibraryForPlacedVariant(options[i])}}
 }
 "label"->{val b=viewBounds(e,d);val center=b.center;val auto=objectLabelPosition(e,d)-center;val section=d.viewMode()=="section";val dxKey=if(section)"labelSectionDx"else"labelTopDx";val dyKey=if(section)"labelSectionDy"else"labelTopDy";FormDialog("Objektbeschriftung",listOf(Field("mode","Textmodus",e.str("labelMode","auto"),choices=listOf("auto","manuell")),Field("text","Manueller Text",e.str("labelText")),Field("dx","Textabstand X mm",fmt(e.num(dxKey,auto.x)),true),Field("dy","Textabstand Y mm",fmt(e.num(dyKey,auto.y)),true)),{setDialog("")}){v->var n=e.withStr("labelMode",v["mode"].orEmpty()).withStr("labelText",v["text"].orEmpty());n=n.withNum(dxKey,parseNumber(v["dx"]!!)!!).withNum(dyKey,parseNumber(v["dy"]!!)!!);vm.update(n)}}
 "snapPriority"->ChoiceDialog("Snap-Priorität · Führende Bauteile werden beim Fangen bevorzugt",listOf("Führend","Normal","Folgend"),{setDialog("")},selectedIndex=when(e.str("snapPriority","normal")){"high"->0;"low"->2;else->1}){i->vm.update(e.withStr("snapPriority",listOf("high","normal","low")[i]))}
 "dimensionRotation"->{val labels=listOf("Winkelsnap 15°","Winkelsnap 30°","Winkelsnap 45°","Winkelsnap 90°","Frei drehbar");val idx=if(e.str("rotationMode","snap")=="free")4 else when(e.num("angleSnapStep",15.0).toInt()){30->1;45->2;90->3;else->0};ChoiceDialog("Drehmodus · aktueller Modus ist markiert",labels,{setDialog("")},selectedIndex=idx){i->vm.update(if(i==4)e.withStr("rotationMode","free") else e.withStr("rotationMode","snap").withNum("angleSnapStep",listOf(15.0,30.0,45.0,90.0)[i]))}}
 "plantingSettings"->{
  val names=listOf("Tragschicht","Oberboden grob","Oberboden fein","Deckschicht")
  val materials=listOf(listOf("FS-Kies","Auffüllkies","Rotlage","Schotter 0/32","Sonstiges"),listOf("Oberboden 0/35","Oberboden","Sonstiges"),listOf("Oberboden 0/20","Oberboden","Sonstiges"),listOf("Rindenkompost","Rindenmulch","Lavamulch","Keine","Sonstiges"))
  val defaults=listOf(200.0,200.0,150.0,50.0)
  val bounds=Bounds.of(e.points)
  val localLength=if(e.points.size==4)e.points[0].distance(e.points[1]) else bounds.width
  val localWidth=if(e.points.size==4)e.points[0].distance(e.points[3]) else bounds.height
  val fields=mutableListOf(Field("length","Länge (mm)",fmt(localLength),true,true),Field("width","Breite (mm)",fmt(localWidth),true,true),Field("type","Pflanzflächentyp",e.str("plantingType","Staudenfläche"),choices=listOf("Staudenfläche","Gehölzfläche","Bodendeckerfläche","Mischpflanzung","Freie Pflanzfläche")))
  names.indices.reversed().forEach{i->
   val name=names[i]
   val layer=e.strata.getOrNull(i)
   val current=layer?.materialId?.ifBlank{layer.name}?:materials[i].first()
   fields.add(Field("material$i","$name · Material",if(current in materials[i])current else "Sonstiges",choices=materials[i]))
   fields.add(Field("custom$i","$name · freie Materialbezeichnung",if(current in materials[i])"" else current,visibleChoiceKey="material$i",visibleChoiceValue="Sonstiges"))
   fields.add(Field("label$i","$name · Beschriftung",layer?.name?:name))
   fields.add(Field("grading$i","$name · Körnung",layer?.grading.orEmpty()))
   fields.add(Field("thickness$i","$name · Dicke (mm)",fmt(layer?.thicknessMm?:defaults[i]),true,true))
  }
  FormDialog("Pflanzfläche · vier Schichten",fields,{setDialog("")}){v->
   val colors=listOf("#C7BDAA","#947B5B","#A18A68","#785438")
   val updated=names.mapIndexed{i,name->
    val selected=v["material$i"].orEmpty()
    val material=if(selected=="Sonstiges")v["custom$i"].orEmpty().ifBlank{name}else selected
    val thickness=(parseNumber(v["thickness$i"].orEmpty())?:defaults[i]).coerceAtLeast(0.0)
    val surfaceColor=when {
     material.contains("Rindenkompost",true)->"#483225"
     material.contains("Rindenmulch",true)->"#785038"
     material.contains("Lavamulch",true)->"#754C43"
     material.contains("Oberboden",true)->"#947B5B"
     material.contains("Rotlage",true)->"#9C735E"
     material.contains("Kies",true)||material.contains("Schotter",true)->"#B8AEA0"
     else->colors[i]
    }
    Stratum(material,v["label$i"].orEmpty().ifBlank{name},if(material=="Keine")0.0 else thickness,surfaceColor,v["grading$i"].orEmpty())
   }
   val length=(parseNumber(v["length"].orEmpty())?:localLength).coerceAtLeast(1.0)
   val width=(parseNumber(v["width"].orEmpty())?:localWidth).coerceAtLeast(1.0)
   require(length.isFinite()&&width.isFinite()&&length<=1e7&&width<=1e7){"Länge/Breite ungültig"}
   val resized=if(e.points.size==4)resizeParametricRectangle(e,length,width) else e.copy(points=rectangle(bounds.min,bounds.min+Vec(length,width)))
   vm.update(resized.copy(strata=updated).withStr("plantingType",v["type"].orEmpty()))
  }
 }
 "eavesSettings"->{
  val names=listOf("Tragschicht","Deckschicht")
  val materials=listOf(
   listOf("Schotter 0/32","FS-Kies 0/32","Kies 0/32","Splitt 2/5","Sonstiges"),
   listOf("Kies 16/32 Grau","Kies 16/32 Anthrazit","Kies 16/32 Weiß","Kies 16/32 Beige","Kies 8/16 Grau","Zierschotter Anthrazit","Zierschotter Rotbraun","Zierschotter Weiß","Schotter 16/32","Splitt 8/16","Sonstiges")
  )
  val defaults=listOf(150.0,100.0)
  val bounds=Bounds.of(e.points)
  val edgeLength=if(e.points.size==4)e.points[0].distance(e.points[1]) else bounds.width
  val edgeWidth=if(e.points.size==4)e.points[0].distance(e.points[3]) else bounds.height
  val fields=mutableListOf(Field("length","Länge (mm)",fmt(edgeLength),true,true),Field("width","Breite (mm)",fmt(edgeWidth),true,true),Field("type","Traufenart",e.str("eavesType","Kiesstreifen"),choices=listOf("Kiesstreifen","Spritzschutzstreifen","Zierkiesstreifen","Schotterstreifen")))
  names.indices.reversed().forEach{i->
   val name=names[i]
   val layer=e.strata.getOrNull(i)
   val current=layer?.materialId?.ifBlank{layer.name}?:materials[i].first()
   fields.add(Field("material$i","$name · Material",if(current in materials[i])current else "Sonstiges",choices=materials[i]))
   fields.add(Field("custom$i","$name · freie Materialbezeichnung",if(current in materials[i])"" else current,visibleChoiceKey="material$i",visibleChoiceValue="Sonstiges"))
   fields.add(Field("label$i","$name · Beschriftung",layer?.name?:name))
   fields.add(Field("grading$i","$name · Körnung",layer?.grading.orEmpty()))
   fields.add(Field("thickness$i","$name · Dicke (mm)",fmt(layer?.thicknessMm?:defaults[i]),true,true))
  }
  FormDialog("Traufe · Schichtaufbau",fields,{setDialog("")}){v->
   val colors=listOf("#9F9F99","#B6B5AD")
   val updated=names.mapIndexed{i,name->
    val selected=v["material$i"].orEmpty()
    val material=if(selected=="Sonstiges")v["custom$i"].orEmpty().ifBlank{name}else selected
    val thickness=(parseNumber(v["thickness$i"].orEmpty())?:defaults[i]).coerceAtLeast(0.0)
    val surfaceColor=when {
     material.contains("Anthrazit",true)->"#505154"
     material.contains("Weiß",true)->"#E3E1D9"
     material.contains("Beige",true)->"#C6B69A"
     material.contains("Rotbraun",true)->"#985D48"
     material.contains("Oberboden",true)->"#947B5B"
     material.contains("Rotlage",true)->"#9C735E"
     material.contains("Kies",true)||material.contains("Schotter",true)->"#B8AEA0"
     else->colors[i]
    }
    Stratum(material,v["label$i"].orEmpty().ifBlank{name},if(material=="Keine")0.0 else thickness,surfaceColor,v["grading$i"].orEmpty())
   }
   val length=(parseNumber(v["length"].orEmpty())?:edgeLength).coerceAtLeast(1.0)
   val width=(parseNumber(v["width"].orEmpty())?:edgeWidth).coerceAtLeast(1.0)
   require(length.isFinite()&&width.isFinite()&&length<=1e7&&width<=1e7){"Länge/Breite ungültig"}
   val resized=if(e.points.size==4)resizeParametricRectangle(e,length,width) else e.copy(points=rectangle(bounds.min,bounds.min+Vec(length,width)))
   vm.update(resized.copy(strata=updated).withStr("eavesType",v["type"].orEmpty()))
  }
 }
 "grassSettings"->FormDialog("Rasen · Aufbau und Form",listOf(
 Field("type","Rasenart",e.str("grassType","Gebrauchsrasen"),choices=listOf("Gebrauchsrasen","Zierrasen","Landschaftsrasen","Sportrasen","Golfrasen","Kräuterrasen","Blumenwiese","Kunstrasen","Sonstige")),
 Field("rsm","RSM / Sorte",e.str("grassRsm","RSM 2.3")),
 Field("method","Herstellung",e.str("grassMethod","Saatrasen"),choices=listOf("Saatrasen","Rollrasen","Kunstrasen")),
 Field("shape","Form",e.str("grassShape","Rechteckig"),choices=listOf("Rechteckig","Quadratisch","Rund")),
 Field("length","Länge mm / Durchmesser bei Rund",fmt(viewBounds(e,d).width),true,true),
 Field("width","Breite mm",fmt(viewBounds(e,d).height),true,true),
 Field("blade","Halmlänge mm (oberhalb OK Grasnarbe)",fmt(e.num("grassBladeMm",40.0)),true,true),
 Field("layer1","Schicht 1 · Material",e.str("grassLayer1Name","Oberboden")),
 Field("grading1","Schicht 1 · Körnung",e.str("grassLayer1Grading","0/15")),
 Field("depth1","Schicht 1 · Dicke mm",fmt(e.num("grassLayer1Mm",50.0)),true),
 Field("layer2","Schicht 2 · Material",e.str("grassLayer2Name","Oberboden")),
 Field("grading2","Schicht 2 · Körnung",e.str("grassLayer2Grading","0/25")),
 Field("depth2","Schicht 2 · Dicke mm",fmt(e.num("grassLayer2Mm",150.0)),true)
 )+buildUpMeasureFields(e,true),{setDialog("")}){v->
 val b=viewBounds(e,d);val l=(parseNumber(v["length"].orEmpty())?:b.width).coerceAtLeast(1.0);val w=(parseNumber(v["width"].orEmpty())?:b.height).coerceAtLeast(1.0)
 val shape=v["shape"].orEmpty();val newPoints=if(shape=="Rund") (0..63).map{i->val a=i*2.0*Math.PI/64.0;Vec(b.min.x+l/2.0+kotlin.math.cos(a)*l/2.0,b.min.y+l/2.0+kotlin.math.sin(a)*l/2.0)} else rectangle(b.min,b.min+Vec(l,if(shape=="Quadratisch")l else w))
 var n=e.withStr("grassType",v["type"].orEmpty()).withStr("grassRsm",v["rsm"].orEmpty()).withStr("grassMethod",v["method"].orEmpty()).withStr("grassShape",shape)
 val sectionLength=(parseNumber(v["sectionLength"].orEmpty())?:e.num("grassSectionLengthMm",l))
 val realLength=(parseNumber(v["realLength"].orEmpty())?:sectionLength)
 val sectionWidth=(parseNumber(v["sectionWidth"].orEmpty())?:w)
 val realWidth=(parseNumber(v["realWidth"].orEmpty())?:w)
 val slope=kotlin.math.abs(parseNumber(v["slopePct"].orEmpty())?:0.0)
 require(sectionLength>0.0 && realLength>0.0 && sectionWidth>0.0 && realWidth>0.0 && slope<=100.0){"Schnittlänge, Realmaß oder Gefälle ungültig"}
 n=n.withNum("grassSectionLengthMm",sectionLength).withNum("buildUpSectionLengthMm",sectionLength)
  .withNum("buildUpSectionWidthMm",sectionWidth).withNum("buildUpRealWidthMm",realWidth)
  .withStr("buildUpRealLengthEnabled",if(v["realLengthEnabled"]=="ja" || kotlin.math.abs(realLength-sectionLength)>0.01)"true" else "false")
  .withNum("buildUpRealLengthMm",realLength)
  .withNum("buildUpSlopePct",if(v["slopeDirection"]=="Nach links fallend")-slope else slope)
  .withStr("buildUpSlopeFixedSide",if(v["slopeFixedSide"]=="Rechts")"right" else "left")
  .withNum("buildUpSlopeLabelDx",parseNumber(v["slopeLabelDx"].orEmpty())?:0.0)
  .withNum("buildUpSlopeLabelDy",parseNumber(v["slopeLabelDy"].orEmpty())?:0.0)
 n=n.withNum("grassBladeMm",(parseNumber(v["blade"].orEmpty())?:40.0).coerceAtLeast(0.0))
 for(i in 1..2){n=n.withStr("grassLayer${i}Name",v["layer$i"].orEmpty()).withStr("grassLayer${i}Grading",v["grading$i"].orEmpty()).withNum("grassLayer${i}Mm",(parseNumber(v["depth$i"].orEmpty())?:0.0).coerceAtLeast(0.0))}
 vm.update(n.copy(points=newPoints))
 }

 "elevationEdit"->ElevationDialog("Höhenkote bearbeiten",e.str("elevationRole","manual"),fmt((if(e.str("elevationRole")=="relative")e.num("heightOffsetMm") else e.num("heightMm"))/1000.0),e.str("elevationPrefix"),e.num("elevationFontPaperMm",3.0),e.num("elevationArrowPaperMm",2.5),{setDialog("")}){role,value,prefix,fontMm,arrowMm->var n=e.withStr("elevationRole",role).withStr("elevationPrefix",prefix).withNum("elevationFontPaperMm",fontMm).withNum("elevationArrowPaperMm",arrowMm);n=if(role=="relative")n.withNum("heightOffsetMm",value*1000.0)else n.withNum("heightMm",value*1000.0);vm.update(n)}
 "legendEdit"->{
  val items=legendItems(d,vm.project!!.libraryEntries)
  val fields=mutableListOf(Field("title","Überschrift",e.text))
  items.forEachIndexed{i,item->
   fields.add(Field("show$i","${item.label} anzeigen",if(e.str("legendVisible:${item.key}","true")!="false")"ja"else"nein",checkbox=true))
   fields.add(Field("label$i","Text",e.str("legendLabel:${item.key}").ifBlank{item.label}))
   fields.add(Field("color$i","Farbe #RRGGBB",e.str("legendColor:${item.key}").ifBlank{item.style.fill?:"#D0D0D0"}))
   fields.add(Field("order$i","Reihenfolge",fmt(e.num("legendOrder:${item.key}",i.toDouble())),true))
  }
  FormDialog("Legende bearbeiten",fields,{setDialog("")}){v->
   var n=e.copy(text=v["title"].orEmpty())
   items.forEachIndexed{i,item->
    val color=v["color$i"].orEmpty();require(Regex("#[0-9a-fA-F]{6}([0-9a-fA-F]{2})?").matches(color)){"Ungültige Farbe bei ${item.label}"}
    n=n.withStr("legendVisible:${item.key}",(v["show$i"]=="ja").toString()).withStr("legendLabel:${item.key}",v["label$i"].orEmpty()).withStr("legendColor:${item.key}",color).withNum("legendOrder:${item.key}",parseNumber(v["order$i"]!!)!!)
   }
   vm.update(n)
  }
 }

 }
}

