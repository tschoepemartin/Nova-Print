package de.baudetail.ui.diagnostics

import android.os.SystemClock
import java.util.Locale

/** Opt-in, bounded, local sampling. No project content or coordinates are stored. */
object PerformanceTrace {
 @Volatile var enabled = false
 @Volatile var scenario = "Werkzeugleiste"
 private data class Sample(val elapsedMs:Long,val kind:String,val durationMs:Double,val objects:Int)
 private val samples = ArrayList<Sample>(4096)
 private var started = 0L
 private var lastFrame = 0L
 @Synchronized fun start(name:String) {
  scenario=name; samples.clear(); started=SystemClock.uptimeMillis();lastFrame=0L;enabled=true
 }
 @Synchronized fun stop(){enabled=false}
 @Synchronized fun sample(kind:String,nanos:Long,objects:Int){
  if(!enabled)return
  if(samples.size>=12000){enabled=false;return}
  samples.add(Sample(SystemClock.uptimeMillis()-started,kind,(if(kind=="zoom_factor")nanos/1_000_000.0 else nanos/1_000_000.0),objects))
 }
 @Synchronized fun frameStart():Long {
  if(!enabled)return 0L
  val now=System.nanoTime()
  if(lastFrame!=0L)sample("canvas_interval",now-lastFrame,0)
  lastFrame=now
  return now
 }
 @Synchronized fun csv():String=buildString {
  append("# BauDetail Performance-Diagnose; Version ").append(Diagnostics.version()).append('\n')
  append("# Szenario: ").append(scenario.replace('\n',' ')).append('\n')
  append("# canvas_interval = Abstand zwischen Canvas-Aufrufen, KEINE systemweite FPS-Messung\n")
  append("# canvas_draw = CPU-Dauer; render_* = aufaddierte Zeichenzeiten nach Primitivtyp (Gruppen enthalten Unterelemente)\n")
  append("# zoom_factor: Zoomfaktor als Wert in duration_ms (nicht Millisekunden)\n")
  append("# input_queue_delay: Zeit von Android-Touchzeitstempel bis zum Eintritt in den Canvas-Handler\n")
  append("# scene_build: Aufbau der Zeichenprimitive; canvas_composition: Anzahl der Compositions (Dauer 0)\n")
  append("elapsed_ms,metric,duration_ms,objects\n")
  samples.forEach{append(it.elapsedMs).append(',').append(it.kind).append(',').append(String.format(Locale.US,"%.3f",it.durationMs)).append(',').append(it.objects).append('\n')}
 }
 @Synchronized fun timeline():List<Triple<Long,String,String>> = samples.map {
  Triple(it.elapsedMs,it.kind,String.format(Locale.US,"%.3f",it.durationMs))
 }
 @Synchronized fun count():Int=samples.size
}
