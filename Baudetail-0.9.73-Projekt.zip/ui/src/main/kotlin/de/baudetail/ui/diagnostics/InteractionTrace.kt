package de.baudetail.ui.diagnostics

import android.os.SystemClock
import android.view.MotionEvent
import java.util.Locale

/** Opt-in, bounded event log. Does not store coordinates, drawing data or names. */
object InteractionTrace {
 @Volatile var enabled = false
 private data class Event(val ms: Long, val source: String, val action: String, val fingers: Int,
                          val tool: String, val zoom: Double, val queueMs: Long, val workMs: Double)
 private val events = ArrayList<Event>(8192)
 private var startMs = 0L
 private var dropped = 0
 private var lastEventAt = 0L
 private var stallCount = 0
 @Synchronized fun start() {
  events.clear(); dropped=0; stallCount=0; startMs=SystemClock.uptimeMillis(); lastEventAt=startMs; enabled=true
  PerformanceTrace.start("Automatische Sitzung")
 }
 @Synchronized fun stop() { enabled=false; PerformanceTrace.stop() }
 @Synchronized fun count():Int=events.size
 @Synchronized fun record(source:String,action:String,fingers:Int,tool:String="",zoom:Double=0.0,
                          eventTime:Long=SystemClock.uptimeMillis(),workMs:Double=0.0) {
  if(!enabled)return
  if(events.size>=30000){dropped++;return}
  val now=SystemClock.uptimeMillis()
  val delay=(now-eventTime).coerceAtLeast(0)
  if(delay>=250 && source=="android") {
   stallCount++
   events.add(Event(now-startMs,"warning","INPUT_STALL_${delay}ms",fingers,tool,zoom,delay,0.0))
  }
  events.add(Event(now-startMs,source,action,fingers,tool,zoom,delay,workMs))
  lastEventAt=now
 }
 fun actionName(action:Int):String=when(action){
  MotionEvent.ACTION_DOWN->"DOWN";MotionEvent.ACTION_POINTER_DOWN->"POINTER_DOWN"
  MotionEvent.ACTION_MOVE->"MOVE";MotionEvent.ACTION_POINTER_UP->"POINTER_UP"
  MotionEvent.ACTION_UP->"UP";MotionEvent.ACTION_CANCEL->"CANCEL";else->"OTHER"
 }
 @Synchronized fun export():String=buildString {
  append("# BauDetail Interaktionsdiagnose ").append(Diagnostics.version()).append('\n')
  append("# Zeiten: monotone Millisekunden seit Start; keine Beruehrungskoordinaten oder Projektinhalte\n")
  append("# queue_ms: Android Ereigniszeit bis Protokollierung; work_ms: Canvas Handlerdauer\n")
  append("# Erfasste Eingabeverzoegerungen >=250ms: ").append(stallCount).append('\n')
  append("# Verworfene Ereignisse bei Kapazitaetsgrenze: ").append(dropped).append('\n')
  append("elapsed_ms,source,action,fingers,tool,zoom,queue_ms,work_ms\n")
  events.forEach { e ->
   append(e.ms).append(',').append(e.source).append(',').append(e.action).append(',')
    .append(e.fingers).append(',').append(e.tool.replace(',','_')).append(',')
    .append(String.format(Locale.US,"%.5f",e.zoom)).append(',').append(e.queueMs).append(',')
    .append(String.format(Locale.US,"%.3f",e.workMs)).append('\n')
  }
  append("\n# PERFORMANCE_METRIKEN (gleicher monotone Zeitursprung)\n").append(PerformanceTrace.csv())
  append("\n# GEMEINSAME_ZEITACHSE\n")
  append("elapsed_ms,category,event,value_ms\n")
  val unified=events.map { Triple(it.ms,"touch:"+it.source,it.action+";queue="+it.queueMs) } +
   PerformanceTrace.timeline().map { Triple(it.first,"performance",it.second+";duration="+it.third) }
  unified.sortedBy { it.first }.forEach { (t,category,value) ->
   append(t).append(',').append(category).append(',').append(value.substringBefore(';')).append(',')
    .append(value.substringAfter("=", "0")).append('\n')
  }
 }
}
