# BauDetail 0.9.32 – Fix: Pflasterfläche verschwindet beim Zusammenführen

Ursache: Die vereinigte Polygonfläche behielt libraryId und parametricBuildUp=true des ursprünglichen stack-Objekts. Dadurch leitete Scene.entity die Fläche wieder an den Stack-Renderer statt an den Polygon-Pflaster-Renderer weiter.

Fix: Bei der Vereinigung libraryId entfernen und parametricBuildUp-Flag entfernen. Zusätzlich erkennt isParametricBuildUp alle mergedPaving-Objekte ausdrücklich als NICHT parametrischen Stack, auch für bereits gespeicherte 0.9.31-Objekte.

Nicht lokal kompiliert oder auf Android getestet.
