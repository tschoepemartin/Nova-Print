# Verbindliche externe Bibliothek – BauDetail

- Android-Dateiverzeichnis: `Interner Speicher/BaudetailBib/Materialien/Hersteller/Godelmann/`
- Katalog: `katalog.json` (Schema 1.0.0, `products`, `materials`, `textureFile`)
- Originaldateien: `Produkte/GDM-.../` einschließlich referenzierter Herstellerbilder.
- Beim **Bibliothek aktualisieren** importiert `importManufacturerCatalog` die Varianten als Materialeinträge unter `Materialien/Hersteller/Godelmann/<Serie>` und speichert die Bildressourcen in der externen App-Bibliotheksablage.
- Mauer: `Mauer anpassen` -> Hersteller Godelmann -> Serie -> zugehörige Farbe/Oberfläche. `wallManufacturerTexture` referenziert den importierten Bildressourcenpfad; keine Godelmann-Bilder in den App-Assets.
- Die Textur wird mit `repeat:<Steinlänge>:<Ressourcenpfad>` gerendert. Exportpfade müssen dieses Präfix vor der Ressourcenauflösung entfernen.
- Die Android-SAF-Verzeichnisfreigabe muss für den Bibliotheksordner bestehen; ein Dateisystempfad allein gewährt keinen Zugriff.
- Kein Duplizieren von Herstellerbildern in APK/Projekt.
