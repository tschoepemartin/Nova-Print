# BauDetail 0.9.33

- Pflanzung anpassen: Dropdown Laubgehölz / Nadelgehölz.
- Pflanzung anpassen: Checkbox Bestand.
- Nadelgehölz erhält dunklere, nadelartige Kronenstruktur in Draufsicht/PDF.
- Bestandspflanzen erhalten eine zusätzliche gestrichelte Außenkontur.
- Beide Einstellungen werden als Objektparameter gespeichert.

Android-Build und Gerätetest ausstehend.
