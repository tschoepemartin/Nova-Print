# BauDetail 0.9.28 – Pflaster-Innenkanten und Hecken

- Bei verknüpften, kompatiblen, unmittelbar benachbarten Pflasterflächen werden künstliche Randfugen auf gemeinsamen Kantenabschnitten unterdrückt.
- Die ursprünglichen Flächenumrisse bleiben geometrisch unverändert. Nicht geteilte Randabschnitte behalten ihre Randfuge.
- Die Verlegeraster-/Plattentextur bleibt gekoppelt wie in 0.9.26.
- Hecken-Pflanzsymbole statt identischer Kreise mit organischer, unregelmäßig gerundeter Krone und Blattflächen.
- Neue organische Großbaum-/Strauchdarstellung und Pflanzmenü aus 0.9.27 enthalten.

Hinweis: Nicht lokal kompiliert oder auf dem Gerät getestet. Randfugen an komplexen Rotationen/Teilüberlappungen auf dem Gerät prüfen.
