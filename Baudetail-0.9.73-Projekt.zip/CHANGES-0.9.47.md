# BauDetail 0.9.47 – Performance der Zeichenengine

Basis: vollständiges Projekt 0.9.46 aus `Baudetail-0.9.46-Astra-Uebergabe-NEU.zip`.
Version: versionCode 947, versionName 0.9.47.

## Ergebnis und Grenzen

Die Bildschirm-Zeichenengine verwendet jetzt begrenzte Caches für Android-Paths,
Zeichenstifte und Textaufbereitung. Damit entfällt wiederholte Aufbereitung bei
Cache-Treffern, insbesondere beim Pan/Zoom einer unveränderten Szene und beim
Zeichnen des unveränderten Hintergrunds während eines Objekt-Drags.

Es liegen **keine gemessenen Android-Performanceverbesserungen** vor. Die Version
wurde hier **nicht kompiliert und nicht auf Android ausgeführt**. Das Erfolgskriterium
„deutlich flüssiger bei identischem Verhalten“ muss nach dem GitHub-Build am Gerät
bestätigt werden. Ein Bytevergleich ist kein Ersatz für diese praktische Abnahme.

## Ursachenanalyse im vorhandenen Code

| Bereich | Konkreter Befund | Entscheidung |
|---|---|---|
| CanvasRenderer: Pfade und Clips | Jeder Draw baute native Paths erneut auf; `drop(1)` erzeugte zusätzliche Listen. Das betrifft auch jede einzelne Stein-/Gruppen-Clipkontur. | Wiederverwendung über vollständige Koordinaten und geschlossen/offen; Schleife ohne Teilliste. |
| CanvasRenderer: Paint | Für jeden Pfad/Kreis wurden Paint, Farbauflösung und gegebenenfalls DashPathEffect erneut erzeugt. | Bildschirm-Paints nach vollständigem Style und Füll-/Linienmodus wiederverwenden. |
| CanvasRenderer: Text | Gleicher Text wurde jedes Frame in Zeilen zerlegt, Schrift konfiguriert und vermessen. | Zeilen, Text-Paint und Maximalbreite nach Text, Größe und vollständigem Style wiederverwenden. |
| Szene / Compose | DrawingCanvas hält Scene.drawing bereits mit remember(d,p); Snap-Zielkanten und Drag-Hintergründe haben bereits Caches. | Keine zusätzliche doppelte Szenenablage. |
| Gesten / Drag-Vorschau | Scene.entity für das bewegte Objekt wird weiterhin im Draw neu erzeugt. Abhängige Beschriftungen, Schnittlagen und Anschlüsse machen eine pauschale Verschiebung der alten Grafik riskant. | Unverändert. Diese Kosten können weiterhin dominieren. |
| Touch / Snapping | Universelle Plan-Kanten sind bereits gecacht; spezielle Snap-Pfade und Griffbearbeitung führen weitere Geometrieabfragen aus. | Keine Änderung an Fangsuche, Reihenfolge, Toleranzen oder Ereignisverarbeitung. |
| Compose-Zustand | Zoom, Pan, Snap-Markierungen und Koordinatenanzeige verursachen Zustandsänderungen. Ohne Laufzeitprofil ist die Zahl vermeidbarer Recompositions nicht belegt. | Keine Umbauten an State oder Callback-Lebensdauer. |
| Texturen / Ressourcen | Bitmap-/SVG-/Mipmap-Caches und quickReject für Assets existieren bereits. Pro-Asset-Dateiprüfungen und Shader-Aufbereitung bleiben vorhanden. | Unverändert, einschließlich Auflösung, Mipmap-Auswahl und Dateiprüfung. |
| Sichtbarkeit | Zusätzliche grobe Objekt-Bounds könnten Beschriftungen, breite Striche oder herausragende Details abschneiden. | Keine neue Sichtbarkeitsfilterung. |

Dies sind aus dem Code belegte wiederholte Arbeiten, keine profilierten Anteile
an der gesamten Framezeit. Es wurde kein pauschales Ergebnis für CPU oder GC abgeleitet.

## Konkrete Implementierung und Invalidierung

Produktiv geändert wurden nur `export/.../CanvasRenderer.kt` und die Versionsangabe
in `app/build.gradle.kts`. Keine neuen Abhängigkeiten.

1. **Path-Cache:** Schlüssel aus allen Punkten und dem Closed-Flag. Die gespeicherten
   Punktlisten sind Kopien; auch eine nachträgliche Änderung einer übergebenen Liste
   führt nicht zu einer veralteten Kontur. Es werden keine Hashwerte allein als
   Identität verwendet. Der Lookup vergleicht vollständige Werte. Android-Paths
   bleiben nach Erstellung unverändert. Canvas-Transform und Clip werden weiterhin
   für jeden Draw angewendet. Der Cache ist mit 131072 Gewichtseinheiten begrenzt
   (Punktzahl + 16 je Eintrag), also keine unbeschränkte Sammlung. Sehr große
   Einzelpfade werden normal gezeichnet, ohne den gesamten Cache zu verdrängen.
2. **Paint-Cache:** maximal 512 Style-/Füllmodus-Kombinationen. Gecachte Paints werden
   ausschließlich zum Zeichnen verwendet und nicht nachträglich verändert.
3. **Text-Cache:** Text, Double-Schriftgröße und vollständiger Style bestimmen die
   vorbereiteten Zeilen, Schrift und Breite. Position und Drehung werden weiterhin
   aktuell angewendet. Text hat eigene Paints und kann niemals einen gecachten
   Flächen-Paint umkonfigurieren. Budget 262144 Gewichtseinheiten (Zeichenanzahl + 128
   je Eintrag); kein behauptetes Byte-/Heap-Limit.
4. **Keine viewportabhängigen Cache-Inhalte:** Pan, Zoom und Ansichtsdrehung benötigen
   keine Invalidierung der Weltkoordinaten-Paths. Neue Geometrie oder Text-/Stiländerung
   erzeugt einen anderen Schlüssel. Alte Einträge werden per LRU verdrängt. Undo,
   Laden oder neue Dokumente können nur bei exakt gleichen Zeichenwerten wiederverwenden.
5. **Druck/PDF:** alle neuen Caches sind nur bei `interactive=true` aktiv. Der
   Export erhält dieselben Zeichenoperationen, Koordinaten, Farben und Textmetriken
   wie zuvor. Pfadaufbau und Textvorbereitung sind in Hilfsfunktionen ausgelagert;
   auch der uncached Pfad benötigt deshalb noch den Android-Vergleichstest.

Die zusätzlichen Caches tauschen begrenzten Speicher gegen weniger wiederholte
Aufbereitung. Bei vielen ständig neuen Konturen können Schlüsselbildung und
Cache-Verdrängung den Nutzen vermindern. Die Anzahl eigentlicher Canvas-Zeichenaufrufe,
Texturdetails und Touch-Ereignisse wird nicht reduziert.

## Tatsächlich ausgeführte Prüfungen

- Vollständiger Dateivergleich zur extrahierten Referenz: **225 bestehende Dateien
  bytegleich**, nur Renderer und Versionsdatei geändert. Neue Berichts-/Testdateien
  kommen hinzu. Insbesondere UI, DrawingCanvas, gesamte Geometrie/Snapping,
  Persistenz, Bibliotheken und `.github/workflows/android-build.yml` bytegleich.
- Versionsdatei nach Rücksetzen allein der Nummern exakt gleich der Referenz.
- Eingefrorener Test-Renderer entspricht 0.9.46 exakt, abgesehen von Klassennamen
  und dem Namen seiner SVG-Hilfsfunktion.
- Gradle-Verfügbarkeit versucht: `bash project/gradlew --version` scheitert bereits
  am Download von Gradle 8.11.1 mit `Network is unreachable`. Kein Compile-Ergebnis.
- Finale ZIP wird nach dem Verpacken auf CRC-Integrität und auf Bytegleichheit mit
  dem Arbeitsprojekt geprüft.

Wiederholung des Quellvergleichs nach Entpacken beider Projekte:

```sh
python3 tools/check-0947-scope.py /pfad/zur/0946 /pfad/zur/0947
```

## Vorbereitete, hier NICHT ausgeführte Android-Tests

`Renderer0947Test` vergleicht Pixel des alten und neuen Renderers unabhängig:

- Pfade offen/geschlossen, Füllungen, Transparenz, gestrichelte Linien, runde und
  gerade Linienenden, Kreise, verschachtelte Gruppen, Clips und Spiegelung;
- mehrzeilige Texte, Ausrichtung, Hintergrund, Rahmen, Fett/Kursiv und Drehung;
- Bitmap, wiederholte Textur, fehlende Ressource, außerhalb liegendes Asset;
- kalter/warmer Cache, Zoom/Drehung, geänderte Punktliste, geänderter Text/Style,
  Rückkehr zur alten Szene und erzwungene Cache-Verdrängung;
- interaktiver und nichtinteraktiver Renderer.

```sh
./gradlew :export:connectedDebugAndroidTest
```

Der vorhandene `PdfScaleTest` bleibt enthalten und unverändert. Die Pixeltests
benutzen Software-Bitmap-Canvas und ersetzen keine GPU-Prüfung auf dem S25 Ultra.
Der bestehende GitHub-Workflow wurde nicht erweitert; Instrumentationstests werden
nicht allein durch das Hinzufügen dieser Dateien automatisch ausgeführt.

## Praktische Abnahme nach dem GitHub-Actions-Build

Alle folgenden Punkte sind **noch offen**, nicht als bestanden zu verstehen:

| Test | Vergleich mit 0.9.46 |
|---|---|
| Pflanzbeet an Pflaster und Pflanztrog | Gleichzeitiger X-/Y-Fang an zwei Objekten, gleiche Lösegrenze |
| Fassadenrinne an mehreren Kanten | Gleiche Zielkante, Priorität und Einrastposition |
| Alle verwendeten Objekttypen | Verschieben, Drehen, Skalieren und Griffe; keine alten Konturen |
| Lange Pflasterflächen / texturierte Objekte | Fugen, Steinbilder, Schraffuren, vollständige Details beim Drag |
| Bemaßung / Höhenkoten | Inhalt, Position, Rahmen, Größe und Auswahl |
| Pan / Zoom / Auswahl | Schnitt und Draufsicht, auch gedrehte Ansicht |
| Speichern / Laden / Undo / Redo | Änderungen erscheinen unmittelbar und korrekt |
| PDF und Druck | A3/A4, gleiche Maße, Beschriftungen und Texturen |

Für einen reproduzierbaren Vorher/Nachher-Lauf dieselbe Zeichnung, Ansicht,
Zoomstufe, Geräte-Bildwiederholrate und dieselbe Gestenfolge verwenden. Je Version
nach identischem Aufwärmen mehrere 30-Sekunden-Läufe: Pan, Pinch-Zoom, Objekt-Drag,
Griffbearbeitung. System Trace/Profiler zur Messung von Framezeiten (Median, p95,
p99), UI-Thread, CPU, Allokationen und GC verwenden; Recompositions getrennt mit
Compose-Werkzeugen untersuchen. Debug-Messungen nur mit gleichartigen Builds
vergleichen. Snap-Zeit bei Bedarf separat profilieren. Keine Messwerte liegen vor.

**Erwartet:** weniger native Path-/Paint-Erzeugungen, weniger Textvermessung und
weniger temporäre Listen auf warmen Renderpfaden. **Nicht zugesichert:** ein
bestimmter FPS-Gewinn oder vollständige Beseitigung aller Ruckler, insbesondere
bei der unverändert neu erzeugten Drag-Geometrie großer Einzelobjekte.
