package de.baudetail
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.MotionEvent
import de.baudetail.ui.diagnostics.InteractionTrace
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import de.baudetail.ui.*
class MainActivity:ComponentActivity(){
 private val model:BaudetailViewModel by viewModels()
 override fun onCreate(state:Bundle?){super.onCreate(state);enableEdgeToEdge();WindowCompat.getInsetsController(window,window.decorView).apply { hide(WindowInsetsCompat.Type.systemBars());systemBarsBehavior=WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE };setContent{BaudetailRoot(model)};if(state==null)receive(intent)}
 override fun dispatchTouchEvent(ev:MotionEvent):Boolean {
  if(InteractionTrace.enabled && (ev.actionMasked!=MotionEvent.ACTION_MOVE || ev.eventTime % 5L == 0L))
   InteractionTrace.record("android",InteractionTrace.actionName(ev.actionMasked),ev.pointerCount,eventTime=ev.eventTime)
  return super.dispatchTouchEvent(ev)
 }
 override fun onNewIntent(intent:Intent){super.onNewIntent(intent);setIntent(intent);receive(intent)}
 @Suppress("DEPRECATION") private fun receive(intent:Intent?){val uri=if(intent?.action==Intent.ACTION_SEND)intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)else if(intent?.action==Intent.ACTION_VIEW)intent.data else null;uri?.let(model::stagePackage)}
}
