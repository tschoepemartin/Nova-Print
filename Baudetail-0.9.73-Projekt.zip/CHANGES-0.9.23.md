# BauDetail 0.9.23 — erste Geometrie-/Snapping-Korrekturen

- Werkzeug »Zusammenführen« direkt unter »Verschieben«; nur bei mindestens zwei kompatiblen, entsperrten Flächen aktiv.
- Vereinigung über segmentierte Originalkanten, ohne Außenkontur durch ein Bounding-Rectangle zu ersetzen. Bei getrennten Flächen, Löchern und nicht eindeutig verfolgbarer Kontur erfolgt keine Änderung.
- Verbesserte Priorität für Ecken und Schnittpunkte im allgemeinen Snap-Algorithmus.

## Noch nicht umgesetzt
- Referenzgebundene Pflasterverbände mit persistenter Kopplung.
- Allgemeine Korrektur sämtlicher Positionssprünge bei Maßänderungen; hierfür sind die einzelnen Objektfamilien noch systematisch zu prüfen.
- Android-Build und Gerätetest.
