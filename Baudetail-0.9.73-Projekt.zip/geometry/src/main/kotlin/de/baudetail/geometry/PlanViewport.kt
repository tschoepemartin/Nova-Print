package de.baudetail.geometry

/** Single reversible model-mm <-> display-pixel transform for the plan viewport.
 * The view angle rotates only the camera; it never changes stored CAD coordinates.
 */
data class PlanViewport(
 val zoom:Double, val offset:Vec, val angleDegrees:Double, val screenCenter:Vec
) {
 init { require(zoom>0.0 && zoom.isFinite()) }
 fun toScreen(model:Vec):Vec=(model*zoom+offset).rotate(angleDegrees,screenCenter)
 fun toWorld(screen:Vec):Vec=(screen.rotate(-angleDegrees,screenCenter)-offset)*(1.0/zoom)
 /** Convert a screen-space pan delta into the unrotated camera offset. */
 fun panDelta(screenDelta:Vec):Vec=screenDelta.rotate(-angleDegrees)
 /** Preserve the exact model point beneath the fingers during pinch/zoom. */
 fun offsetForAnchor(model:Vec,screen:Vec,newZoom:Double):Vec =
  screen.rotate(-angleDegrees,screenCenter)-model*newZoom
}
