# BauDetail 0.9.35

- Baum- und Strauchkronen in Draufsicht oberhalb sämtlicher Bauobjekte, unabhängig von Ebene und manueller Ebenenreihenfolge.
- Untereinander werden Baumkronen anhand Oberkante = Basis-Kote + Pflanzenhöhe sortiert. Pflanzenhöhe aus plantHeightCm (Bereich: oberer Wert) oder plantHeightMm als Fallback.
- Pflanzung anpassen: Sichtbarkeit 0–100 Prozent. Opazität wird auf alle Kronen-/Ast-/Kontur-/Beschriftungsprimitiven angewendet und am Objekt gespeichert.

Nicht auf Android kompiliert oder am Gerät geprüft.
