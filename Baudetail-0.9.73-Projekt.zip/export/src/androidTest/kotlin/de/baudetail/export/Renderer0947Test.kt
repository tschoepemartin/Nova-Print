package de.baudetail.export

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import de.baudetail.core.*
import de.baudetail.geometry.*
import java.io.File
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

/** Independent 0.9.46 renderer versus 0.9.47, including warmed and replaced keys.
 * Run on Android: ./gradlew :export:connectedDebugAndroidTest
 * This is deliberately a pixel comparison, not a timing assertion.
 */
@RunWith(AndroidJUnit4::class)
class Renderer0947Test {
 private fun fixtures(points:List<Vec>,revision:Int=0):List<Primitive> {
  val style=Style(stroke="#263A49",fill="#91BE7A",widthMm=1.7,
   dashed=revision%2==0,opacity=.73,bold=revision%2==1,italic=true,
   background="#FFFFFF",frame=true,align=if(revision%2==0)"center" else "right")
  return listOf(
   Primitive.Path(points,true,style),Primitive.Path(points,false,style.copy(fill=null,align="cut-butt")),
   Primitive.Circle(Vec(180.0,75.0),28.0,style),
   Primitive.Group(listOf(Primitive.Path(points,true,style),
    Primitive.Text(Vec(75.0,55.0),"Maß $revision\n−12,5 mm",14.0+revision,style,17.0)),
    translate=Vec(90.0,90.0),scale=.75,angle=23.0,clip=points,mirrorY=revision%2==1),
   Primitive.Text(Vec(170.0,220.0),"Höhe $revision\n",16.0,style,-9.0),
   Primitive.Asset(Vec(220.0,20.0),80.0,80.0,"tile.png",.6,12.0),
   Primitive.Asset(Vec(20.0,240.0),220.0,50.0,"repeat:35:tile.png"),
   Primitive.Asset(Vec(5000.0,5000.0),80.0,80.0,"missing.png"),
   Primitive.Asset(Vec(280.0,240.0),80.0,50.0,"missing.png")
  )
 }
 @Test fun exactPixelsBeforeAndAfterCacheWarmupEditsAndEviction() {
  val dir=File(InstrumentationRegistry.getInstrumentation().targetContext.cacheDir,"renderer0947").apply{mkdirs()}
  val tile=Bitmap.createBitmap(8,8,Bitmap.Config.ARGB_8888)
  for(y in 0 until 8)for(x in 0 until 8)tile.setPixel(x,y,if((x+y)%2==0)Color.BLUE else Color.YELLOW)
  File(dir,"tile.png").outputStream().use{tile.compress(Bitmap.CompressFormat.PNG,100,it)};tile.recycle()
  for(interactive in listOf(true,false)) {
   val reference=ReferenceCanvasRenderer0946({File(dir,it)},interactive)
   val optimized=CanvasRenderer({File(dir,it)},interactive)
   fun compare(nodes:List<Primitive>,zoom:Float,angle:Float) {
    fun render(draw:(Canvas)->Unit):Bitmap {
     val bmp=Bitmap.createBitmap(480,480,Bitmap.Config.ARGB_8888)
     bmp.eraseColor(Color.WHITE)
     val canvas=Canvas(bmp);canvas.translate(17f,23f);canvas.rotate(angle,240f,240f);canvas.scale(zoom,zoom)
     draw(canvas);return bmp
    }
    val before=render{reference.draw(it,nodes,angle)}
    val after=render{optimized.draw(it,nodes,angle)}
    try{assertTrue("pixels differ: interactive=$interactive zoom=$zoom angle=$angle",before.sameAs(after))}
    finally{before.recycle();after.recycle()}
   }
   val points=mutableListOf(Vec(15.0,20.0),Vec(140.0,20.0),Vec(130.0,110.0),Vec(15.0,110.0))
   val initial=fixtures(points)
   repeat(3){for(zoom in listOf(.25f,1f,1.7f))for(angle in listOf(0f,37f))compare(initial,zoom,angle)}
   // Deliberately exercise mutable input too: the cached key owns a snapshot.
   points[1]=Vec(165.0,35.0)
   compare(initial,1f,0f)
   compare(fixtures(points,1),1f,37f)
   compare(initial,1f,0f) // Undo / switching back to a prior scene.
   // Force path, paint and text eviction, then return to the original scene.
   val churn=(0 until 8500).flatMap{i->listOf(
    Primitive.Path(listOf(Vec(i.toDouble(),5.0),Vec(i+1.0,8.0)),style=Style(widthMm=.1+i*.001)),
    Primitive.Text(Vec(10.0,10.0),"cache-$i",10.0))}
   compare(churn,1f,0f)
   compare(initial,1f,0f)
  }
  dir.deleteRecursively()
 }
}
