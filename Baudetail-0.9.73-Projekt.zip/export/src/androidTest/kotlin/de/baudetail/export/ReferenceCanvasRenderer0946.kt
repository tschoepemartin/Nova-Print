package de.baudetail.export

import android.graphics.*
import com.caverock.androidsvg.SVG
import de.baudetail.core.*
import de.baudetail.geometry.*
import java.io.File

internal class ReferenceCanvasRenderer0946(private val asset:(String)->File, private val interactive:Boolean=false) {
 private val bitmaps=object:android.util.LruCache<String,Bitmap>(if(interactive) 64*1024*1024 else 32*1024*1024){override fun sizeOf(key:String,value:Bitmap)=value.allocationByteCount}
 private val vectors=android.util.LruCache<String,SVG>(64)
 // Cached reduced resolutions prevent aliasing and moire at distant zooms.
 private val mipmaps=object:android.util.LruCache<String,Bitmap>(16*1024*1024){override fun sizeOf(key:String,value:Bitmap)=value.allocationByteCount}
 private fun color(s:String)=runCatching{Color.parseColor(s)}.getOrDefault(Color.DKGRAY)
 private fun paint(style:Style,fill:Boolean=false)=Paint(Paint.ANTI_ALIAS_FLAG).apply {
  this.style=if(fill) Paint.Style.FILL else Paint.Style.STROKE
  color=color(if(fill)style.fill?:style.stroke else style.stroke);alpha=(style.opacity*255).toInt();strokeWidth=style.widthMm.toFloat();strokeJoin=Paint.Join.ROUND;strokeCap=if(style.align=="cut-butt")Paint.Cap.BUTT else Paint.Cap.ROUND
  if(style.dashed&&!fill)pathEffect=DashPathEffect(floatArrayOf(strokeWidth*7,strokeWidth*5),0f)
 }
 private fun path(points:List<Vec>,closed:Boolean)=Path().apply {points.firstOrNull()?.let {moveTo(it.x.toFloat(),it.y.toFloat())};points.drop(1).forEach{lineTo(it.x.toFloat(),it.y.toFloat())};if(closed)close()}
 fun draw(canvas:Canvas,nodes:List<Primitive>,uprightAngle:Float=0f) {nodes.forEach {n-> when(n) {
  is Primitive.Group -> {canvas.save();n.clip?.let {canvas.clipPath(path(it,true))};canvas.translate(n.translate.x.toFloat(),n.translate.y.toFloat());canvas.rotate(n.angle.toFloat());canvas.scale(n.scale.toFloat(),n.scale.toFloat()*(if(n.mirrorY)-1f else 1f));draw(canvas,n.nodes,uprightAngle);canvas.restore()}
  is Primitive.Path -> {val p=path(n.points,n.closed);if(n.closed&&n.style.fill!=null)canvas.drawPath(p,paint(n.style,true));canvas.drawPath(p,paint(n.style))}
  is Primitive.Circle -> {if(n.style.fill!=null)canvas.drawCircle(n.center.x.toFloat(),n.center.y.toFloat(),n.radius.toFloat(),paint(n.style,true));canvas.drawCircle(n.center.x.toFloat(),n.center.y.toFloat(),n.radius.toFloat(),paint(n.style))}
  is Primitive.Text -> {
   val pen=paint(n.style,true).apply {color=color(n.style.stroke);textSize=n.size.toFloat();typeface=Typeface.create(Typeface.SANS_SERIF,if(n.style.bold&&n.style.italic)Typeface.BOLD_ITALIC else if(n.style.bold)Typeface.BOLD else if(n.style.italic)Typeface.ITALIC else Typeface.NORMAL);textAlign=when(n.style.align){"center"->Paint.Align.CENTER;"right"->Paint.Align.RIGHT;else->Paint.Align.LEFT}}
   canvas.save();canvas.rotate(n.angle.toFloat()-uprightAngle,n.at.x.toFloat(),n.at.y.toFloat());val lines=n.value.lines();val w=lines.maxOfOrNull {pen.measureText(it)}?:0f
   val x=n.at.x.toFloat();val y=n.at.y.toFloat();val left=x-when(pen.textAlign){Paint.Align.CENTER->w/2;Paint.Align.RIGHT->w;else->0f}
   val box=RectF(left-n.size.toFloat()/3,y-n.size.toFloat(),left+w+n.size.toFloat()/3,y+(lines.size-1)*n.size.toFloat()*1.35f+n.size.toFloat()/3)
   n.style.background?.let {canvas.drawRect(box,Paint().apply{color=color(it)})};if(n.style.frame)canvas.drawRect(box,paint(n.style))
   lines.forEachIndexed {i,line->canvas.drawText(line,x,y+i*n.size.toFloat()*1.35f,pen)};canvas.restore()
  }
  is Primitive.Asset -> {
   canvas.save();canvas.translate(n.at.x.toFloat(),n.at.y.toFloat());canvas.rotate(n.angle.toFloat());val rect=RectF(0f,0f,n.width.toFloat(),n.height.toFloat())
   // Skip off-screen tiles before disk access or decoding. Canvas carries the viewport clip.
   if(interactive && canvas.quickReject(rect)) { canvas.restore();return@forEach }
   runCatching {
    val repeated=n.path.startsWith("repeat:")
    val repeatSpec=if(repeated)n.path.removePrefix("repeat:").split(":",limit=2)else emptyList()
    val tileMm=if(repeated)repeatSpec.firstOrNull()?.toFloatOrNull()?.coerceAtLeast(20f)?:350f else 0f
    val sourcePath=if(repeated)repeatSpec.getOrNull(1)?:"" else n.path
    val f=asset(sourcePath);require(f.isFile){"Datei fehlt"}
    if(f.extension.lowercase()=="svg" && !repeated) {
     val svg=vectors[n.path]?:SVG.getFromString(sanitizeSvg0946(f.readText())).also{vectors.put(n.path,it)}
     val layer=canvas.saveLayerAlpha(rect,(n.opacity*255).toInt());svg.renderToCanvas(canvas,rect);canvas.restoreToCount(layer)
    } else {
     val bmp=bitmaps[sourcePath]?:run {
      // Screen preview needs fewer source pixels than print/PDF. Decode once,
      // retain in an LRU; never decode full-res tiles during every gesture.
      val opts=BitmapFactory.Options().apply {
       inPreferredConfig=Bitmap.Config.RGB_565
       if(interactive && n.path.startsWith("grass-textures/")) inSampleSize=2
      }
      BitmapFactory.decodeFile(f.path,opts)?.also{bitmaps.put(sourcePath,it)}
     }?:error("Bild nicht lesbar")
     if(repeated){
      // One draw call irrespective of area size. Filtered mip levels are
      // reused while pinch-zooming; no bitmap creation in the hot path.
      val matrix=Matrix();canvas.getMatrix(matrix)
      val values=FloatArray(9);matrix.getValues(values)
      val pxPerMm=kotlin.math.hypot(values[Matrix.MSCALE_X].toDouble(),values[Matrix.MSKEW_Y].toDouble()).coerceAtLeast(0.00001)
      val desired=(tileMm*pxPerMm).toInt().coerceAtLeast(1)
      val downsample=if(!interactive)1 else {
       var sample=1
       while(bmp.width/sample>desired*2 && sample<64)sample*=2
       sample
      }
      val image=if(downsample==1)bmp else {
       val key="$sourcePath#$downsample"
       mipmaps[key]?:Bitmap.createScaledBitmap(bmp,(bmp.width/downsample).coerceAtLeast(1),(bmp.height/downsample).coerceAtLeast(1),true).also{mipmaps.put(key,it)}
      }
      val shader=BitmapShader(image,Shader.TileMode.REPEAT,Shader.TileMode.REPEAT)
      val transform=Matrix().apply{setScale(tileMm/image.width,tileMm/image.height);postTranslate(-n.at.x.toFloat(),-n.at.y.toFloat())}
      shader.setLocalMatrix(transform)
      canvas.drawRect(rect,Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG).apply{alpha=(n.opacity*255).toInt();this.shader=shader})
     }else canvas.drawBitmap(bmp,null,rect,Paint(Paint.ANTI_ALIAS_FLAG).apply{alpha=(n.opacity*255).toInt();isFilterBitmap=true})
    }
   }.onFailure {canvas.drawRect(rect,Paint().apply{color=Color.LTGRAY});canvas.drawText("Ressource fehlt / ungültig",8f,24f,Paint().apply{color=Color.RED;textSize=16f})}
   canvas.restore()
  }
 }}}
}
/** Declarative SVG only: block active content and external resources before AndroidSVG/XML parsing. */
fun sanitizeSvg0946(source:String):String {
 require(source.length<=8*1024*1024){"SVG zu groß"}
 require(!Regex("<!DOCTYPE|<!ENTITY|<script|<foreignObject|<image|\\son[a-z]+\\s*=|@import|url\\(\\s*['\"]?(?!#)",RegexOption.IGNORE_CASE).containsMatchIn(source)){"SVG enthält nicht unterstützte aktive oder externe Inhalte"}
 require(!Regex("(?:href|src)\\s*=\\s*['\"](?!#)",RegexOption.IGNORE_CASE).containsMatchIn(source)){"Externe SVG-Verweise sind nicht erlaubt"}
 require(source.contains("<svg",true)){"Keine SVG-Datei"};return source
}
