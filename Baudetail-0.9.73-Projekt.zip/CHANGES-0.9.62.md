# BauDetail 0.9.62 – Diagnoseprotokoll erweitert

- Gemeinsame monotone Zeitbasis für Touch- und Performance-Ereignisse (SystemClock.uptimeMillis).
- Zusätzliche chronologisch sortierte Ereignis-Zeitachse im CSV-Export.
- Automatische Kennzeichnung von Android-Eingabeverzögerungen ab 250 ms.
- Berührungsereignisse in beiden horizontalen Werkzeugleisten erfasst (Down, Scroll, Up).
- Android-MOVE-Ereignisse sparsam mitprotokolliert, ohne Koordinaten.
- Weiterhin keine Projektdaten oder Fingerpositionen im Export.
- Noch kein Build und keine Gerätevalidierung durchgeführt.
