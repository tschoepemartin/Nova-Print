# BauDetail 0.9.69

- Eigener Anpassen-Dialog für alle Objekte der Familie `curb` (Bordstein/Leistenstein), statt einer nur anhand des Namens sichtbaren Inline-Steuerung.
- Steinart/Sorte, Material, Einzelsteinlänge, Draufsichtbreite, Querschnittbreite und -höhe, Fase und Fasenmaße editierbar.
- Reihenoption und numerische Gesamtlänge, Anfangs-/Endzuschnitt nur bei aktivierter Reihe.
- Im Bearbeiten-Modus bei aktiver Reihe zusätzliche Endkanten-Griffe mit Fang an vorhandenen Objekten.
- Sichtbare Umrissgeometrie in Draufsicht berücksichtigt die Endzuschnitte.
- Kein lokaler Android-Build möglich; GitHub Actions muss kompilieren und die Funktion auf dem Gerät geprüft werden.
