# BauDetail 0.9.51 – Render-Performance

- Cache fuer native Pfadgrenzen: keine wiederholte computeBounds-Berechnung fuer unveraenderte Pfade.
- Cache fuer BitmapShader/Matrix/Paint bei wiederholten Texturkacheln (inkl. Aufloesungsstufe, Position, Deckkraft).
- LRU begrenzt auf 256 Kacheleintraege; keine Aenderung der Geometrie, der Texturkoordinaten, des Snappings oder des Druckpfads.
- Performance-Diagnose aus 0.9.50 bleibt erhalten.
- Android-Build muss ueber GitHub Actions validiert werden.
