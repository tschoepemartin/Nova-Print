package de.baudetail.format
import de.baudetail.core.*
import kotlinx.serialization.json.*
import org.junit.Assert.*
import org.junit.Test
class RecoveryTest {
 @Test fun brokenObjectDoesNotDestroyOtherGeometry(){
  val raw=BaudetailJson.parseToJsonElement("""{"entities":[{"kind":"text","text":null,"points":null,"style":{"textPaperMm":-3}},{"kind":"line","points":[{"x":0,"y":0},{"x":100,"y":0}]},{"kind":"text","points":"broken"}]}""")
  val result=recoverDocument(raw);val d=BaudetailJson.decodeFromJsonElement<Drawing>(result.value)
  assertEquals(2,d.entities.size);assertTrue(result.repaired>=2);validateDrawing(d)
 }
 @Test fun propertySurvivesRecoveryWithExactVerticesAndParameters(){
  val original=Entity(kind="property",name="Grundstück",points=listOf(
   de.baudetail.geometry.Vec(0.0,0.0),de.baudetail.geometry.Vec(22860.0,0.0),
   de.baudetail.geometry.Vec(22860.0,55530.0),de.baudetail.geometry.Vec(0.0,45590.0)),
   params=buildJsonObject {put("propertySideA",22860.0);put("propertyAngleA",90.0);put("propertyLockedA",true)})
  val drawing=Drawing(entities=listOf(original))
  val raw=BaudetailJson.encodeToJsonElement(drawing)
  val recovered=recoverDocument(raw)
  val restored=BaudetailJson.decodeFromJsonElement<Drawing>(recovered.value)
  assertEquals(0,recovered.repaired)
  assertEquals(1,restored.entities.size)
  assertEquals(original,restored.entities.single())
  val again=recoverDocument(BaudetailJson.encodeToJsonElement(restored))
  assertEquals(original,BaudetailJson.decodeFromJsonElement<Drawing>(again.value).entities.single())
 }
}
