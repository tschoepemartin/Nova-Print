package de.baudetail.format

import de.baudetail.core.*
import kotlinx.serialization.json.*
import org.junit.Assert.*
import org.junit.Test

class FoundationRecovery0829Test {
 @Test fun foundationIsNotDroppedByRecovery() {
  val f=Entity(kind="foundation",params=buildJsonObject { put("sourceId","stair1");put("thicknessMm",250.0);put("foundationType","with_wedge") })
  val d=Drawing(entities=listOf(f))
  val source=buildJsonObject { put("entities",BaudetailJson.encodeToJsonElement(d.entities)) }
  val result=recoverDocument(source)
  val objects=(result.value as JsonObject)["entities"] as JsonArray
  assertEquals(1,objects.size)
  val restored=BaudetailJson.decodeFromJsonElement<List<Entity>>(objects)
  assertEquals("foundation",restored.single().kind)
  assertEquals("stair1",restored.single().str("sourceId"))
  assertEquals(250.0,restored.single().num("thicknessMm"),0.001)
 }
}
