# BauDetail 0.9.61 – Automatischer Diagnosemodus

- Unter Diagnose ein einziger Schalter für die automatische Sitzung statt einzelner Testfälle.
- Android-Touchereignisse mit Fingeranzahl und Eingabewartezeit werden erfasst.
- Canvas-Ereignisse werden als Ansicht verschieben, Zwei-Finger-Zoom/Pan, Objekt verschieben oder Zeichnen/Auswahl eingeordnet.
- Vorhandene Performance-Messungen werden automatisch parallel gestartet und im Export ergänzt.
- Export einer CSV-Datei über den Android-Systemdialog. Keine Berührungskoordinaten, Zeichnungsinhalte oder Namen.
- Aufzeichnung begrenzt auf 30.000 Ereignisse, MOVE-Ereignisse ausgedünnt.
- Noch nicht auf einem Android-Gerät getestet; die tatsächliche Ursache der Blockierung ist noch nicht nachgewiesen.
