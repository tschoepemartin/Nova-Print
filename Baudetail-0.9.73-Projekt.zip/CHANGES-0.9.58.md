# BauDetail 0.9.58 – Grundstück-Datenverlust und UI-Reaktionszeit

- **Kritischer Datenverlust behoben:** Die Recovery-Whitelist akzeptiert jetzt `property`. Bisher wurden korrekt gespeicherte Grundstücksgrenzen beim Laden als unbekannter Objekttyp entfernt. `plan-height` wird ebenfalls akzeptiert.
- Regressionstest: Grundstück mit vier Eckpunkten und numerischen Parametern über Recovery und erneuten Speichern/Laden-Durchgang unverändert erhalten.
- **UI-Performance:** Der Canvas meldet Koordinaten und Zoom nicht mehr bei jedem einzelnen `ACTION_MOVE` an den übergeordneten `DrawingScreen`. Damit entfällt die unnötige Neuzusammensetzung der gesamten Oberfläche einschließlich Werkzeugleisten während der Bewegung. Koordinaten werden beim Abschluss der Geste aktualisiert.
- Ausgangspunkt: 0.9.56 Testfix, ohne den langsameren RenderNode-Umbau aus 0.9.57.
- Grenzen: Noch keine Android-Geräte-Benchmarks; keine Garantie, dass alle verbleibenden mehrsekündigen Renderblockaden beseitigt sind.
