# BauDetail 0.9.39

- Rechteckige Hecken werden über ihre gesamte Grundfläche zuverlässig getroffen, einschließlich der letzten Polygonkante.
- Orange Auswahlkontur folgt der Heckenaußenkante.
- Kontur-Bearbeiten ermöglicht vier achsengeführte Kanten; einzelne Eckpunkte bleiben bei rechteckigen Hecken gesperrt, damit keine schrägen Formen entstehen.
- Der bestehende Maßpfeil samt numerischer Abstandsänderung funktioniert auch für Hecken; die Breitenangabe wird synchronisiert.
- Bestehende Darstellung und Pflanzenparameter bleiben erhalten.

Prüfung: Quellcode bearbeitet; Android-Build nicht durchgeführt.
