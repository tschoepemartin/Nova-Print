# BauDetail 0.9.64 – Bildschirm-LOD für sehr kleine Muster

- Bildschirm-Renderer überspringt ausschließlich vollständig subpixelgroße, ungefüllte geschlossene Konturen und einzelne Material-Swatches.
- Originale Geometrie, Scene, Snapping, Bibliothek, Maßstäbe und PDF-/Druck-Renderer bleiben unverändert.
- LOD-Schwellwert 0,7 Pixel; keine Änderung an sichtbaren größeren Konturen.
- Android Build und Gerätetest ausstehend.
