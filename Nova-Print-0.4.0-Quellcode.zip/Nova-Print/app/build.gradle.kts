plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android { namespace = "de.novaprint.app"; compileSdk = 35
 defaultConfig { applicationId = "de.novaprint.app"; minSdk = 26; targetSdk = 35; versionCode = 40; versionName = "0.4.0" }
 compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
 signingConfigs {
  create("novaDebug") {
   storeFile = file("nova-debug.jks")
   storePassword = "nova-print-development"
   keyAlias = "nova-print"
   keyPassword = "nova-print-development"
  }
 }
 buildTypes { getByName("debug") { signingConfig = signingConfigs.getByName("novaDebug") } }
 kotlinOptions { jvmTarget = "17" }
}
