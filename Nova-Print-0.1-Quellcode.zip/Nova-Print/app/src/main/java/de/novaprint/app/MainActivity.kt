package de.novaprint.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.view.View
import android.widget.*
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var host: EditText
    private lateinit var path: EditText
    private lateinit var paper: Spinner
    private lateinit var quality: Spinner
    private lateinit var color: Spinner
    private lateinit var duplex: Spinner
    private lateinit var source: Spinner
    private lateinit var copies: EditText
    private var document: Uri? = null
    private var pdfWidth = 0f
    private var pdfHeight = 0f
    private var supportedPdf = false
    private var discovered = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28, 22, 28, 22) }
        val scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)
        root.addView(TextView(this).apply { text = "Nova-Print"; textSize = 28f })
        root.addView(TextView(this).apply { text = "PDF-Druck ohne App-Skalierung · Vorabversion 0.1" })
        fun edit(label: String, value: String): EditText {
            root.addView(TextView(this).apply { text = label })
            return EditText(this).apply { setText(value); root.addView(this) }
        }
        fun spin(label: String, entries: List<String>): Spinner {
            root.addView(TextView(this).apply { text = label })
            return Spinner(this).apply { adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, entries); root.addView(this) }
        }
        host = edit("Drucker-IP", "192.168.178.50")
        path = edit("IPP-Pfad (ggf. ändern)", "/ipp/print")
        val choose = Button(this).apply { text = "PDF auswählen"; setOnClickListener {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "application/pdf"; addCategory(Intent.CATEGORY_OPENABLE) }, 10)
        } }
        root.addView(choose)
        paper = spin("Papierformat", listOf("Automatisch", "A4", "A3"))
        quality = spin("Qualität", listOf("Normal", "Entwurf", "Hoch"))
        color = spin("Farbe", listOf("Farbe", "Schwarzweiß"))
        duplex = spin("Duplex", listOf("Einseitig", "Lange Kante", "Kurze Kante"))
        source = spin("Papierzufuhr", listOf("Automatisch", "Kassette 1", "Kassette 2", "Hinterer Einzug"))
        copies = edit("Exemplare", "1")
        root.addView(Button(this).apply { text = "Druckerfunktionen abfragen"; setOnClickListener { probe() } })
        root.addView(Button(this).apply { text = "PDF 100 % drucken"; setOnClickListener { printPdf() } })
        status = TextView(this).apply { text = "Bitte PDF auswählen und Drucker abfragen."; setPadding(0, 20, 0, 10); textIsSelectable = true }
        root.addView(status)
        accept(intent)
    }

    @Deprecated("Legacy picker callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 10 && resultCode == RESULT_OK) data?.data?.let { setDocument(it) }
    }
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); accept(intent) }
    private fun accept(i: Intent?) {
        val uri = when (i?.action) {
            Intent.ACTION_SEND -> if (android.os.Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java) else @Suppress("DEPRECATION") i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
            Intent.ACTION_VIEW -> i.data
            else -> null
        }
        if (uri != null) setDocument(uri)
    }
    private fun setDocument(uri: Uri) {
        document = uri
        try {
            contentResolver.openFileDescriptor(uri, "r")!!.use { fd ->
                PdfRenderer(fd).use { renderer ->
                    val p = renderer.openPage(0)
                    pdfWidth = p.width.toFloat(); pdfHeight = p.height.toFloat(); p.close()
                    update("PDF geladen: ${renderer.pageCount} Seite(n), erste Seite ca. ${pdfWidth} × ${pdfHeight} pt. Originaldatei bleibt unverändert.")
                }
            }
        } catch (e: Exception) { update("PDF-Metadaten konnten nicht gelesen werden: ${e.message}") }
    }
    private fun update(msg: String) { runOnUiThread { status.text = msg } }
    private fun endpoint() = "http://${host.text.toString().trim()}:631${path.text.toString().trim().let { if (it.startsWith('/')) it else "/$it" }}"
    private fun probe() {
        update("Frage IPP-Funktionen ab …")
        thread {
            try {
                val response = ippRequest(0x000B, null, emptyList())
                val parsed = parseAttributes(response)
                discovered = parsed
                supportedPdf = parsed.contains("application/pdf", true)
                update("IPP-Antwort:\n$parsed\n\nPDF-Direktdruck: ${if (supportedPdf) "vom Drucker gemeldet" else "NICHT bestätigt"}.\nPapierformat/-quelle werden nur angezeigt, wenn IPP sie liefert.")
            } catch (e: Exception) { supportedPdf = false; update("IPP-Abfrage fehlgeschlagen: ${e.message}\nPrüfe IP-Adresse, IPP-Pfad und WLAN.") }
        }
    }
    private fun printPdf() {
        val uri = document ?: return update("Bitte zuerst ein PDF auswählen.")
        if (!supportedPdf) return update("Druck gestoppt: Direkter PDF-Druck über IPP wurde noch nicht bestätigt. Erst Druckerfunktionen abfragen. Keine automatische Verkleinerung als Ersatz.")
        update("Übertrage PDF unverändert per IPP …")
        val selectedPaper = paper.selectedItemPosition
        val selectedQuality = quality.selectedItemPosition
        val selectedColor = color.selectedItemPosition
        val selectedDuplex = duplex.selectedItemPosition
        val selectedSource = source.selectedItemPosition
        val n = copies.text.toString().toIntOrNull()?.coerceIn(1, 99) ?: 1
        thread {
            try {
                val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                if (bytes.size < 5 || String(bytes.copyOfRange(0, 5)) != "%PDF-") throw IllegalArgumentException("Keine gültige PDF-Datei")
                val attrs = mutableListOf<Triple<Int, String, Any>>()
                attrs += Triple(0x49, "document-format", "application/pdf")
                attrs += Triple(0x44, "print-color-mode", if (selectedColor == 0) "color" else "monochrome")
                attrs += Triple(0x44, "sides", when (selectedDuplex) { 1 -> "two-sided-long-edge"; 2 -> "two-sided-short-edge"; else -> "one-sided" })
                attrs += Triple(0x23, "print-quality", when (selectedQuality) { 1 -> 3; 2 -> 5; else -> 4 })
                attrs += Triple(0x21, "copies", n)
                val media = when (selectedPaper) { 1 -> "iso_a4_210x297mm"; 2 -> "iso_a3_297x420mm"; else -> if (pdfWidth > 650 || pdfHeight > 900) "iso_a3_297x420mm" else "iso_a4_210x297mm" }
                attrs += Triple(0x44, "media", media)
                if (selectedSource != 0) attrs += Triple(0x44, "media-source", when (selectedSource) { 1 -> "tray-1"; 2 -> "tray-2"; else -> "manual" })
                val response = ippRequest(0x0002, bytes, attrs)
                val code = ((response[2].toInt() and 255) shl 8) or (response[3].toInt() and 255)
                update(if (code < 0x0100) "Druckauftrag vom Drucker angenommen (IPP 0x${code.toString(16)}). PDF wurde unverändert übertragen. Maßhaltigkeit bitte am vorhandenen Plan prüfen." else "Drucker hat Auftrag abgelehnt: IPP 0x${code.toString(16)}\n${parseAttributes(response)}")
            } catch (e: Exception) { update("Druck fehlgeschlagen: ${e.message}") }
        }
    }
    private fun ippRequest(operation: Int, pdf: ByteArray?, jobAttrs: List<Triple<Int, String, Any>>): ByteArray {
        val out = ByteArrayOutputStream()
        fun byte(v: Int) { out.write(v and 255) }
        fun short(v: Int) { byte(v shr 8); byte(v) }
        fun integer(v: Int) { byte(v shr 24); byte(v shr 16); byte(v shr 8); byte(v) }
        fun attr(tag: Int, name: String, value: Any) {
            val key = name.toByteArray(Charsets.UTF_8)
            val data = if (value is Int) ByteBuffer.allocate(4).order(ByteOrder.BIG_ENDIAN).putInt(value).array() else value.toString().toByteArray(Charsets.UTF_8)
            byte(tag); short(key.size); out.write(key); short(data.size); out.write(data)
        }
        short(0x0200); short(operation); integer(1)
        byte(0x01)
        attr(0x47, "attributes-charset", "utf-8")
        attr(0x48, "attributes-natural-language", "en")
        attr(0x45, "printer-uri", "ipp://${host.text.toString().trim()}:631${path.text.toString().trim().let { if (it.startsWith('/')) it else "/$it" }}")
        if (operation == 0x000B) attr(0x44, "requested-attributes", "all")
        if (operation == 0x0002) { attr(0x42, "requesting-user-name", "Nova-Print"); attr(0x42, "job-name", "Nova-Print PDF"); byte(0x02); jobAttrs.forEach { (t, n, v) -> attr(t, n, v) } }
        byte(0x03)
        if (pdf != null) out.write(pdf)
        val conn = URL(endpoint()).openConnection() as HttpURLConnection
        conn.requestMethod = "POST"; conn.connectTimeout = 6000; conn.readTimeout = 30000
        conn.setRequestProperty("Content-Type", "application/ipp")
        conn.doOutput = true
        conn.outputStream.use { it.write(out.toByteArray()) }
        val result = (if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream).use { it.readBytes() }
        conn.disconnect()
        if (result.size < 8) throw IllegalStateException("Ungültige IPP-Antwort")
        return result
    }
    private fun parseAttributes(bytes: ByteArray): String {
        val sb = StringBuilder(); var i = 8; var name = ""; var count = 0
        while (i < bytes.size && count < 350) {
            val tag = bytes[i++].toInt() and 255
            if (tag == 3) break
            if (tag <= 0x0f) continue
            if (i + 4 > bytes.size) break
            val nl = ((bytes[i].toInt() and 255) shl 8) or (bytes[i+1].toInt() and 255); i += 2
            if (i + nl + 2 > bytes.size) break
            if (nl > 0) name = String(bytes, i, nl, Charsets.UTF_8)
            i += nl
            val vl = ((bytes[i].toInt() and 255) shl 8) or (bytes[i+1].toInt() and 255); i += 2
            if (i + vl > bytes.size) break
            val v = if (tag == 0x21 || tag == 0x23) { if (vl == 4) ByteBuffer.wrap(bytes, i, 4).order(ByteOrder.BIG_ENDIAN).int.toString() else "(Zahl)" } else String(bytes, i, vl, Charsets.UTF_8).filter { it >= ' ' }.take(160)
            i += vl; count++
            if (name.contains("document-format") || name.contains("media") || name.contains("tray") || name.contains("supply") || name.contains("printer-state") || name.contains("print-quality") || name.contains("color") || name.contains("sides") || name.contains("resolution")) sb.append(name).append(": ").append(v).append('\n')
        }
        return if (sb.isEmpty()) "Keine auswertbaren relevanten Attribute erhalten." else sb.toString().take(14000)
    }
}
