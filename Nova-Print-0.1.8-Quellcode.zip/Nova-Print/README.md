# Nova-Print 0.1.6

- Überarbeitete Android-Oberfläche mit Druckerkarten und blauem App-Icon
- WLAN-Suche IPP/IPPS, Duplikate pro IP zusammengefasst
- IPPS-Zertifikat mit SHA-256-Fingerabdruck beim Hinzufügen bestätigen
- Zertifikat pro Drucker speichern und bei Folgezugriffen vergleichen
- Bestehende PDF-Direktdruckfunktionen
- Identische Entwicklungssignatur wie 0.1.5

Build und tatsächliche Druckerverbindung noch nicht getestet.

## 0.1.8
Mehrseitige PDF-Vorschau mit Seitenwechsel, Vollbildansicht und Live-Skalierungsanzeige. Randlos nur bei gemeldeter Druckerunterstützung. Druckerinterne Randlos-Vergrößerung und 100%-Maßhaltigkeit sind nicht garantiert; am Gerät testen.
