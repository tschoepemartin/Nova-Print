# Nova-Print 0.1 – Android-Prototyp

Ein minimales Android-Projekt für direkten PDF-Druck per IPP auf den Epson WF-7830DTWF.

## APK erstellen
1. Repository auf GitHub erstellen und den **Inhalt** dieses ZIP ins Repository laden.
2. In GitHub `Actions` → `Android APK` → `Run workflow` wählen.
3. Nach erfolgreichem Build unter `Artifacts` die `Nova-Print-debug-apk` herunterladen und die APK installieren.

## Was funktioniert / was noch nicht
- PDF über Android-Dateiauswahl oder Teilen empfangen.
- Drucker-IP und IPP-Pfad editierbar; IPP-Get-Printer-Attributes zeigt gemeldete Fähigkeiten, darunter Papierformate/-quellen, falls vorhanden.
- Direkter IPP-PDF-Print-Job mit Papierformat, Qualität, Farbe, Duplex, Quelle und Exemplaren. Original-PDF wird unverändert übertragen.
- Kein Android-Druckdialog, kein PDF-Rendering/Skalieren.
- **Ungetestet am echten Epson**: Der Drucker muss `application/pdf` als `document-format-supported` melden. Wenn nicht, verweigert die App den Druck bewusst. Epson-spezifische IPP-Endpunkte können abweichen.
- **Keine verifizierte automatische Kassettenerkennung**: Es werden nur Attribute angezeigt, die der Drucker liefert. Eine zuverlässige Anzeige pro Kassette und Tintenfüllstände ist noch nicht umgesetzt.
- IPP-Antwort-Parsing ist minimal; Prototyp, nicht produktionsreif.
- `media-source`-Werte sind generisch und müssen anhand der vom Gerät gemeldeten unterstützten Werte validiert werden.
- 100-%-Maßhaltigkeit muss anhand eines physischen Testdrucks geprüft werden; unveränderte PDF-Bytes garantieren keine maßhaltige Interpretation durch Druckerfirmware.
- Unverschlüsseltes IPP über das lokale WLAN; nicht über das öffentliche Internet freigeben.
