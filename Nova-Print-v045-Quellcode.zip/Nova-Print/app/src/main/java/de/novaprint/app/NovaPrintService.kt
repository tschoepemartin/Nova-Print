package de.novaprint.app

import android.print.PrintAttributes
import android.print.PrinterCapabilitiesInfo
import android.print.PrinterId
import android.print.PrinterInfo
import android.printservice.PrintJob
import android.printservice.PrintService
import android.printservice.PrinterDiscoverySession
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.pdf.PdfRenderer
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import org.json.JSONArray
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicInteger
import kotlin.concurrent.thread

/** Android framework printing entry point. Uses the same PWG raster and IPP codec as the app. */
class NovaPrintService : PrintService() {
    private data class Device(val key:String,val name:String,val host:String,val port:Int,val path:String,val secure:Boolean)
    private val ids=AtomicInteger(4000)
    private fun saved():List<Device> {
        val a=JSONArray(getSharedPreferences("printers",MODE_PRIVATE).getString("items","[]"))
        return (0 until a.length()).mapNotNull { i ->
            try {val o=a.getJSONObject(i); Device("${o.optString("ip")}:${o.optInt("port",631)}:${o.optString("path","/ipp/print")}",o.optString("name","Epson"),o.getString("ip"),o.optInt("port",631),o.optString("path","/ipp/print"),o.optBoolean("secure"))}catch(_:Exception){null}
        }
    }
    override fun onCreatePrinterDiscoverySession():PrinterDiscoverySession = object:PrinterDiscoverySession(){
        override fun onStartPrinterDiscovery(priorityList:MutableList<PrinterId>) {safePublish();probe()}
        override fun onStopPrinterDiscovery() {}
        override fun onValidatePrinters(printerIds:MutableList<PrinterId>) {safePublish();probe()}
        override fun onStartPrinterStateTracking(printerId:PrinterId) {safePublish();probe()}
        override fun onStopPrinterStateTracking(printerId:PrinterId) {}
        override fun onDestroy() {disposed = true}
        private var disposed = false
        private val states = java.util.concurrent.ConcurrentHashMap<String,Int>()
        private val failures = java.util.concurrent.ConcurrentHashMap<String,Int>()
        private val probeGeneration = AtomicInteger(0)
        private fun probe() {
            val devices = try { saved() } catch(t:Throwable) {diagnostic("Printer probe initialization",t);return}
            val generation = probeGeneration.incrementAndGet()
            thread(name="NovaPrint-PrinterProbe") {
                devices.forEach { d ->
                    // Get-Printer-Attributes can fail on Epson even while Print-Job works.
                    // A failed status query is not proof that the printer is offline.
                    val result = try {
                        exchange(d, 11, listOf(Ipp.a(0x44,"requested-attributes","printer-state")))
                        "IPP status OK"
                    } catch (e: Exception) {
                        "IPP status inconclusive: ${e.javaClass.simpleName}: ${e.message}"
                    }
                    val ok = result == "IPP status OK"
                    if (ok) {
                        failures[d.key] = 0
                        states[d.key] = PrinterInfo.STATUS_IDLE
                    } else {
                        failures[d.key] = (failures[d.key] ?: 0) + 1
                        // Preserve last-known-online status. A status probe cannot
                        // invalidate a printer whose actual print path is working.
                        if (!states.containsKey(d.key)) states[d.key] = PrinterInfo.STATUS_IDLE
                    }
                    getSharedPreferences("print_service_diagnostics",MODE_PRIVATE).edit()
                        .putString("last_probe_${d.key}","$result; failures=${failures[d.key]}")
                        .apply()
                }
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    if (!disposed && generation == probeGeneration.get()) safePublish()
                }
            }
        }
        private fun safePublish() {
            try { publish() } catch(t:Throwable) { diagnostic("Printer discovery callback",t) }
        }
        private fun publish(){
            val devices=saved(); if(devices.isEmpty())return
            val printers=devices.map { d ->
                val id=generatePrinterId(d.key)
                val a4=PrintAttributes.MediaSize.ISO_A4
                val caps=PrinterCapabilitiesInfo.Builder(id)
                    .addMediaSize(a4,true)
                    .addResolution(PrintAttributes.Resolution("300","300 dpi",300,300),true)
                    .setColorModes(PrintAttributes.COLOR_MODE_COLOR or PrintAttributes.COLOR_MODE_MONOCHROME,PrintAttributes.COLOR_MODE_COLOR)
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                    .setDuplexModes(PrintAttributes.DUPLEX_MODE_NONE, PrintAttributes.DUPLEX_MODE_NONE)
                // Only advertise A3 when the model is known to support it.
                if(d.name.contains("7830",true))caps.addMediaSize(PrintAttributes.MediaSize.ISO_A3,false)
                PrinterInfo.Builder(id,d.name,states[d.key] ?: PrinterInfo.STATUS_IDLE).setCapabilities(caps.build()).build()
            }
            addPrinters(printers)
        }
    }
    private fun diagnostic(stage:String,t:Throwable?=null) {
        android.util.Log.e("NovaPrintService",stage,t)
        try {
            getSharedPreferences("print_service_diagnostics",MODE_PRIVATE).edit()
                .putString("last_service_error",stage+"\\n"+(t?.let {android.util.Log.getStackTraceString(it)} ?: ""))
                .putLong("last_service_error_time",System.currentTimeMillis()).apply()
        } catch(_:Throwable) {}
    }
    override fun onRequestCancelPrintJob(job:PrintJob) {
        try {job.cancel()}catch(t:Throwable){diagnostic("Cancel job",t)}
    }
    override fun onPrintJobQueued(job:PrintJob) {
        val device=try {saved().firstOrNull { generatePrinterId(it.key)==job.info.printerId }}
            catch(t:Throwable){diagnostic("Print job lookup",t);try{job.fail("Druckerzuordnung fehlgeschlagen")}catch(_:Throwable){};return}
        if(device==null){try{job.fail("Drucker nicht gespeichert. Bitte zuerst in Nova-Print verbinden.")}catch(_:Throwable){};return}
        thread(name="NovaPrint-AndroidPrint") {
            var spool:File?=null
            try {
                if(job.isCancelled)return@thread
                diagnostic("Android job queued: ${job.info.label}")
                if (!job.start()) {
                    diagnostic("Android rejected job.start(): ${job.info.state}")
                    try { if (!job.isCancelled) job.fail("Android konnte Druckauftrag nicht starten") } catch (_:Throwable) {}
                    return@thread
                }
                diagnostic("Android job started")
                val attrs=job.info.attributes
                val media=attrs.mediaSize ?: PrintAttributes.MediaSize.ISO_A4
                val isA3=media.id==PrintAttributes.MediaSize.ISO_A3.id
                if(isA3 && !device.name.contains("7830",true))error("A3 für diesen Drucker nicht freigegeben")
                val portrait=media.isPortrait
                val mmW=if(isA3){if(portrait)297 else 420}else{if(portrait)210 else 297}
                val mmH=if(isA3){if(portrait)420 else 297}else{if(portrait)297 else 210}
                val mediaName=if(isA3)"iso_a3_297x420mm" else "iso_a4_210x297mm"
                val gray=attrs.colorMode==PrintAttributes.COLOR_MODE_MONOCHROME
                val dpi=300;val w=PwgRaster.pixels(mmW.toDouble(),dpi);val h=PwgRaster.pixels(mmH.toDouble(),dpi)
                val channels=if(gray)1 else 3
                // Do not make printing depend on optional Get-Printer-Attributes
                // replies. The direct Nova-Print path already proved this printer
                // accepts PWG raster; the Print-Job response is authoritative.
                getSharedPreferences("print_service_diagnostics",MODE_PRIVATE).edit()
                    .putString("last_print_target", "${device.name} ${device.host}:${device.port}${device.path}")
                    .apply()
                diagnostic("Opening Android spool PDF")
                val input=job.document.data ?: error("Android hat keine Druckdaten geliefert")
                spool=File.createTempFile("nova-service-",".pwg",cacheDir)
                input.use {fd->
                    PdfRenderer(fd).use {renderer->
                        check(renderer.pageCount>0){"Leeres Dokument"}
                        spool!!.outputStream().buffered(65536).use {out->
                            out.write("RaS2".toByteArray(Charsets.US_ASCII))
                            for(i in 0 until renderer.pageCount){
                                if(job.isCancelled)throw InterruptedException("Druckauftrag abgebrochen")
                                renderer.openPage(i).use {pg->
                                    out.write(PwgRaster.header(w,h,dpi,channels,renderer.pageCount,4,mediaName,0,0,1,1))
                                    // Android supplies a print-ready PDF. Do not silently fit-to-page:
                                    // preserve its physical page size and crop outside target media.
                                    val transform=Matrix().apply {setScale(dpi/72f,dpi/72f)}
                                    val pixels=IntArray(w);val row=ByteArray(w*channels)
                                    var y=0
                                    while(y<h){
                                        if(job.isCancelled)throw InterruptedException("Druckauftrag abgebrochen")
                                        val rows=minOf(128,h-y)
                                        val bmp=Bitmap.createBitmap(w,rows,Bitmap.Config.ARGB_8888)
                                        try {
                                            bmp.eraseColor(Color.WHITE)
                                            val band=Matrix(transform).apply {postTranslate(0f,-y.toFloat())}
                                            pg.render(bmp,null,band,PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                                            for(line in 0 until rows){
                                                bmp.getPixels(pixels,0,w,0,line,w,1)
                                                for(x in 0 until w){val v=pixels[x];val r=(v ushr 16) and 255;val g=(v ushr 8) and 255;val b=v and 255
                                                    if(gray)row[x]=((r*77+g*150+b*29+128) shr 8).toByte()
                                                    else {row[x*3]=r.toByte();row[x*3+1]=g.toByte();row[x*3+2]=b.toByte()}
                                                }
                                                PwgRaster.row(out,row,channels)
                                            }
                                        }finally{bmp.recycle()}
                                        y+=rows
                                    }
                                }
                            }
                        }
                    }
                }
                if(job.isCancelled)return@thread
                diagnostic("PWG ready: ${spool?.length()} bytes; sending to ${device.name}")
                val op=listOf(Ipp.a(0x42,"requesting-user-name","Nova-Print"),Ipp.a(0x42,"job-name",job.info.label),Ipp.a(0x49,"document-format","image/pwg-raster"),Ipp.a(0x22,"ipp-attribute-fidelity",true))
                val jobAttrs=listOf(Ipp.a(0x21,"copies",1),Ipp.a(0x44,"media",mediaName),Ipp.a(0x44,"print-scaling","none"),Ipp.a(0x44,"sides","one-sided"))
                val response=exchange(device,2,op,jobAttrs,spool)
                diagnostic("IPP Print-Job accepted, status=${response.status}")
                val printerJobId=response.integer("job-id",0)
                if(printerJobId<=0){
                    // Some Epson firmwares accept Print-Job but omit a job-id.
                    // IPP success is an accepted transfer, not proof of physical output.
                    diagnostic("IPP accepted without job-id; completing Android transfer")
                    job.complete()
                }else{
                    var terminal=false
                    var pollFailed=false
                    for(attempt in 0 until 30){
                        if(job.isCancelled){terminal=true;break}
                        val r=try {exchange(device,9,listOf(Ipp.a(0x21,"job-id",printerJobId),Ipp.a(0x42,"requesting-user-name","Nova-Print")))}
                            catch(t:Throwable){diagnostic("IPP job status unavailable",t);pollFailed=true;break}
                        when(r.integer("job-state",0)){
                            9->{job.complete();terminal=true}
                            7->{job.cancel();terminal=true}
                            8->{job.fail("Drucker meldet einen Fehler");terminal=true}
                        }
                        if(terminal)break
                        Thread.sleep(2000)
                    }
                    if(!terminal){
                        // The raster has been accepted by IPP; never leave an Android job
                        // indefinitely queued just because Epson does not expose status.
                        diagnostic(if(pollFailed)"IPP accepted; status polling unsupported" else "IPP accepted; polling timed out")
                        job.complete()
                    }
                }
            }catch(e:InterruptedException){try{job.cancel()}catch(_:Throwable){}}
            catch(t:Throwable){
                diagnostic("Android print pipeline",t)
                try {if(!job.isCancelled)job.fail("Nova-Print: ${t.javaClass.simpleName}: ${t.message}".take(180))}
                catch(reportError:Throwable){diagnostic("Reporting print failure",reportError)}
            }
            finally{try{spool?.delete()}catch(_:Throwable){} }
        }
    }
    private fun exchange(d:Device,operation:Int,op:List<Ipp.Attr> = emptyList(),attrs:List<Ipp.Attr> = emptyList(),file:File?=null):Ipp.Response {
        val uri="${if(d.secure)"ipps" else "ipp"}://${d.host}:${d.port}/${d.path.trimStart('/')}"
        val header=Ipp.request(operation,ids.incrementAndGet(),uri,op,attrs)
        val conn=URL("${if(d.secure)"https" else "http"}://${d.host}:${d.port}/${d.path.trimStart('/')}").openConnection() as HttpURLConnection
        conn.requestMethod="POST";conn.doOutput=true;conn.connectTimeout=7000;conn.readTimeout=60000
        conn.setRequestProperty("Content-Type","application/ipp")
        conn.setFixedLengthStreamingMode(header.size.toLong()+(file?.length() ?: 0L))
        try {
            conn.outputStream.use {out->out.write(header);file?.inputStream()?.use {it.copyTo(out)}}
            check(conn.responseCode in 200..299){"IPP HTTP ${conn.responseCode}"}
            return Ipp.parse(conn.inputStream.use {it.readBytes()}).also {it.requireSuccess()}
        }finally{conn.disconnect()}
    }
}
