package de.novaprint.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.pdf.PdfRenderer
import android.graphics.pdf.PdfDocument
import android.graphics.Bitmap
import android.graphics.RectF
import android.graphics.Canvas
import android.graphics.Matrix
import android.graphics.Paint
import android.provider.OpenableColumns
import android.view.Gravity
import android.widget.ImageView
import java.io.File
import kotlin.math.min
import android.os.ParcelFileDescriptor
import android.view.View
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.widget.LinearLayout.LayoutParams
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetAddress
import android.widget.*
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.security.SecureRandom
import java.security.cert.X509Certificate
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocketFactory
import javax.net.ssl.X509TrustManager
import javax.net.ssl.TrustManager
import javax.net.ssl.SSLSocket
import android.app.AlertDialog
import android.graphics.drawable.ColorDrawable
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var status: TextView
    private var progressLabel: TextView? = null
    private var progressBar: ProgressBar? = null
    private var progressPercent: TextView? = null
    private var inkPanel: LinearLayout? = null
    private var lastFriendlyStatus = "Bereit zum Drucken"
    private var inkBusy = java.util.concurrent.atomic.AtomicBoolean(false)
    private var lastInkUpdate = 0L
    private val inkValues = linkedMapOf<String, Int>()
    private var activePageTotal = 0
    private data class Printer(val name: String, val ip: String, val port: Int, val path: String, val secure: Boolean = false, val fingerprint: String = "")
    private val printers = mutableListOf<Printer>()
    private val candidates = mutableListOf<Printer>()
    private var active: Printer? = null
    private lateinit var printerList: LinearLayout
    private lateinit var scanList: LinearLayout
    private lateinit var nsd: NsdManager
    private val listeners = mutableListOf<NsdManager.DiscoveryListener>()
    private var currentScreen: LinearLayout? = null
    private lateinit var paper: Spinner
    private lateinit var quality: Spinner
    private lateinit var color: Spinner
    private lateinit var duplex: Spinner
    private lateinit var source: Spinner
    private lateinit var copies: EditText
    private var document: Uri? = null
    private var pdfWidth = 0f
    private var pdfHeight = 0f
    private var supportedPdf = false
    private var discovered = ""
    private lateinit var pdfInfo: TextView
    private lateinit var preview: ImageView
    private lateinit var scaleMode: Spinner
    private lateinit var customScale: EditText
    private lateinit var scaleInfo: TextView
    private var pageCount = 0
    private var previewPage = 0
    private lateinit var pageLabel: TextView
    private var borderlessSupported = false
    private var borderlessMedia: String? = null
    private var fileName = ""
    private var previewBitmap: Bitmap? = null
    private val previewExecutor=java.util.concurrent.Executors.newSingleThreadExecutor()
    @Volatile private var previewGeneration = 0
    @Volatile private var documentGeneration = 0
    private lateinit var automaticPaperInfo: TextView
    private lateinit var automaticSourceInfo: TextView
    private var printerSourceDetail = "Vom Drucker nicht gemeldet"
    private var printerProbeKey = ""
    private var printerProbeBusy = false
    private var diagnosticReport = ""
    private val blue = Color.rgb(25, 28, 33)
    private val ink = Color.rgb(20, 42, 79)
    private fun dp(n: Int): Int = (resources.displayMetrics.density * n).toInt()
    private fun rounded(color: Int, radius: Int = 18): GradientDrawable = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(16),dp(14),dp(16),dp(14))
        background = rounded(Color.WHITE)
        elevation = dp(3).toFloat()
        layoutParams = LayoutParams(-1, -2).apply { setMargins(0,dp(7),0,dp(10)) }
    }
    private fun section(root: LinearLayout, text: String): LinearLayout = card().also { root.addView(it); it.addView(title(text,19f)) }
    private fun primary(label: String, action: () -> Unit): Button = button(label,action).apply {
        setTextColor(Color.WHITE); background = rounded(blue,14)
        layoutParams = LayoutParams(-1,dp(56)).apply { setMargins(0,dp(6),0,dp(8)) }
    }
    // Product photos are selected by the connected printer's actual model,
    // never by the app owner's default printer.
    private fun modelImage(p: Printer?, size: Int = 92): ImageView {
        val view = printerImage(size)
        val model = p?.name?.uppercase(java.util.Locale.ROOT) ?: return view
        when {
            model.contains("WF-7830") || model.contains("WF 7830") ->
                view.setImageResource(R.drawable.wf7830_photo)
            model.contains("ET-4750") || model.contains("ET 4750") -> {
                // Genuine Epson press image. Cache after first online retrieval.
                // Offline and unsupported models use the neutral printer icon,
                // never a photograph of the wrong model.
                val cached = File(cacheDir, "epson_et4750_product.jpg")
                if(cached.length()>1000L) {
                    android.graphics.BitmapFactory.decodeFile(cached.absolutePath)?.let(view::setImageBitmap)
                } else {
                    thread(name="NovaPrint-ET4750Photo") {
                        try {
                            val address = "https://s3.amazonaws.com/cms.ipressroom.com/108/files/20178/" +
                                "59cd2f2c2cfac202d363bc39_ET_WF4750_HO_ANG_1/" +
                                "ET_WF4750_HO_ANG_1_8ffc8560-d0ae-4d3c-b6e6-7b5348eb8c7e-prv.jpg"
                            val connection = (URL(address).openConnection() as HttpURLConnection).apply {
                                connectTimeout=7000;readTimeout=7000
                            }
                            try {
                                if(connection.responseCode==200 && connection.contentType?.startsWith("image/")==true) {
                                    val bytes=connection.inputStream.use { it.readBytes() }
                                    if(bytes.size in 1001..2_000_000) {
                                        val bitmap=android.graphics.BitmapFactory.decodeByteArray(bytes,0,bytes.size)
                                        if(bitmap!=null) {
                                            cached.writeBytes(bytes)
                                            runOnUiThread { if(view.isAttachedToWindow)view.setImageBitmap(bitmap) }
                                        }
                                    }
                                }
                            } finally {connection.disconnect()}
                        } catch (_: Exception) { /* offline: retain neutral icon */ }
                    }
                }
            }
        }
        return view
    }
    private fun printerImage(size: Int = 92): ImageView = ImageView(this).apply {
        setImageResource(R.drawable.printer_device)
        layoutParams = LayoutParams(dp(size),dp(size))
        scaleType = ImageView.ScaleType.FIT_CENTER
    }
    private fun fingerprint(cert: X509Certificate): String = MessageDigest.getInstance("SHA-256")
        .digest(cert.encoded).joinToString(":") { "%02X".format(it.toInt() and 255) }
    private fun captureCertificate(p: Printer): Pair<X509Certificate, String> {
        val context = SSLContext.getInstance("TLS")
        val trust = object : X509TrustManager {
            override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
            override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {throw java.security.cert.CertificateException("Client certificates not supported")}
            override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {}
        }
        context.init(null, arrayOf<TrustManager>(trust), SecureRandom())
        val socket = context.socketFactory.createSocket() as SSLSocket
        socket.connect(java.net.InetSocketAddress(p.ip,p.port),7000)
        socket.soTimeout = 7000
        return socket.use {
            it.startHandshake()
            val cert = it.session.peerCertificates[0] as X509Certificate
            Pair(cert, fingerprint(cert))
        }
    }
    private fun pinnedFactory(expected: String): SSLSocketFactory {
        val trust = object : X509TrustManager {
            override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
            override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {throw java.security.cert.CertificateException("Client certificates not supported")}
            override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {
                if (chain.isEmpty() || fingerprint(chain[0]) != expected)
                    throw java.security.cert.CertificateException("Das Druckerzertifikat hat sich geändert. Bitte Drucker neu bestätigen.")
            }
        }
        return SSLContext.getInstance("TLS").apply { init(null, arrayOf<TrustManager>(trust), SecureRandom()) }.socketFactory
    }
    private fun certificateDialog(p: Printer, fp: String, cert: X509Certificate, proceed: (Printer) -> Unit) {
        AlertDialog.Builder(this)
            .setTitle("🔒 Druckerzertifikat bestätigen")
            .setMessage("${p.name} (${p.ip}) verwendet ein nicht öffentlich bestätigtes Zertifikat.\n\nAusgestellt für: ${cert.subjectX500Principal.name}\nAussteller: ${cert.issuerX500Principal.name}\nGültig bis: ${cert.notAfter}\n\nSHA-256-Fingerabdruck:\n$fp\n\nNur bestätigen, wenn du diesen Drucker kennst. Bei Änderungen wirst du erneut gefragt.")
            .setPositiveButton("Vertrauen & hinzufügen") { _, _ -> proceed(p.copy(fingerprint = fp)) }
            .setNegativeButton("Abbrechen", null).show()
    }

    private fun title(value: String, size: Float = 18f): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(Color.rgb(24, 39, 58)); setPadding(0, 12, 0, 12)
    }
    private fun button(value: String, click: () -> Unit): Button = Button(this).apply {
        text = value; setAllCaps(false); setOnClickListener { click() }
    }
    private fun container(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(18), dp(16), dp(28)); setBackgroundColor(Color.rgb(247, 248, 250))
    }
    private fun show(content: LinearLayout, footer: LinearLayout? = null) {
        currentScreen = content
        val layout=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL;setBackgroundColor(Color.rgb(247,248,250))}
        val scroll=ScrollView(this).apply {isFillViewport=true;fitsSystemWindows=true;addView(content)}
        layout.addView(scroll,LayoutParams(-1,0,1f))
        if(footer!=null)layout.addView(footer,LayoutParams(-1,-2))
        setContentView(layout)
    }
    private fun loadPrinters() {
        val saved = getSharedPreferences("printers", MODE_PRIVATE)
        val arr = JSONArray(saved.getString("items", "[]"))
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            printers.add(Printer(o.optString("name"), o.optString("ip"), o.optInt("port", 631), o.optString("path", "/ipp/print"), o.optBoolean("secure", false), o.optString("fingerprint", "")))
        }
        val idx = saved.getInt("active", 0)
        active = printers.getOrNull(idx)
    }
    private fun savePrinters() {
        val arr = JSONArray()
        printers.forEach { arr.put(JSONObject().put("name", it.name).put("ip", it.ip).put("port", it.port).put("path", it.path).put("secure", it.secure).put("fingerprint", it.fingerprint)) }
        getSharedPreferences("printers", MODE_PRIVATE).edit().putString("items", arr.toString())
            .putInt("active", printers.indexOf(active).coerceAtLeast(0)).apply()
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        nsd = getSystemService(Context.NSD_SERVICE) as NsdManager
        loadPrinters()
        home()
        accept(intent)
    }
    private fun home() {
        val root = container()
        val head = card().apply {setPadding(dp(18),dp(14),dp(18),dp(18))}
        val headRow=LinearLayout(this).apply {orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        val brand=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL}
        brand.addView(title("🖨  Nova-Print",25f).apply {setTypeface(null,Typeface.BOLD)})
        brand.addView(title("Dein Druckcenter",13f).apply {setTextColor(Color.GRAY)})
        headRow.addView(brand,LayoutParams(0,-2,1f))
        headRow.addView(button("⚙") {settingsScreen()}.apply {
            textSize=23f;contentDescription="Einstellungen und Diagnose"
            background=rounded(Color.rgb(239,241,243),25)
        },LayoutParams(dp(56),dp(52)))
        head.addView(headRow)
        val separator=View(this).apply {setBackgroundColor(Color.rgb(230,232,235))}
        head.addView(separator,LayoutParams(-1,dp(1)).apply {setMargins(0,dp(12),0,dp(12))})
        val printerRow=LinearLayout(this).apply {orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        printerRow.addView(modelImage(active,116))
        val details=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL;setPadding(dp(8),0,0,0)}
        details.addView(title(active?.name?.replace(" Series","") ?: "Drucker auswählen",18f).apply {setTypeface(null,Typeface.BOLD)})
        details.addView(title(if(active!=null)"✓  Bereit zum Drucken" else "Noch kein Drucker verbunden",14f).apply {setTextColor(Color.rgb(0,115,65))})
        details.addView(title(if(active!=null)"WLAN · Automatisch verbunden" else "Tippen zum Hinzufügen",12f).apply {setTextColor(Color.GRAY)})
        printerRow.addView(details,LayoutParams(0,-2,1f))
        printerRow.setOnClickListener {discoverScreen()}
        head.addView(printerRow)
        root.addView(head)
        val pdfSection = section(root,"📄  Aktuelles Dokument")
        pdfSection.addView(primary("📄  PDF auswählen") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "application/pdf"; addCategory(Intent.CATEGORY_OPENABLE)
            }, 10)
        })
        pdfSection.addView(button("🖼  Foto aus Galerie auswählen") {
            // Android Photo Picker grants access to the selected image only.
            // No blanket photo-library permission or installation-time prompt is required.
            val pick = Intent("android.intent.action.GET_CONTENT").apply {
                type = "image/*"; addCategory(Intent.CATEGORY_OPENABLE)
            }
            startActivityForResult(Intent.createChooser(pick,"Foto auswählen"), 12)
        }.apply { minimumHeight=dp(54) })
        pdfInfo = title(if (document == null) "Noch keine PDF ausgewählt" else "PDF: $fileName · $pageCount Seiten", 15f).apply { setTextColor(ink); setTypeface(null, Typeface.BOLD) }
        pdfSection.addView(pdfInfo)
        preview = ImageView(this).apply {
            setBackgroundColor(Color.rgb(233, 240, 248))
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            minimumHeight = dp(190)
            layoutParams = LayoutParams(-1, dp(290)).apply { setMargins(0, dp(8), 0, dp(12)) }
        }
        pdfSection.addView(preview)
        previewBitmap?.let { preview.setImageBitmap(it) }
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        nav.addView(button("◀ Vorherige") { if (previewPage > 0) { previewPage--; renderPreview() } }, LayoutParams(0, dp(48), 1f))
        pageLabel = title("Seite ${previewPage + 1} / ${pageCount.coerceAtLeast(1)}", 13f).apply { gravity = Gravity.CENTER }
        nav.addView(pageLabel, LayoutParams(0, dp(48), 1f))
        nav.addView(button("Nächste ▶") { if (previewPage + 1 < pageCount) { previewPage++; renderPreview() } }, LayoutParams(0, dp(48), 1f))
        pdfSection.addView(nav)
        pdfSection.addView(title("Live-Vorschau: Papier, Seitenrand und Skalierung · durch Antippen vergrößern", 12f))
        preview.setOnClickListener {
            previewBitmap?.let { bitmap ->
                val large = ImageView(this).apply {
                    setImageBitmap(bitmap); adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER
                }
                AlertDialog.Builder(this).setTitle("Druckvorschau · Seite ${previewPage + 1}")
                    .setView(large).setPositiveButton("Schließen", null).show()
            }
        }
        fun spin(label: String, entries: List<String>): Spinner {
            pdfSection.addView(title(label, 14f))
            return Spinner(this).apply {
                adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, entries)
                pdfSection.addView(this)
            }
        }
        paper = spin("Papierformat", listOf("Automatisch", "A4", "A3"))
        automaticPaperInfo = title("Automatisch · nach PDF-Auswahl ermitteln", 12f)
        pdfSection.addView(automaticPaperInfo)
        scaleMode = spin("Skalierung", listOf("Originalgröße (100 %)", "An Druckbereich anpassen", "An Papierformat anpassen", "Randlos (falls unterstützt)", "Benutzerdefiniert (%)"))
        pdfSection.addView(title("Benutzerdefinierter Maßstab (%)", 14f))
        customScale = EditText(this).apply { setText("100"); inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL; pdfSection.addView(this) }
        scaleInfo = title("Originalgröße: 100 % · keine automatische Verkleinerung", 13f)
        pdfSection.addView(scaleInfo)
        scaleMode.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { updateScaleDescription() }
        }
        paper.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { refreshAutoInfo(); renderPreview() }
        }
        customScale.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { updateScaleDescription() }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        quality = spin("Qualität", listOf("Normal · 300 dpi", "Hoch · 600 dpi"))
        color = spin("Farbe", listOf("Farbe", "Schwarzweiß"))
        duplex = spin("Duplex", listOf("Einseitig", "Lange Kante", "Kurze Kante"))
        source = spin("Papierzufuhr", listOf("Automatisch", "Hauptzufuhr (main)", "Alternative Zufuhr (alternate)"))
        automaticSourceInfo = title("Automatisch · Fachbelegung wird geprüft", 12f)
        pdfSection.addView(automaticSourceInfo)
        source.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { refreshAutoInfo() }
        }
        pdfSection.addView(title("Exemplare", 14f))
        copies = EditText(this).apply { setText("1"); inputType = 2; pdfSection.addView(this) }
        pdfSection.addView(primary("🖨  Jetzt drucken") { printPdf() })
        val dashboard=card().apply {setPadding(dp(18),dp(14),dp(18),dp(18))}
        dashboard.addView(title("Aktueller Druckauftrag",18f).apply {setTypeface(null,Typeface.BOLD)})
        progressLabel=title("✓  Bereit zum Drucken",15f).apply {setTextColor(Color.rgb(0,115,65))}
        dashboard.addView(progressLabel)
        val progressRow=LinearLayout(this).apply {orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
        progressBar=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply {
            max=100;progress=0;isIndeterminate=false
            progressTintList=android.content.res.ColorStateList.valueOf(Color.rgb(0,160,80))
        }
        progressRow.addView(progressBar,LayoutParams(0,dp(12),1f))
        progressPercent=title("",14f).apply {gravity=Gravity.END}
        progressRow.addView(progressPercent,LayoutParams(dp(65),dp(40)))
        dashboard.addView(progressRow)
        status=title("",12f).apply {visibility=View.GONE}
        dashboard.addView(status)
        dashboard.addView(View(this).apply {setBackgroundColor(Color.rgb(231,233,236))},LayoutParams(-1,dp(1)).apply {setMargins(0,dp(12),0,dp(10))})
        dashboard.addView(title("Tintenstand",18f).apply {setTypeface(null,Typeface.BOLD)})
        inkPanel=LinearLayout(this).apply {orientation=LinearLayout.HORIZONTAL}
        dashboard.addView(inkPanel)
        root.addView(dashboard)
        renderInkPanel()
        show(root)
        refreshAutoInfo()
        autoProbe()
        refreshInk(false)
    }
    private fun showPrintServiceDiagnostic() {
        val prefs=getSharedPreferences("print_service_diagnostics",MODE_PRIVATE)
        val events=prefs.getString("service_events","").orEmpty()
        val last=prefs.getString("last_service_error","").orEmpty()
        val message=if(events.isBlank())
            "Noch keine Ereignisse des Android-Druckdienstes gespeichert. Bitte einen Druck aus Adobe starten und anschließend hier erneut öffnen."
        else events
        val content=android.widget.ScrollView(this)
        val display=TextView(this).apply {
            text=message
            textSize=12f
            setTextIsSelectable(true)
            setPadding(dp(16),dp(12),dp(16),dp(12))
        }
        content.addView(display)
        AlertDialog.Builder(this).setTitle("Android-Druckdienst · Ablaufprotokoll")
            .setView(content)
            .setPositiveButton("Aktualisieren") { _, _ -> showPrintServiceDiagnostic() }
            .setNeutralButton("Teilen") { _, _ ->
                startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                    type="text/plain"
                    putExtra(Intent.EXTRA_SUBJECT,"Nova-Print Android-Druckdienst Diagnose")
                    putExtra(Intent.EXTRA_TEXT,message)
                },"Druckdienst-Protokoll teilen"))
            }
            .setNegativeButton("Schließen",null).show()
    }
    private fun settingsScreen() {
        val root=container()
        val head=section(root,"⚙  Einstellungen & Diagnose")
        head.addView(button("← Zurück zum Drucken") {home()})
        head.addView(title("Technische Funktionen · nur bei Problemen erforderlich",13f))
        head.addView(button("Druckerfunktionen abfragen") {probe()})
        head.addView(button("🧭 Android-Druckdienst-Diagnose anzeigen") { showPrintServiceDiagnostic() })
        head.addView(button("Vollständige Epson-Diagnose erstellen") {runFullDiagnostic()})
        head.addView(button("Diagnosebericht speichern") {saveDiagnostic()})
        head.addView(button("Letzten Druckstatus abrufen") {
            val p=lastJobPrinter;val id=lastJobId
            if(p==null || id==0)update("Noch kein Druckauftrag vorhanden.")
            else thread {try{pollJob(p,id)}catch(e:Exception){logJob("Statusabfrage: ${e.message}")}}
        })
        head.addView(button("Druckprotokoll speichern") {
            synchronized(jobEvents) {
                diagnosticReport=File(filesDir,"last-print.json").takeIf{it.exists()}?.readText()
                    ?: JSONObject().put("events",jobEvents).toString(2)
            }
            saveDiagnostic()
        })
        head.addView(button("Tintenstand jetzt aktualisieren") {refreshInk(true)})
        val scanner=section(root,"Scannen & Kopieren")
        scanner.addView(title("Scanner noch nicht implementiert. Die Dienstsuche ist eine Diagnosefunktion.",13f))
        scanner.addView(button("Scan-Dienste suchen") {discoverScan(scanner)})
        val details=section(root,"Verbindungsdetails")
        details.addView(title(active?.let{"${it.name} · ${it.ip}:${it.port}"} ?: "Kein Drucker ausgewählt",13f))
        show(root)
    }
    private fun renderInkPanel() {
        val panel=inkPanel ?: return
        panel.removeAllViews()
        val colors=listOf("Schwarz" to Color.rgb(38,40,43),"Cyan" to Color.rgb(0,195,210),
            "Magenta" to Color.rgb(222,0,191),"Gelb" to Color.rgb(244,198,0))
        for((name,tint) in colors) {
            val value=inkValues[name]
            val cell=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER_HORIZONTAL;setPadding(dp(3),dp(10),dp(3),dp(8))}
            val cartridge=android.widget.FrameLayout(this).apply {
                background=GradientDrawable().apply {setColor(Color.WHITE);setStroke(dp(2),Color.LTGRAY);cornerRadius=dp(8).toFloat()}
            }
            val fill=View(this).apply {background=rounded(tint,4)}
            val height=dp(61)
            val fillHeight=if(value==null)0 else (height*value/100).coerceIn(0,height)
            cartridge.addView(fill,android.widget.FrameLayout.LayoutParams(-1,fillHeight,Gravity.BOTTOM).apply {setMargins(dp(4),0,dp(4),dp(4))})
            cell.addView(cartridge,LayoutParams(dp(38),dp(72)))
            cell.addView(title(value?.let{"$it%"} ?: "–",16f).apply {gravity=Gravity.CENTER;setTypeface(null,Typeface.BOLD)})
            cell.addView(title(name,11f).apply {gravity=Gravity.CENTER;setTextColor(Color.GRAY)})
            panel.addView(cell,LayoutParams(0,-2,1f))
        }
    }
    private fun refreshInk(force:Boolean) {
        val p=active ?: return
        val now=System.currentTimeMillis()
        if(!force && now-lastInkUpdate<60_000L)return
        if(!inkBusy.compareAndSet(false,true))return
        thread(name="NovaPrint-Ink") {
            try {
                val table=Snmp.walk(p.ip,"1.3.6.1.2.1.43.11.1.1").values.associate{it.oid to it.value}
                val base="1.3.6.1.2.1.43.11.1.1."
                val found=linkedMapOf<String,Int>()
                table.filterKeys{it.startsWith(base+"6.")}.forEach{(oid,raw)->
                    val suffix=oid.removePrefix(base+"6.")
                    val level=table[base+"9."+suffix] as? Number
                    val maximum=table[base+"8."+suffix] as? Number
                    val name=raw.toString()
                    val channel=when {
                        name.contains("cyan",true)->"Cyan"
                        name.contains("magenta",true)->"Magenta"
                        name.contains("yellow",true)->"Gelb"
                        name.contains("black",true)->"Schwarz"
                        else->null
                    }
                    if(channel!=null && level!=null && maximum!=null && maximum.toInt()>0 &&
                        level.toInt()>=0)found[channel]=(100.0*level.toDouble()/maximum.toDouble()).toInt().coerceIn(0,100)
                }
                runOnUiThread {
                    if(found.isNotEmpty()){inkValues.putAll(found);lastInkUpdate=System.currentTimeMillis()}
                    renderInkPanel()
                }
            } catch(e:Exception){logJob("Tintenabfrage fehlgeschlagen: ${e.message}")}
            finally {inkBusy.set(false)}
        }
    }
    private fun showPrintProgress(label:String, percent:Int?=null, completed:Boolean=false) {
        runOnUiThread {
            progressLabel?.text=label+(if(completed)"  ✓" else "")
            progressBar?.isIndeterminate=percent==null && !completed
            if(percent!=null)progressBar?.progress=percent.coerceIn(0,100)
            if(completed){progressBar?.isIndeterminate=false;progressBar?.progress=100}
            progressPercent?.text=when {completed->"100 %";percent!=null->"${percent.coerceIn(0,100)} %";else->""}
            progressBar?.progressTintList=android.content.res.ColorStateList.valueOf(
                if(completed)Color.rgb(35,155,85) else Color.rgb(0,125,235))
        }
    }
    private fun refreshAutoInfo() {
        if (!::automaticPaperInfo.isInitialized || !::paper.isInitialized) return
        val a3 = detectMedia(pdfWidth,pdfHeight) == "iso_a3_297x420mm"
        val detected = if (a3) "A3 · 297 × 420 mm" else "A4 · 210 × 297 mm"
        automaticPaperInfo.text = when (paper.selectedItemPosition) {
            1 -> "Gewählt: A4 · 210 × 297 mm"
            2 -> "Gewählt: A3 · 297 × 420 mm"
            else -> if (document == null || pdfWidth <= 0f) "Automatisch · nach PDF-Auswahl ermitteln"
                    else "Automatisch → $detected · ${if (pdfWidth > pdfHeight) "Querformat" else "Hochformat"} (PDF)"
        }
        if (::automaticSourceInfo.isInitialized && ::source.isInitialized) {
            automaticSourceInfo.text = if (source.selectedItemPosition == 0)
                "Automatisch → $printerSourceDetail"
            else "Manuell → ${source.selectedItem}"
        }
    }
    private fun autoProbe() {
        val p = active ?: return
        val key = "${p.ip}:${p.port}${p.path}"
        if (printerProbeBusy || (printerProbeKey == key && discovered.isNotEmpty())) return
        probe()
    }
    private fun updateScaleDescription() {
        if (!::scaleInfo.isInitialized || !::scaleMode.isInitialized) return
        scaleInfo.text = when (scaleMode.selectedItemPosition) {
            0 -> "Originalgröße 100 %: Raster mit festem Maßstab. Randinhalte können abgeschnitten werden; keine Verkleinerung."
            1 -> "An Druckbereich anpassen: 5 mm Sicherheitsrand, proportionale Verkleinerung."
            2 -> "An Papierformat anpassen: proportional auf das Blattformat."
            3 -> if (borderlessSupported) "Randlos wird vom Drucker gemeldet. Achtung: Drucker kann intern überfüllen." else "Randlos: Druckerunterstützung noch nicht bestätigt."
            else -> "Benutzerdefiniert: ${if (::customScale.isInitialized) customScale.text else "100"} % des PDF-Originalmaßstabs."
        }
        renderPreview()
    }
    private fun renderPreview() {
        if (document == null || !::preview.isInitialized || !::scaleMode.isInitialized || !::paper.isInitialized) return
        val uri = document ?: return
        val generation = ++previewGeneration
        val selectedPage = previewPage
        val selectedPaper = paper.selectedItemPosition
        val selectedMode = scaleMode.selectedItemPosition
        val selectedPercent = if (::customScale.isInitialized) customScale.text.toString().toFloatOrNull() ?: 100f else 100f
        val widthPt = pdfWidth
        val heightPt = pdfHeight
        previewExecutor.execute {
            if(generation!=previewGeneration)return@execute
            try {
                val bitmap = buildPreviewBitmap(uri, selectedPage, selectedPaper, selectedMode, selectedPercent, widthPt, heightPt)
                runOnUiThread {
                    if (generation != previewGeneration || document != uri || isFinishing) {
                        bitmap.recycle()
                    } else {
                        previewBitmap = bitmap
                        preview.setImageBitmap(bitmap)
                        if (::pageLabel.isInitialized) pageLabel.text = "Seite ${selectedPage + 1} / $pageCount"
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { if (generation == previewGeneration) update("Vorschau fehlgeschlagen: ${e.message}") }
            }
        }
    }
    private fun buildPreviewBitmap(uri: Uri, selectedPage: Int, selectedPaper: Int, selectedMode: Int, selectedPercent: Float, widthPt: Float, heightPt: Float): Bitmap {
        try {
            val mediaA3 = when (selectedPaper) {
                1 -> false
                2 -> true
                else -> detectMedia(widthPt,heightPt) == "iso_a3_297x420mm"
            }
            var pageWidthPt=widthPt;var pageHeightPt=heightPt
            contentResolver.openFileDescriptor(uri,"r")!!.use {fd->PdfRenderer(fd).use {renderer->renderer.openPage(selectedPage.coerceIn(0,renderer.pageCount-1)).use {pg->pageWidthPt=pg.width.toFloat();pageHeightPt=pg.height.toFloat()}}}
            val landscape=pageWidthPt>pageHeightPt
            val actualA3=if(selectedPaper==0)detectMedia(pageWidthPt,pageHeightPt)=="iso_a3_297x420mm" else mediaA3
            val pw=if(actualA3)297f else 210f
            val ph=if(actualA3)420f else 297f
            val pageW = if (landscape) ph else pw
            val pageH = if (landscape) pw else ph
            val bitmap = Bitmap.createBitmap(520, (520f * pageH / pageW).toInt().coerceIn(200, 820), Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            canvas.drawColor(Color.rgb(223, 232, 242))
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
            val pad = 18f
            val paperRect = RectF(pad, pad, bitmap.width - pad, bitmap.height - pad)
            canvas.drawRect(paperRect, paint)
            val paperPxW = paperRect.width()
            val paperPxH = paperRect.height()
            val mode = selectedMode
            val custom = selectedPercent
            val margin = if (mode == 1) paperPxW * 5f / pageW else 0f
            val contentW = paperPxW - 2 * margin
            val contentH = paperPxH - 2 * margin
            contentResolver.openFileDescriptor(uri, "r")!!.use { fd ->
                PdfRenderer(fd).use { renderer ->
                    val index = selectedPage.coerceIn(0, renderer.pageCount - 1)
                    renderer.openPage(index).use { pg ->
                        val w = pg.width.toFloat()
                        val h = pg.height.toFloat()
                        val physicalScale = paperPxW / (pageW * 72f / 25.4f)
                        val factor = when (mode) {
                            1 -> min(contentW / w, contentH / h)
                            2, 3 -> min(paperPxW / w, paperPxH / h)
                            4 -> physicalScale * (custom / 100f)
                            else -> physicalScale
                        }
                        val targetW = w * factor
                        val targetH = h * factor
                        val left = paperRect.centerX() - targetW / 2
                        val top = paperRect.centerY() - targetH / 2
                        val f=min(700f/pg.width,1000f/pg.height).coerceAtMost(1f)
                        val img=Bitmap.createBitmap((pg.width*f).toInt().coerceAtLeast(1),(pg.height*f).toInt().coerceAtLeast(1),Bitmap.Config.ARGB_8888)
                        try {
                            img.eraseColor(Color.WHITE)
                            pg.render(img, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            canvas.save()
                            canvas.clipRect(paperRect)
                            canvas.drawBitmap(img, null, RectF(left, top, left + targetW, top + targetH), Paint(Paint.FILTER_BITMAP_FLAG))
                            canvas.restore()
                        } finally { img.recycle() }
                        if (mode == 1) {
                            paint.color = Color.rgb(30, 140, 240)
                            paint.style = Paint.Style.STROKE
                            paint.strokeWidth = 2f
                            canvas.drawRect(paperRect.left + margin, paperRect.top + margin, paperRect.right - margin, paperRect.bottom - margin, paint)
                            paint.style = Paint.Style.FILL
                        }
                    }
                }
            }
            return bitmap
        } catch (e: Exception) { throw e }
    }
    private fun drawSaved() {
        printerList.removeAllViews()
        if (printers.isEmpty()) printerList.addView(title("Noch kein Drucker eingerichtet.", 14f))
        printers.forEach { p ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL; setPadding(dp(4),dp(10),dp(4),dp(10)) }
            row.addView(modelImage(p,82))
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            info.addView(title(p.name + if (p == active) "  ✓" else "", 16f))
            info.addView(title("${if (p.secure) "IPPS" else "IPP"} · ${p.ip}:${p.port} · ${p.path}", 12f))
            row.addView(info, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
            row.setOnClickListener { active = p; savePrinters(); home() }
            row.setOnLongClickListener { printerDetails(p); true }
            printerList.addView(row)
        }
    }
    private fun printerDetails(p: Printer) {
        val root = container()
        root.addView(button("← Zurück") { home() })
        root.addView(modelImage(p,170))
        root.addView(title(p.name, 22f))
        root.addView(title("${if (p.secure) "IPPS" else "IPP"} · ${p.ip}:${p.port}${p.path}", 14f))
        root.addView(button("Als Standarddrucker verwenden") { active = p; savePrinters(); home() })
        root.addView(button("Drucker entfernen") { printers.remove(p); if (active == p) active = printers.firstOrNull(); savePrinters(); home() })
        show(root)
    }
    private var searchIndicator: android.widget.ProgressBar? = null
    private var searchStatus: TextView? = null
    private var discoverySerial = 0
    private val searchHandler = android.os.Handler(android.os.Looper.getMainLooper())

    private fun drawRecentPrinters(root: LinearLayout) {
        val recent = section(root, "🕘  Zuletzt verbundene Drucker")
        if (printers.isEmpty()) {
            recent.addView(title("Noch keine gespeicherten Drucker", 14f))
            return
        }
        printers.asReversed().forEach { p ->
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            line.addView(modelImage(p, 58))
            val details = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            details.addView(title(p.name, 15f))
            details.addView(title("${p.ip}:${p.port} · ${if (p == active) "Zuletzt verwendet" else "Gespeichert"}", 12f))
            line.addView(details, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
            recent.addView(line)
            recent.addView(button("Verbinden") {
                active = p; savePrinters(); stopDiscovery(); home()
            })
        }
    }

    private fun discoverScreen() {
        val root = container()
        root.addView(button("← Zurück") { stopDiscovery(); home() })
        root.addView(title("Drucker hinzufügen", 26f))
        val info = section(root,"📶  WLAN-Druckersuche")
        info.addView(title("IPP- und AirPrint-Drucker im gleichen WLAN werden automatisch erkannt.",14f))
        val progressRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        searchIndicator = android.widget.ProgressBar(this).apply {
            isIndeterminate = true
            layoutParams = LayoutParams(dp(28), dp(28)).apply { rightMargin = dp(12) }
        }
        progressRow.addView(searchIndicator)
        searchStatus = title("Suche läuft …", 14f)
        progressRow.addView(searchStatus)
        info.addView(progressRow)
        scanList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        info.addView(scanList)
        root.addView(primary("Erneut suchen") { startDiscovery() })
        drawRecentPrinters(root)
        root.addView(button("Drucker manuell hinzufügen") { stopDiscovery(); manualScreen() })
        show(root)
        startDiscovery()
    }
    private fun startDiscovery() {
        stopDiscovery(); candidates.clear(); scanList.removeAllViews()
        val token = ++discoverySerial
        searchIndicator?.visibility = android.view.View.VISIBLE
        searchStatus?.text = "Suche läuft …"
        searchHandler.postDelayed({
            if (token == discoverySerial && searchIndicator?.isAttachedToWindow == true) {
                stopDiscovery()
                searchIndicator?.visibility = android.view.View.GONE
                searchStatus?.text = if (candidates.isEmpty())
                    "Keine Drucker gefunden. Du kannst einen gespeicherten Drucker wählen oder eine IP eingeben."
                    else "Suche beendet · ${candidates.size} Drucker gefunden"
            }
        }, 16000L)
        listOf("_ipp._tcp.", "_ipps._tcp.").forEach { serviceType ->
            val listener = object : NsdManager.DiscoveryListener {
                override fun onDiscoveryStarted(regType: String) {}
                override fun onStartDiscoveryFailed(type: String, errorCode: Int) {
                    runOnUiThread { searchStatus?.text = "Netzwerksuche fehlgeschlagen ($errorCode)" }
                }
                override fun onStopDiscoveryFailed(type: String, errorCode: Int) {}
                override fun onDiscoveryStopped(type: String) {}
                override fun onServiceLost(service: NsdServiceInfo) {}
                override fun onServiceFound(service: NsdServiceInfo) {
                    try {
                        @Suppress("DEPRECATION")
                        nsd.resolveService(service, object : NsdManager.ResolveListener {
                            override fun onResolveFailed(info: NsdServiceInfo, code: Int) {}
                            override fun onServiceResolved(info: NsdServiceInfo) {
                                val ip = info.host?.hostAddress ?: return
                                val txt = info.attributes
                                val rp = txt["rp"]?.toString(Charsets.UTF_8)?.trim('/') ?: "ipp/print"
                                val model = txt["ty"]?.toString(Charsets.UTF_8)?.takeIf { it.isNotBlank() } ?: info.serviceName
                                val printer = Printer(model, ip, info.port, "/$rp", serviceType == "_ipps._tcp." || info.serviceType.startsWith("_ipps."))
                                runOnUiThread {
                                    val existing = candidates.indexOfFirst { it.ip == printer.ip }
                                    if (existing < 0) { candidates.add(printer); drawCandidates(); searchStatus?.text = "${candidates.size} Drucker gefunden · Suche läuft …" }
                                    else if (printer.secure && !candidates[existing].secure) { candidates[existing] = printer; drawCandidates() }
                                }
                            }
                        })
                    } catch (_: Exception) { }
                }
            }
            listeners.add(listener)
            try { nsd.discoverServices(serviceType, NsdManager.PROTOCOL_DNS_SD, listener) }
            catch (e: Exception) { scanList.addView(title("Netzwerksuche: ${e.message}", 14f)) }
        }
    }
    private fun drawCandidates() {
        scanList.removeAllViews()
        candidates.forEach { p ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL; setPadding(0,dp(8),0,dp(8)) }
            row.addView(modelImage(p,72))
            val text = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            text.addView(title(p.name, 16f)); text.addView(title("${p.ip} · ${if (p.secure) "IPPS 🔒" else "IPP"}", 13f))
            row.addView(text, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
            row.addView(button("Hinzufügen") { verifyPrinter(p) })
            scanList.addView(row)
        }
    }
    private fun verifyPrinter(p: Printer) {
        scanList.addView(title("Prüfe ${p.name} …", 14f))
        thread { verifyAndOffer(p) }
    }
    private fun verifyAndOffer(p: Printer) {
        try {
            val actual = try {
                if (p.secure) p else {
                    try { ippRequest(0x000B, null, emptyList(), p); p }
                    catch (e: Exception) { if (e.message?.contains("426") == true) p.copy(secure = true) else throw e }
                }
            } catch (e: Exception) { throw e }
            if (actual.secure && actual.fingerprint.isBlank()) {
                val (cert, fp) = captureCertificate(actual)
                runOnUiThread { certificateDialog(actual, fp, cert) { approved ->
                    thread { verifyAndOffer(approved) }
                } }
                return
            }
            val response = ippRequest(0x000B, null, emptyList(), actual)
            val code = ((response[2].toInt() and 255) shl 8) or (response[3].toInt() and 255)
            if (code >= 0x0100) throw IllegalStateException("Drucker meldet IPP-Status 0x${code.toString(16)}")
            runOnUiThread {
                printers.removeAll { it.ip == actual.ip }
                printers.add(actual); active = actual; savePrinters(); stopDiscovery(); home()
            }
        } catch (e: Exception) { runOnUiThread {
            scanList.addView(title("Verbindung nicht möglich: ${e.message ?: "Unbekannter Netzwerkfehler"}",14f))
        } }
    }
    private fun manualScreen() {
        val root = container()
        root.addView(button("← Zurück") { discoverScreen() })
        root.addView(title("Drucker manuell hinzufügen", 22f))
        fun edit(label: String, value: String): EditText {
            root.addView(title(label, 14f))
            return EditText(this).apply { setText(value); root.addView(this) }
        }
        val name = edit("Name", "Epson WorkForce WF-7830DTWF")
        val ip = edit("IP-Adresse", "192.168.178.50")
        val port = edit("IPP-Port", "631")
        val path = edit("IPP-Pfad", "/ipp/print")
        val message = title("", 14f)
        root.addView(primary("Verbindung prüfen und hinzufügen") {
            val p = Printer(name.text.toString().trim(), ip.text.toString().trim(), port.text.toString().toIntOrNull() ?: 631, path.text.toString().trim())
            message.text = "Verbindung wird geprüft …"
            thread { verifyManual(p, message) }
        })
        root.addView(message)
        show(root)
    }
    private fun verifyManual(p: Printer, message: TextView) {
        try {
            val actual = if (p.secure) p else try { ippRequest(0x000B, null, emptyList(), p); p }
                catch (e: Exception) { if (e.message?.contains("426") == true) p.copy(secure = true) else throw e }
            if (actual.secure && actual.fingerprint.isBlank()) {
                val (cert, fp) = captureCertificate(actual)
                runOnUiThread { certificateDialog(actual, fp, cert) { approved -> thread { verifyManual(approved, message) } } }
                return
            }
            val response = ippRequest(0x000B, null, emptyList(), actual)
            val code = ((response[2].toInt() and 255) shl 8) or (response[3].toInt() and 255)
            if (code >= 0x0100) throw IllegalStateException("IPP-Status 0x${code.toString(16)}")
            runOnUiThread { printers.removeAll { it.ip == actual.ip }; printers.add(actual); active = actual; savePrinters(); home() }
        } catch (e: Exception) { runOnUiThread { message.text = "Verbindung fehlgeschlagen: ${e.message}" } }
    }
    private fun stopDiscovery() {
        discoverySerial++
        searchIndicator?.visibility = android.view.View.GONE
        listeners.forEach { try { nsd.stopServiceDiscovery(it) } catch (_: Exception) {} }
        listeners.clear()
    }
    override fun onDestroy() {stopDiscovery();++previewGeneration;previewExecutor.shutdownNow();super.onDestroy()}

    @Deprecated("Legacy picker callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 10 && resultCode == RESULT_OK) data?.data?.let { setDocument(it) }
        if (requestCode == 12 && resultCode == RESULT_OK) data?.data?.let { importPhoto(it) }
        if (requestCode == 81 && resultCode == RESULT_OK) data?.data?.let { uri ->
            try { contentResolver.openOutputStream(uri)?.use { it.write(diagnosticReport.toByteArray(Charsets.UTF_8)) }; update("Diagnosebericht gespeichert.") }
            catch (e: Exception) { update("Speichern fehlgeschlagen: ${e.message}") }
        }
    }
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); accept(intent) }
    private fun accept(i: Intent?) {
        val uri = when (i?.action) {
            Intent.ACTION_SEND -> if (android.os.Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java) else @Suppress("DEPRECATION") i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
            Intent.ACTION_VIEW -> i.data
            else -> null
        }
        if (uri != null) setDocument(uri)
    }
    private fun importPhoto(uri: Uri) {
        update("Foto wird als druckbares PDF vorbereitet …")
        thread(name="NovaPrint-PhotoImport") {
            try {
                val options=android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds=true }
                contentResolver.openInputStream(uri)!!.use {android.graphics.BitmapFactory.decodeStream(it,null,options)}
                check(options.outWidth>0 && options.outHeight>0) {"Bild kann nicht gelesen werden."}
                // Limit decoded pixels to avoid OOM on large camera photographs.
                var sample=1
                while(options.outWidth/sample>3500 || options.outHeight/sample>3500) sample*=2
                val decode=android.graphics.BitmapFactory.Options().apply {inSampleSize=sample}
                val bitmap=contentResolver.openInputStream(uri)!!.use {
                    android.graphics.BitmapFactory.decodeStream(it,null,decode)
                } ?: error("Bildformat wird nicht unterstützt.")
                try {
                    val exif=1 // Picker images usually provide correctly oriented pixels.
                    val angle=when(exif){3->180f;6->90f;8->270f;else->0f}
                    val image=if(angle!=0f) Bitmap.createBitmap(bitmap,0,0,bitmap.width,bitmap.height,
                        Matrix().apply {postRotate(angle)},true) else bitmap
                    try {
                        val landscape=image.width>image.height
                        val pw=if(landscape)842 else 595
                        val ph=if(landscape)595 else 842
                        val doc=PdfDocument()
                        try {
                            val page=doc.startPage(PdfDocument.PageInfo.Builder(pw,ph,1).create())
                            val scale=minOf(pw.toFloat()/image.width,ph.toFloat()/image.height)
                            val w=image.width*scale;val h=image.height*scale
                            page.canvas.drawColor(Color.WHITE)
                            page.canvas.drawBitmap(image,null,android.graphics.RectF((pw-w)/2,(ph-h)/2,(pw+w)/2,(ph+h)/2),Paint(Paint.FILTER_BITMAP_FLAG))
                            doc.finishPage(page)
                            val out=File(cacheDir,"nova-photo-${System.currentTimeMillis()}.pdf")
                            out.outputStream().use {doc.writeTo(it)}
                            runOnUiThread {setDocument(Uri.fromFile(out))}
                        } finally {doc.close()}
                    } finally {if(image!==bitmap)image.recycle()}
                } finally {bitmap.recycle()}
            }catch(e:Exception){runOnUiThread {update("Foto konnte nicht geöffnet werden: ${e.message}")}}
        }
    }
    private fun setDocument(uri: Uri) {
        document = uri
        val generation = ++documentGeneration
        ++previewGeneration
        pdfWidth = 0f
        pdfHeight = 0f
        pageCount = 0
        previewPage = 0
        if (::pdfInfo.isInitialized) pdfInfo.text = "PDF wird geladen …"
        if (::preview.isInitialized) preview.setImageDrawable(null)
        update("PDF wird im Hintergrund eingelesen …")
        thread(name = "NovaPrint-PdfOpen") {
            try {
                var name = "Dokument.pdf"
                try {
                    contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                        if (cursor.moveToFirst()) name = cursor.getString(0) ?: name
                    }
                } catch (_: Exception) {}
                var count = 0
                var width = 0f
                var height = 0f
                contentResolver.openFileDescriptor(uri, "r")!!.use { fd ->
                    PdfRenderer(fd).use { renderer ->
                        count = renderer.pageCount
                        if (count < 1) throw IllegalArgumentException("PDF enthält keine Seiten")
                        renderer.openPage(0).use { page ->
                            width = page.width.toFloat()
                            height = page.height.toFloat()
                        }
                    }
                }
                runOnUiThread {
                    if (generation != documentGeneration || document != uri || isFinishing) return@runOnUiThread
                    fileName = name
                    pageCount = count
                    pdfWidth = width
                    pdfHeight = height
                    if (::pdfInfo.isInitialized) pdfInfo.text =
                        "✓ $name · $count Seiten · ${"%.0f".format(width * 25.4 / 72)} × ${"%.0f".format(height * 25.4 / 72)} mm"
                    refreshAutoInfo()
                    renderPreview()
                    update("PDF geladen: $name · $count Seiten.")
                }
            } catch (e: Exception) {
                runOnUiThread { if (generation == documentGeneration) update("PDF konnte nicht geöffnet werden: ${e.message}") }
            }
        }
    }
    private fun update(msg: String) {runOnUiThread {
        if(!isFinishing && ::status.isInitialized) {
            // Raw protocol information belongs in the diagnostics, not on the home dashboard.
            if(msg.startsWith("Live-Abfrage:") || msg.startsWith("IPP ") || msg.contains("PWG-Raster unterstützt")) {
                android.util.Log.d("NovaPrint-Diagnostics",msg)
            } else if(msg.contains("fehlgeschlagen",true) || msg.contains("Fehler",true)) {
                showPrintProgress("Druckerhinweis – Einstellungen prüfen")
            }
        }
    }}
    private fun endpoint(p: Printer): String = "${if (p.secure) "https" else "http"}://${p.ip}:${p.port}${p.path.let { if (it.startsWith('/')) it else "/$it" }}"
    private fun probe() {
        val printer = active ?: return update("Bitte zuerst einen Drucker hinzufügen.")
        if (printerProbeBusy) return
        printerProbeBusy = true
        update("Druckerfunktionen werden im Hintergrund abgefragt …")
        thread {
            try {
                val response = ippRequest(0x000B, null, emptyList(), printer)
                val parsed = parseAttributes(response)
                discovered = parsed
                printerProbeKey = "${printer.ip}:${printer.port}${printer.path}"
                supportedPdf = hasPdfSupport(response)
                borderlessSupported = parsed.contains("borderless", true) || parsed.contains("randlos", true)
                borderlessMedia = Regex("""(?m)^media[^:]*: ([^\\n]*borderless[^\\n]*)""", RegexOption.IGNORE_CASE).find(parsed)?.groupValues?.get(1)?.trim()
                val structured=Ipp.parse(response)
                printerSourceDetail=structured.values("media-col-ready").mapNotNull { value ->
                    @Suppress("UNCHECKED_CAST")
                    val fields=value as? List<Ipp.Attr> ?: return@mapNotNull null
                    val src=Ipp.member(fields,"media-source") ?: "auto"
                    @Suppress("UNCHECKED_CAST")
                    val size=Ipp.member(fields,"media-size") as? List<Ipp.Attr>
                    "$src: ${size?.let{Ipp.member(it,"x-dimension")}} × ${size?.let{Ipp.member(it,"y-dimension")}} (1/100 mm)"
                }.distinct().joinToString("; ").ifBlank{"Keine Live-Fachbelegung gemeldet"}
                runOnUiThread{refreshAutoInfo()}
                update("Live-Abfrage: PWG-Raster ${if(structured.has("document-format-supported","image/pwg-raster"))"unterstützt" else "nicht bestätigt"}. $printerSourceDetail")
            } catch (e: Exception) { supportedPdf = false; update("IPP-Abfrage fehlgeschlagen: ${e.message}") }
            finally { printerProbeBusy = false }
        }
    }

    private fun saveDiagnostic() {
        if (diagnosticReport.isBlank()) return update("Bitte zuerst die vollständige Diagnose durchführen.")
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/json"
            putExtra(Intent.EXTRA_TITLE, "Nova-Print-Epson-Diagnose.json")
        }, 81)
    }

    // Read-only discovery. No settings are changed and no print jobs are submitted.
    private fun runFullDiagnostic() {
        val p = active ?: return update("Bitte zuerst einen Drucker auswählen.")
        update("Vollständige Diagnose läuft: IPP, SNMP, HTTP, Scanner und Netzwerk …")
        thread(name = "NovaPrint-DeviceDiagnostic") {
            val report = JSONObject()
            report.put("schema", "Nova-Print device diagnostics v1")
            report.put("timestamp", java.time.Instant.now().toString())
            report.put("printer", JSONObject().put("name", p.name).put("address", p.ip).put("ippPort", p.port).put("ippPath", p.path))
            val ports = JSONObject()
            for (port in listOf(80, 443, 515, 631, 9100, 5357, 1865, 2968, 3289)) {
                ports.put(port.toString(), try {
                    java.net.Socket().use { sock -> sock.connect(java.net.InetSocketAddress(p.ip, port), 950); "open" }
                } catch (_: Exception) { "closed-or-filtered" })
            }
            report.put("tcpPorts", ports)
            try {
                val raw = ippRequest(0x000B, null, emptyList(), p)
                report.put("ipp", JSONObject()
                    .put("statusCode", ((raw[2].toInt() and 255) shl 8) or (raw[3].toInt() and 255))
                    .put("attributes", fullIppAttributes(raw)).put("structured",Ipp.parse(raw).attrs().toString())
                    .put("rawResponseBase64", android.util.Base64.encodeToString(raw, android.util.Base64.NO_WRAP)))
            } catch (e: Exception) { report.put("ippError", e.toString()) }
            val snmp = JSONObject()
            // Standard MIB-II + Printer-MIB supply, input tray, status and identity tables.
            for ((label, oid) in listOf(
                "systemDescription" to "1.3.6.1.2.1.1.1.0",
                "systemName" to "1.3.6.1.2.1.1.5.0",
                "printerStatus" to "1.3.6.1.2.1.25.3.5.1.1.1",
                "printerDetectedError" to "1.3.6.1.2.1.25.3.5.1.2.1",
                "printerGeneral" to "1.3.6.1.2.1.43.5.1.1.16.1",
                "inputTrayName1" to "1.3.6.1.2.1.43.8.2.1.13.1.1",
                "inputTrayName2" to "1.3.6.1.2.1.43.8.2.1.13.1.2",
                "inputTrayLevel1" to "1.3.6.1.2.1.43.8.2.1.10.1.1",
                "inputTrayLevel2" to "1.3.6.1.2.1.43.8.2.1.10.1.2",
                "supplyDescription1" to "1.3.6.1.2.1.43.11.1.1.6.1.1",
                "supplyLevel1" to "1.3.6.1.2.1.43.11.1.1.9.1.1",
                "supplyMax1" to "1.3.6.1.2.1.43.11.1.1.8.1.1"
            )) snmp.put(label, snmpGet(p.ip, oid))
            report.put("snmp", snmp)
            val walks=JSONObject()
            for(root in listOf("1.3.6.1.2.1.43","1.3.6.1.2.1.25.3"))walks.put(root,walkJson(Snmp.walk(p.ip,root)))
            report.put("snmpWalk",walks).put("jobEvents",jobEvents)
            val http = JSONObject()
            for (path in listOf("/", "/eSCL/ScannerCapabilities", "/eSCL/ScannerStatus", "/DevMgmt/ProductConfigDyn.xml")) {
                http.put(path, httpDiagnostic(p.ip, path))
            }
            report.put("httpAndScan", http)
            diagnosticReport = report.toString(2)
            runOnUiThread {
                update("Diagnose abgeschlossen. IPP, SNMP, Netzwerk und Scan-Schnittstellen geprüft. Bitte auf ‚Diagnosebericht speichern‘ tippen und die JSON-Datei hier hochladen. Keine Drucker-Einstellungen verändert.")
            }
        }
    }

    private fun walkJson(walk:Snmp.Walk):JSONObject {
        val rows=JSONArray();walk.values.forEach{rows.put(JSONObject().put("oid",it.oid).put("tag",it.tag).put("value",it.value))}
        return JSONObject().put("complete",walk.complete).put("reason",walk.reason).put("values",rows)
    }
    private fun liveStatus(root:LinearLayout) {
        val p=active ?: return update("Bitte zuerst Drucker verbinden.")
        val info=title("Live-Abfrage läuft …",14f);root.addView(info)
        thread {
            val walk=Snmp.walk(p.ip,"1.3.6.1.2.1.43");val table=walk.values.associate{it.oid to it.value}
            val summary=StringBuilder("Printer-MIB: ${if(walk.complete)"Walk vollständig" else "Teilresultat"} · ${walk.reason}\n")
            val supplies=mutableListOf<Triple<String,Int,Int>>();val base="1.3.6.1.2.1.43.11.1.1."
            table.filterKeys{it.startsWith(base+"6.")}.forEach{(oid,name)->
                val suffix=oid.removePrefix(base+"6.");val level=table[base+"9."+suffix];val max=table[base+"8."+suffix]
                summary.append("$name: ${Snmp.level(level)} / ${Snmp.level(max)}\n")
                if(level is Number && max is Number && level.toInt()>=0 && max.toInt()>0){val label=name.toString();val tint=when{label.contains("cyan",true)->Color.CYAN;label.contains("magenta",true)->Color.MAGENTA;label.contains("yellow",true)->Color.YELLOW;else->Color.DKGRAY};supplies.add(Triple(label,(level.toDouble()/max.toDouble()*100).toInt().coerceIn(0,100),tint))}
            }
            val input="1.3.6.1.2.1.43.8.2.1."
            table.filterKeys{it.startsWith(input+"13.")}.forEach{(oid,name)->val suffix=oid.removePrefix(input+"13.");summary.append("$name: ${Snmp.level(table[input+"10."+suffix])}; Medium: ${table[input+"12."+suffix] ?: "unbekannt"}; Statuscode: ${table[input+"11."+suffix] ?: "unbekannt"}\n")}
            table.filterKeys{it.startsWith("1.3.6.1.2.1.43.18.1.1.8.")}.forEach{(_,v)->summary.append("Meldung: $v\n")}
            try{val r=exchange(p,11,listOf(Ipp.a(0x44,"requested-attributes","all")));summary.append("IPP Status: ${r.text("printer-state")} ${r.text("printer-state-reasons")}\nMedien: ${r.text("media-col-ready")}")}catch(e:Exception){summary.append("IPP: ${e.message}")}
            diagnosticReport=walkJson(walk).toString(2)
            runOnUiThread{info.text=summary.toString();supplies.forEach{(name,percent,tint)->root.addView(title("$name: $percent %",13f));root.addView(ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply{max=100;progress=percent;progressTintList=android.content.res.ColorStateList.valueOf(tint)})}}
        }
    }
    private fun discoverScan(root:LinearLayout) {
        val p=active ?: return update("Bitte zuerst Drucker verbinden.")
        val view=title("Suche nach eSCL/AirScan-Diensten …",14f);root.addView(view);val found=JSONArray()
        for(type in listOf("_uscan._tcp.","_uscans._tcp.","_scanner._tcp.")){
            val listener=object:NsdManager.DiscoveryListener{
                override fun onDiscoveryStarted(t:String){}
                override fun onDiscoveryStopped(t:String){}
                override fun onStopDiscoveryFailed(t:String,e:Int){}
                override fun onStartDiscoveryFailed(t:String,e:Int){runOnUiThread{view.append("\n$type: Fehler $e")}}
                override fun onServiceLost(s:NsdServiceInfo){}
                override fun onServiceFound(service:NsdServiceInfo){
                    try{nsd.resolveService(service,object:NsdManager.ResolveListener{
                        override fun onResolveFailed(s:NsdServiceInfo,e:Int){}
                        override fun onServiceResolved(s:NsdServiceInfo){
                            if(s.host?.hostAddress!=p.ip)return
                            val record=JSONObject().put("type",type).put("name",s.serviceName).put("port",s.port);val txt=JSONObject();s.attributes.forEach{(k,v)->txt.put(k,v.toString(Charsets.UTF_8))};record.put("txt",txt)
                            synchronized(found){found.put(record);diagnosticReport=JSONObject().put("scanServices",found).toString(2)}
                            runOnUiThread{view.append("\n$record")}
                        }
                    })}catch(e:Exception){runOnUiThread{view.append("\n${e.message}")}}
                }
            }
            listeners.add(listener);try{nsd.discoverServices(type,NsdManager.PROTOCOL_DNS_SD,listener)}catch(e:Exception){view.append("\n${e.message}")}
        }
        android.os.Handler(mainLooper).postDelayed({stopDiscovery();view.append("\nSuche beendet. Kein Treffer beweist keine fehlende Scan-Funktion.")},15000)
    }
    private fun readLimited(input:java.io.InputStream,limit:Int):ByteArray {
        val out=ByteArrayOutputStream();val b=ByteArray(4096)
        while(out.size()<limit){val n=input.read(b,0,minOf(b.size,limit-out.size()));if(n<0)break;out.write(b,0,n)}
        return out.toByteArray()
    }
    private fun httpDiagnostic(host: String, path: String): JSONObject {
        val result = JSONObject()
        try {
            val conn = URL("http://$host$path").openConnection() as HttpURLConnection
            conn.connectTimeout = 2000; conn.readTimeout = 2500
            conn.instanceFollowRedirects = false
            try {
                result.put("status", conn.responseCode)
                result.put("contentType", conn.contentType ?: "").put("location",conn.getHeaderField("Location") ?: "")
                val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
                result.put("body", stream?.use { String(readLimited(it,65536), Charsets.UTF_8) } ?: "")
            } finally { conn.disconnect() }
        } catch (e: Exception) { result.put("error", e.toString()) }
        return result
    }

    private fun fullIppAttributes(bytes: ByteArray): JSONArray {
        val array = JSONArray(); var i = 8; var name = ""; var group = 0; var count = 0
        while (i < bytes.size && count < 3000) {
            val tag = bytes[i++].toInt() and 255
            if (tag == 3) break
            if (tag <= 0x0f) { group = tag; continue }
            if (i + 4 > bytes.size) break
            val nl = ((bytes[i].toInt() and 255) shl 8) or (bytes[i+1].toInt() and 255); i += 2
            if (i + nl + 2 > bytes.size) break
            if (nl > 0) name = String(bytes, i, nl, Charsets.UTF_8)
            i += nl
            val vl = ((bytes[i].toInt() and 255) shl 8) or (bytes[i+1].toInt() and 255); i += 2
            if (i + vl > bytes.size) break
            val data = bytes.copyOfRange(i, i + vl); i += vl; count++
            val value = when {
                tag == 0x21 || tag == 0x23 -> if (vl == 4) ByteBuffer.wrap(data).order(ByteOrder.BIG_ENDIAN).int.toString() else "invalid integer"
                tag == 0x32 && vl == 9 -> "${ByteBuffer.wrap(data, 0, 4).int}x${ByteBuffer.wrap(data, 4, 4).int} dpi/unit:${data[8].toInt() and 255}"
                tag == 0x22 && vl == 1 -> (data[0].toInt() != 0).toString()
                tag in 0x30..0x3f || tag == 0x34 || tag == 0x4a -> "base64:" + android.util.Base64.encodeToString(data, android.util.Base64.NO_WRAP)
                else -> String(data, Charsets.UTF_8)
            }
            array.put(JSONObject().put("group", group).put("tag", tag).put("name", name).put("value", value))
        }
        return array
    }

    private fun snmpGet(host: String, oid: String): JSONObject {
        val result = JSONObject()
        try {
            fun len(n: Int): ByteArray = if (n < 128) byteArrayOf(n.toByte()) else byteArrayOf(0x82.toByte(), (n shr 8).toByte(), n.toByte())
            fun tlv(tag: Int, data: ByteArray): ByteArray = byteArrayOf(tag.toByte()) + len(data.size) + data
            val arcs = oid.split('.').map { it.toLong() }
            val oidBytes = ByteArrayOutputStream(); oidBytes.write((arcs[0] * 40 + arcs[1]).toInt())
            for (arc in arcs.drop(2)) {
                var v = arc; val parts = mutableListOf((v and 127).toInt()); v = v shr 7
                while (v > 0) { parts.add(0, ((v and 127) or 128).toInt()); v = v shr 7 }
                parts.forEach { oidBytes.write(it) }
            }
            val varbind = tlv(0x30, tlv(0x06, oidBytes.toByteArray()) + tlv(0x05, byteArrayOf()))
            val request = tlv(0xA0, tlv(0x02, byteArrayOf(1)) + tlv(0x02, byteArrayOf(0)) + tlv(0x02, byteArrayOf(0)) + tlv(0x30, varbind))
            val message = tlv(0x30, tlv(0x02, byteArrayOf(0)) + tlv(0x04, "public".toByteArray()) + request)
            java.net.DatagramSocket().use { sock ->
                sock.soTimeout = 750
                sock.send(java.net.DatagramPacket(message, message.size, InetAddress.getByName(host), 161))
                val buffer = ByteArray(8192); val packet = java.net.DatagramPacket(buffer, buffer.size)
                sock.receive(packet)
                result.put("responseBase64", android.util.Base64.encodeToString(buffer.copyOf(packet.length), android.util.Base64.NO_WRAP))
            }
        } catch (e: Exception) { result.put("error", e.javaClass.simpleName + ": " + (e.message ?: "")) }
        return result
    }

    private fun hasPdfSupport(bytes: ByteArray): Boolean {
        var i = 8; var name = ""
        while (i < bytes.size) {
            val tag = bytes[i++].toInt() and 255
            if (tag == 3) break
            if (tag <= 0x0f) continue
            if (i + 4 > bytes.size) break
            val nl = ((bytes[i].toInt() and 255) shl 8) or (bytes[i+1].toInt() and 255); i += 2
            if (i + nl + 2 > bytes.size) break
            if (nl > 0) name = String(bytes, i, nl, Charsets.UTF_8)
            i += nl
            val vl = ((bytes[i].toInt() and 255) shl 8) or (bytes[i+1].toInt() and 255); i += 2
            if (i + vl > bytes.size) break
            if (name == "document-format-supported" && String(bytes, i, vl, Charsets.UTF_8).equals("application/pdf", true)) return true
            i += vl
        }
        return false
    }
    private val printBusy = java.util.concurrent.atomic.AtomicBoolean(false)
    private val requestIds = java.util.concurrent.atomic.AtomicInteger(100)
    @Volatile private var lastJobId = 0
    @Volatile private var lastJobPrinter: Printer? = null
    private val jobEvents = JSONArray()
    private fun logJob(message: String) {
        synchronized(jobEvents) {
            jobEvents.put(JSONObject().put("time",java.time.Instant.now().toString()).put("message",message))
            if(jobEvents.length()>1000) jobEvents.remove(0)
            try {File(filesDir,"last-print.json").writeText(JSONObject().put("version","0.4.0").put("events",jobEvents).toString(2))}catch(_:Exception){}
        }
        // Technical IPP/SNMP messages remain in the exportable log, not on the home screen.
    }
    private fun ippUri(p: Printer) = "${if(p.secure) "ipps" else "ipp"}://${p.ip}:${p.port}/${p.path.trimStart('/')}"
    private fun exchange(p: Printer, operation: Int, op: List<Ipp.Attr> = emptyList(), job: List<Ipp.Attr> = emptyList(), file: File? = null): Ipp.Response {
        val id=requestIds.incrementAndGet();val header=Ipp.request(operation,id,ippUri(p),op,job)
        val conn=URL(endpoint(p)).openConnection() as HttpURLConnection
        if(conn is HttpsURLConnection && p.fingerprint.isNotBlank()) {
            conn.sslSocketFactory=pinnedFactory(p.fingerprint)
            conn.hostnameVerifier=javax.net.ssl.HostnameVerifier {host,_->host==p.ip}
        }
        conn.instanceFollowRedirects=false;conn.requestMethod="POST";conn.connectTimeout=7000;conn.readTimeout=60000
        conn.setRequestProperty("Content-Type","application/ipp");conn.doOutput=true
        conn.setFixedLengthStreamingMode(header.size.toLong()+(file?.length() ?: 0L))
        try {
            conn.outputStream.buffered().use {out->out.write(header);file?.inputStream()?.use {it.copyTo(out)}}
            val code=conn.responseCode
            if(code !in 200..299) throw java.io.IOException("HTTP $code; bei Übertragungsabbruch Drucker prüfen, nicht blind erneut senden")
            val result=Ipp.parse(conn.inputStream.use {it.readBytes()})
            check(result.id==id){"IPP Request-ID stimmt nicht überein"}
            logJob("IPP Operation $operation: Status 0x${result.status.toString(16)} ${result.text("status-message")}")
            result.requireSuccess();return result
        } finally {conn.disconnect()}
    }
    private fun detectMedia(w: Float,h: Float): String? {
        val a=minOf(w,h)*25.4/72;val b=maxOf(w,h)*25.4/72
        return when {
            kotlin.math.abs(a-210)<1.2 && kotlin.math.abs(b-297)<1.2 -> "iso_a4_210x297mm"
            kotlin.math.abs(a-297)<1.2 && kotlin.math.abs(b-420)<1.2 -> "iso_a3_297x420mm"
            else -> null
        }
    }
    private fun printPdf() {
        val p=active ?: return update("Bitte zuerst einen Drucker hinzufügen.")
        val uri=document ?: return update("Bitte zuerst ein PDF auswählen.")
        val mode=scaleMode.selectedItemPosition
        val parsedPercent=customScale.text.toString().replace(',','.').toDoubleOrNull()
        if(mode==4 && (parsedPercent==null || parsedPercent !in 10.0..400.0)) return update("Skalierung muss 10 bis 400 % betragen.")
        val percent=parsedPercent ?: 100.0
        if(mode==3) return update("Randlos bleibt bis zur Geräteprüfung gesperrt. Für maßhaltigen Druck Originalgröße wählen.")
        val paperChoice=paper.selectedItemPosition;val qualityChoice=quality.selectedItemPosition
        val gray=color.selectedItemPosition==1;val sideChoice=duplex.selectedItemPosition
        val sourceChoice=source.selectedItemPosition;val copyCount=copies.text.toString().toIntOrNull() ?: 1
        if(copyCount !in 1..99) return update("Exemplare: 1 bis 99 eingeben.")
        if(!printBusy.compareAndSet(false,true)) return update("Ein Druckauftrag läuft bereits.")
        showPrintProgress("Druckdaten werden vorbereitet …")
        thread(name="NovaPrint-PWG") {
            var spool:File?=null;var accepted=false
            try {
                spool=File.createTempFile("nova-",".pwg",cacheDir)
                logJob("Fähigkeiten werden live geprüft. Originalgröße: keine Verkleinerung; Randinhalte können abgeschnitten werden.")
                val caps=exchange(p,11,listOf(Ipp.a(0x49,"document-format","image/pwg-raster"),Ipp.a(0x44,"requested-attributes","all")))
                check(caps.has("document-format-supported","image/pwg-raster")){"Drucker meldet kein PWG-Raster."}
                val dpi=if(qualityChoice==1)600 else 300
                check(caps.has("pwg-raster-document-resolution-supported","${dpi}x$dpi/3")){"$dpi dpi für PWG nicht unterstützt."}
                check(caps.has("pwg-raster-document-type-supported",if(gray)"sgray_8" else "srgb_8")){"Rasterfarbraum nicht unterstützt."}
                val sides=when(sideChoice){1->"two-sided-long-edge";2->"two-sided-short-edge";else->"one-sided"}
                check(caps.has("sides-supported",sides)){"Duplexmodus nicht unterstützt."}
                val back=caps.values("pwg-raster-document-sheet-back").firstOrNull()?.toString() ?: ""
                if(sideChoice!=0) PwgRaster.backTransform(back,sideChoice,true)
                val sourceName=when(sourceChoice){1->"main";2->"alternate";else->"auto"}
                check(sourceChoice==0 || caps.has("media-source-supported",sourceName)){"Papierquelle nicht unterstützt."}
                val q=if(qualityChoice==1)5 else 4;val job=mutableListOf<Ipp.Attr>()
                job+=Ipp.a(0x21,"copies",copyCount);job+=Ipp.a(0x44,"sides",sides)
                check(caps.has("print-scaling-supported","none")){"Drucker bestätigt print-scaling=none nicht; keine stille Skalierung."}
                job+=Ipp.a(0x44,"print-scaling","none")
                if(caps.has("print-quality-supported",q)) job+=Ipp.a(0x23,"print-quality",q)
                val colorName=if(gray)"monochrome" else "color"
                if(caps.has("print-color-mode-supported",colorName))job+=Ipp.a(0x44,"print-color-mode",colorName)
                contentResolver.openFileDescriptor(uri,"r")!!.use {fd->PdfRenderer(fd).use {renderer->
                    activePageTotal=renderer.pageCount
                    val medias=mutableListOf<String>()
                    for(i in 0 until renderer.pageCount)renderer.openPage(i).use {pg->
                        val media=when(paperChoice){1->"iso_a4_210x297mm";2->"iso_a3_297x420mm";else->detectMedia(pg.width.toFloat(),pg.height.toFloat())}
                            ?: throw IllegalStateException("Seite ${i+1}: kein A3/A4-Format. Papier explizit wählen; Originalgröße bleibt unverändert.")
                        check(caps.has("media-supported",media)){"$media nicht unterstützt."};medias.add(media)
                    }
                    check(medias.distinct().size==1){"Gemischte A3/A4-PDF: bitte ein Zielformat wählen. Automatischer Fachwechsel noch nicht freigegeben."}
                    val media=medias.first();val mmW=if(media.contains("a3"))297 else 210;val mmH=if(mmW==297)420 else 297
                    if(sourceChoice==0)job+=Ipp.a(0x44,"media",media) else {
                        check(caps.has("media-col-supported","media-source")){"media-col/media-source fehlt."}
                        job+=Ipp.a(0x34,"media-col",listOf(Ipp.a(0x34,"media-size",listOf(Ipp.a(0x21,"x-dimension",mmW*100),Ipp.a(0x21,"y-dimension",mmH*100))),Ipp.a(0x44,"media-source",sourceName)))
                    }
                    val op=listOf(Ipp.a(0x42,"requesting-user-name","Nova-Print"),Ipp.a(0x42,"job-name","Nova-Print PDF"),Ipp.a(0x49,"document-format","image/pwg-raster"),Ipp.a(0x22,"ipp-attribute-fidelity",true))
                    if(caps.has("operations-supported",4)){val validation=exchange(p,4,op,job);check(validation.status==0){"Druckparameter wurden ersetzt/ignoriert: ${validation.attrs()}"}}
                    val w=PwgRaster.pixels(mmW.toDouble(),dpi);val h=PwgRaster.pixels(mmH.toDouble(),dpi);val channels=if(gray)1 else 3
                    spool!!.outputStream().buffered(65536).use {out->
                        out.write("RaS2".toByteArray(Charsets.US_ASCII))
                        for(index in 0 until renderer.pageCount)renderer.openPage(index).use {pg->
                            showPrintProgress("Seite ${index+1} von ${renderer.pageCount} wird vorbereitet …")
                            logJob("Rasterseite ${index+1}/${renderer.pageCount}: $mmW × $mmH mm, $dpi dpi")
                            val t=PwgRaster.backTransform(back,sideChoice,index%2==1)
                            out.write(PwgRaster.header(w,h,dpi,channels,renderer.pageCount,q,media,sourceChoice,sideChoice,t[0],t[1]))
                            val transform=Matrix().apply {setValues(PrintGeometry.matrix(w,h,dpi,pg.width,pg.height,mode,percent,t[0],t[1]))}
                            val pixels=IntArray(w);val row=ByteArray(w*channels);var y=0
                            while(y<h){
                                val rows=minOf(128,h-y);val bitmap=Bitmap.createBitmap(w,rows,Bitmap.Config.ARGB_8888)
                                try {
                                    bitmap.eraseColor(Color.WHITE)
                                    val band=Matrix(transform).apply {postTranslate(0f,-y.toFloat())}
                                    pg.render(bitmap,null,band,PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                                    for(line in 0 until rows){bitmap.getPixels(pixels,0,w,0,line,w,1)
                                        for(x in 0 until w){val v=pixels[x];val r=(v ushr 16)and 255;val g=(v ushr 8)and 255;val b=v and 255
                                            if(gray)row[x]=((r*77+g*150+b*29+128)shr 8).toByte()
                                            else{row[x*3]=r.toByte();row[x*3+1]=g.toByte();row[x*3+2]=b.toByte()}}
                                        PwgRaster.row(out,row,channels)
                                    }
                                }finally{bitmap.recycle()};y+=rows
                            }
                        }
                    }
                    logJob("${renderer.pageCount} Seiten vorbereitet (${spool!!.length()} Bytes). Übertragung als EIN Auftrag …")
                    showPrintProgress("Druckauftrag wird übertragen …")
                    val response=exchange(p,2,op,job,spool);accepted=true
                    lastJobId=response.integer("job-id",0);lastJobPrinter=p
                    logJob("Vom Drucker angenommen: Job $lastJobId. Physischer Ausdruck noch nicht geprüft."+if(response.status!=0)" ACHTUNG: IPP-Warnung ${response.attrs()}" else "")
                }}
                if(lastJobId>0)pollJob(p,lastJobId)
                refreshInk(true)
            }catch(e:Exception){showPrintProgress("Druckstatus prüfen – ${e.message?.take(65)}");logJob(if(accepted)"Auftrag angenommen; Statusabfrage fehlgeschlagen: ${e.message}" else "Druckvorgang nicht bestätigt: ${e.message}")}
            finally{spool?.delete();printBusy.set(false)}
        }
    }
    private fun pollJob(p:Printer,id:Int) {
        repeat(90){
            val r=exchange(p,9,listOf(Ipp.a(0x21,"job-id",id),Ipp.a(0x42,"requesting-user-name","Nova-Print")))
            val state=r.integer("job-state",0)
            val label=when(state){3->"wartet";4->"angehalten";5->"wird verarbeitet";6->"gestoppt";7->"abgebrochen";8->"fehlgeschlagen";9->"laut Drucker abgeschlossen";else->"Status unbekannt"}
            val done=r.integer("job-impressions-completed",-1)
            val total=r.integer("job-impressions",activePageTotal)
            when(state) {
                9 -> showPrintProgress("Druckauftrag abgeschlossen",100,true)
                7,8 -> showPrintProgress("Druckauftrag $label")
                3,4,5,6 -> {
                    val progress=if(done>=0 && total>0) (done*100/total).coerceIn(0,99) else null
                    showPrintProgress(when(state){5->"Wird gedruckt …";3->"Wartet auf Drucker …";4->"Druck pausiert";else->"Drucker angehalten"},progress)
                }
            }
            logJob("Job $id: $label. ${r.text("job-state-reasons")} ${r.text("job-state-message")}")
            if(state in 7..9)return;Thread.sleep(2000)
        }
        logJob("Job $id: Beobachtungszeit abgelaufen, kein Abschluss bestätigt. Status erneut abrufen.")
    }
    private fun ippRequest(operation: Int, pdf: ByteArray?, jobAttrs: List<Triple<Int, String, Any>>, printer: Printer): ByteArray {
        val out = ByteArrayOutputStream()
        fun byte(v: Int) { out.write(v and 255) }
        fun short(v: Int) { byte(v shr 8); byte(v) }
        fun integer(v: Int) { byte(v shr 24); byte(v shr 16); byte(v shr 8); byte(v) }
        fun attr(tag: Int, name: String, value: Any) {
            val key = name.toByteArray(Charsets.UTF_8)
            val data = if (value is Int) ByteBuffer.allocate(4).order(ByteOrder.BIG_ENDIAN).putInt(value).array() else value.toString().toByteArray(Charsets.UTF_8)
            byte(tag); short(key.size); out.write(key); short(data.size); out.write(data)
        }
        short(0x0200); short(operation); integer(1)
        byte(0x01)
        attr(0x47, "attributes-charset", "utf-8")
        attr(0x48, "attributes-natural-language", "en")
        attr(0x45, "printer-uri", "${if (printer.secure) "ipps" else "ipp"}://${printer.ip}:${printer.port}${printer.path.let { if (it.startsWith('/')) it else "/$it" }}")
        if (operation == 0x000B) attr(0x44, "requested-attributes", "all")
        if (operation == 0x0002) { attr(0x42, "requesting-user-name", "Nova-Print"); attr(0x42, "job-name", "Nova-Print PDF"); byte(0x02); jobAttrs.forEach { (t, n, v) -> attr(t, n, v) } }
        byte(0x03)
        if (pdf != null) out.write(pdf)
        val conn = URL(endpoint(printer)).openConnection() as HttpURLConnection
        if (conn is HttpsURLConnection && printer.fingerprint.isNotBlank()) {
            conn.sslSocketFactory = pinnedFactory(printer.fingerprint)
            conn.hostnameVerifier = javax.net.ssl.HostnameVerifier { host, _ -> host == printer.ip }
        }
        conn.requestMethod = "POST"; conn.connectTimeout = 6000; conn.readTimeout = 30000
        conn.setRequestProperty("Content-Type", "application/ipp")
        conn.doOutput = true
        conn.outputStream.use { it.write(out.toByteArray()) }
        val httpCode = conn.responseCode
        if (httpCode == 426) {
            conn.disconnect()
            throw IllegalStateException("HTTP 426: Drucker verlangt eine verschlüsselte IPPS-Verbindung")
        }
        val result = (if (httpCode in 200..299) conn.inputStream else conn.errorStream)?.use { it.readBytes() } ?: byteArrayOf()
        conn.disconnect()
        if (result.size < 8 || (result[0].toInt() != 2 && result[0].toInt() != 1))
            throw IllegalStateException("Ungültige IPP-Antwort (HTTP $httpCode, ${result.size} Bytes, ${if (printer.secure) "IPPS" else "IPP"}).")
        return result
    }
    private fun parseAttributes(bytes: ByteArray): String {
        val sb = StringBuilder(); var i = 8; var name = ""; var count = 0
        while (i < bytes.size && count < 350) {
            val tag = bytes[i++].toInt() and 255
            if (tag == 3) break
            if (tag <= 0x0f) continue
            if (i + 4 > bytes.size) break
            val nl = ((bytes[i].toInt() and 255) shl 8) or (bytes[i+1].toInt() and 255); i += 2
            if (i + nl + 2 > bytes.size) break
            if (nl > 0) name = String(bytes, i, nl, Charsets.UTF_8)
            i += nl
            val vl = ((bytes[i].toInt() and 255) shl 8) or (bytes[i+1].toInt() and 255); i += 2
            if (i + vl > bytes.size) break
            val v = if (tag == 0x21 || tag == 0x23) { if (vl == 4) ByteBuffer.wrap(bytes, i, 4).order(ByteOrder.BIG_ENDIAN).int.toString() else "(Zahl)" } else String(bytes, i, vl, Charsets.UTF_8).filter { it >= ' ' }.take(160)
            i += vl; count++
            if (name.contains("document-format") || name.contains("media") || name.contains("tray") || name.contains("supply") || name.contains("printer-state") || name.contains("print-quality") || name.contains("color") || name.contains("sides") || name.contains("resolution")) sb.append(name).append(": ").append(v).append('\n')
        }
        return if (sb.isEmpty()) "Keine auswertbaren relevanten Attribute erhalten." else sb.toString().take(14000)
    }
}
