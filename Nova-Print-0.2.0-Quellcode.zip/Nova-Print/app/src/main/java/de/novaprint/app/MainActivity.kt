package de.novaprint.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.pdf.PdfRenderer
import android.graphics.pdf.PdfDocument
import android.graphics.Bitmap
import android.graphics.RectF
import android.graphics.Canvas
import android.graphics.Paint
import android.provider.OpenableColumns
import android.view.Gravity
import android.widget.ImageView
import java.io.File
import kotlin.math.min
import android.os.ParcelFileDescriptor
import android.view.View
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.widget.LinearLayout.LayoutParams
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetAddress
import android.widget.*
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.security.SecureRandom
import java.security.cert.X509Certificate
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.SSLSocketFactory
import javax.net.ssl.X509TrustManager
import javax.net.ssl.TrustManager
import javax.net.ssl.SSLSocket
import android.app.AlertDialog
import android.graphics.drawable.ColorDrawable
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var status: TextView
    private data class Printer(val name: String, val ip: String, val port: Int, val path: String, val secure: Boolean = false, val fingerprint: String = "")
    private val printers = mutableListOf<Printer>()
    private val candidates = mutableListOf<Printer>()
    private var active: Printer? = null
    private lateinit var printerList: LinearLayout
    private lateinit var scanList: LinearLayout
    private lateinit var nsd: NsdManager
    private val listeners = mutableListOf<NsdManager.DiscoveryListener>()
    private var currentScreen: LinearLayout? = null
    private lateinit var paper: Spinner
    private lateinit var quality: Spinner
    private lateinit var color: Spinner
    private lateinit var duplex: Spinner
    private lateinit var source: Spinner
    private lateinit var copies: EditText
    private var document: Uri? = null
    private var pdfWidth = 0f
    private var pdfHeight = 0f
    private var supportedPdf = false
    private var discovered = ""
    private lateinit var pdfInfo: TextView
    private lateinit var preview: ImageView
    private lateinit var scaleMode: Spinner
    private lateinit var customScale: EditText
    private lateinit var scaleInfo: TextView
    private var pageCount = 0
    private var previewPage = 0
    private lateinit var pageLabel: TextView
    private var borderlessSupported = false
    private var borderlessMedia: String? = null
    private var fileName = ""
    private var previewBitmap: Bitmap? = null
    @Volatile private var previewGeneration = 0
    @Volatile private var documentGeneration = 0
    private lateinit var automaticPaperInfo: TextView
    private lateinit var automaticSourceInfo: TextView
    private var printerSourceDetail = "Vom Drucker nicht gemeldet"
    private var printerProbeKey = ""
    private var printerProbeBusy = false
    private var diagnosticReport = ""
    private val blue = Color.rgb(0, 125, 235)
    private val ink = Color.rgb(20, 42, 79)
    private fun dp(n: Int): Int = (resources.displayMetrics.density * n).toInt()
    private fun rounded(color: Int, radius: Int = 18): GradientDrawable = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(16),dp(14),dp(16),dp(14))
        background = rounded(Color.WHITE)
        elevation = dp(3).toFloat()
        layoutParams = LayoutParams(-1, -2).apply { setMargins(0,dp(7),0,dp(10)) }
    }
    private fun section(root: LinearLayout, text: String): LinearLayout = card().also { root.addView(it); it.addView(title(text,19f)) }
    private fun primary(label: String, action: () -> Unit): Button = button(label,action).apply {
        setTextColor(Color.WHITE); background = rounded(blue,14)
        layoutParams = LayoutParams(-1,dp(56)).apply { setMargins(0,dp(6),0,dp(8)) }
    }
    private fun printerImage(size: Int = 92): ImageView = ImageView(this).apply {
        setImageResource(R.drawable.printer_device)
        layoutParams = LayoutParams(dp(size),dp(size))
        scaleType = ImageView.ScaleType.FIT_CENTER
    }
    private fun fingerprint(cert: X509Certificate): String = MessageDigest.getInstance("SHA-256")
        .digest(cert.encoded).joinToString(":") { "%02X".format(it.toInt() and 255) }
    private fun captureCertificate(p: Printer): Pair<X509Certificate, String> {
        val context = SSLContext.getInstance("TLS")
        val trust = object : X509TrustManager {
            override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
            override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {}
            override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {}
        }
        context.init(null, arrayOf<TrustManager>(trust), SecureRandom())
        val socket = context.socketFactory.createSocket(p.ip, p.port) as SSLSocket
        socket.soTimeout = 7000
        return socket.use {
            it.startHandshake()
            val cert = it.session.peerCertificates[0] as X509Certificate
            Pair(cert, fingerprint(cert))
        }
    }
    private fun pinnedFactory(expected: String): SSLSocketFactory {
        val trust = object : X509TrustManager {
            override fun getAcceptedIssuers(): Array<X509Certificate> = emptyArray()
            override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {}
            override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {
                if (chain.isEmpty() || fingerprint(chain[0]) != expected)
                    throw java.security.cert.CertificateException("Das Druckerzertifikat hat sich geändert. Bitte Drucker neu bestätigen.")
            }
        }
        return SSLContext.getInstance("TLS").apply { init(null, arrayOf<TrustManager>(trust), SecureRandom()) }.socketFactory
    }
    private fun certificateDialog(p: Printer, fp: String, cert: X509Certificate, proceed: (Printer) -> Unit) {
        AlertDialog.Builder(this)
            .setTitle("🔒 Druckerzertifikat bestätigen")
            .setMessage("${p.name} (${p.ip}) verwendet ein nicht öffentlich bestätigtes Zertifikat.\n\nAusgestellt für: ${cert.subjectX500Principal.name}\nAussteller: ${cert.issuerX500Principal.name}\nGültig bis: ${cert.notAfter}\n\nSHA-256-Fingerabdruck:\n$fp\n\nNur bestätigen, wenn du diesen Drucker kennst. Bei Änderungen wirst du erneut gefragt.")
            .setPositiveButton("Vertrauen & hinzufügen") { _, _ -> proceed(p.copy(fingerprint = fp)) }
            .setNegativeButton("Abbrechen", null).show()
    }

    private fun title(value: String, size: Float = 18f): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(Color.rgb(24, 39, 58)); setPadding(0, 12, 0, 12)
    }
    private fun button(value: String, click: () -> Unit): Button = Button(this).apply {
        text = value; setAllCaps(false); setOnClickListener { click() }
    }
    private fun container(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(18), dp(16), dp(28)); setBackgroundColor(Color.rgb(241, 247, 253))
    }
    private fun show(content: LinearLayout) {
        currentScreen = content
        setContentView(ScrollView(this).apply { isFillViewport = true; addView(content) })
    }
    private fun loadPrinters() {
        val saved = getSharedPreferences("printers", MODE_PRIVATE)
        val arr = JSONArray(saved.getString("items", "[]"))
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            printers.add(Printer(o.optString("name"), o.optString("ip"), o.optInt("port", 631), o.optString("path", "/ipp/print"), o.optBoolean("secure", false), o.optString("fingerprint", "")))
        }
        val idx = saved.getInt("active", 0)
        active = printers.getOrNull(idx)
    }
    private fun savePrinters() {
        val arr = JSONArray()
        printers.forEach { arr.put(JSONObject().put("name", it.name).put("ip", it.ip).put("port", it.port).put("path", it.path).put("secure", it.secure).put("fingerprint", it.fingerprint)) }
        getSharedPreferences("printers", MODE_PRIVATE).edit().putString("items", arr.toString())
            .putInt("active", printers.indexOf(active).coerceAtLeast(0)).apply()
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        nsd = getSystemService(Context.NSD_SERVICE) as NsdManager
        loadPrinters()
        home()
        accept(intent)
    }
    private fun home() {
        val root = container()
        val head = card()
        val headRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL }
        headRow.addView(ImageView(this).apply { setImageResource(R.mipmap.ic_launcher); layoutParams = LayoutParams(dp(64),dp(64)) })
        headRow.addView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(title("Nova-Print",28f).apply { setTypeface(null,Typeface.BOLD) })
            addView(title("PDF maßhaltig drucken · v0.2.0",12f))
        })
        head.addView(headRow); root.addView(head)
        val printerSection = section(root,"🖨  Meine Drucker")
        printerSection.addView(primary("+ Drucker hinzufügen") { discoverScreen() })
        printerList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        printerSection.addView(printerList)
        drawSaved()
        val pdfSection = section(root,"📄  PDF drucken · Vorschau")
        pdfSection.addView(primary("PDF auswählen") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "application/pdf"; addCategory(Intent.CATEGORY_OPENABLE)
            }, 10)
        })
        pdfInfo = title(if (document == null) "Noch keine PDF ausgewählt" else "PDF: $fileName · $pageCount Seiten", 15f).apply { setTextColor(ink); setTypeface(null, Typeface.BOLD) }
        pdfSection.addView(pdfInfo)
        preview = ImageView(this).apply {
            setBackgroundColor(Color.rgb(233, 240, 248))
            scaleType = ImageView.ScaleType.FIT_CENTER
            adjustViewBounds = true
            minimumHeight = dp(190)
            layoutParams = LayoutParams(-1, dp(290)).apply { setMargins(0, dp(8), 0, dp(12)) }
        }
        pdfSection.addView(preview)
        previewBitmap?.let { preview.setImageBitmap(it) }
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        nav.addView(button("◀ Vorherige") { if (previewPage > 0) { previewPage--; renderPreview() } }, LayoutParams(0, dp(48), 1f))
        pageLabel = title("Seite ${previewPage + 1} / ${pageCount.coerceAtLeast(1)}", 13f).apply { gravity = Gravity.CENTER }
        nav.addView(pageLabel, LayoutParams(0, dp(48), 1f))
        nav.addView(button("Nächste ▶") { if (previewPage + 1 < pageCount) { previewPage++; renderPreview() } }, LayoutParams(0, dp(48), 1f))
        pdfSection.addView(nav)
        pdfSection.addView(title("Live-Vorschau: Papier, Seitenrand und Skalierung · durch Antippen vergrößern", 12f))
        preview.setOnClickListener {
            previewBitmap?.let { bitmap ->
                val large = ImageView(this).apply {
                    setImageBitmap(bitmap); adjustViewBounds = true; scaleType = ImageView.ScaleType.FIT_CENTER
                }
                AlertDialog.Builder(this).setTitle("Druckvorschau · Seite ${previewPage + 1}")
                    .setView(large).setPositiveButton("Schließen", null).show()
            }
        }
        fun spin(label: String, entries: List<String>): Spinner {
            pdfSection.addView(title(label, 14f))
            return Spinner(this).apply {
                adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, entries)
                pdfSection.addView(this)
            }
        }
        paper = spin("Papierformat", listOf("Automatisch", "A4", "A3"))
        automaticPaperInfo = title("Automatisch · nach PDF-Auswahl ermitteln", 12f)
        pdfSection.addView(automaticPaperInfo)
        scaleMode = spin("Skalierung", listOf("Originalgröße (100 %)", "An Druckbereich anpassen", "An Papierformat anpassen", "Randlos (falls unterstützt)", "Benutzerdefiniert (%)"))
        pdfSection.addView(title("Benutzerdefinierter Maßstab (%)", 14f))
        customScale = EditText(this).apply { setText("100"); inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL; pdfSection.addView(this) }
        scaleInfo = title("Originalgröße: 100 % · keine automatische Verkleinerung", 13f)
        pdfSection.addView(scaleInfo)
        scaleMode.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { updateScaleDescription() }
        }
        paper.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { refreshAutoInfo(); renderPreview() }
        }
        customScale.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { updateScaleDescription() }
            override fun afterTextChanged(s: android.text.Editable?) {}
        })
        quality = spin("Qualität", listOf("Normal", "Entwurf", "Hoch"))
        color = spin("Farbe", listOf("Farbe", "Schwarzweiß"))
        duplex = spin("Duplex", listOf("Einseitig", "Lange Kante", "Kurze Kante"))
        source = spin("Papierzufuhr", listOf("Automatisch", "Kassette 1", "Kassette 2", "Hinterer Einzug"))
        automaticSourceInfo = title("Automatisch · Fachbelegung wird geprüft", 12f)
        pdfSection.addView(automaticSourceInfo)
        source.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) { refreshAutoInfo() }
        }
        pdfSection.addView(title("Exemplare", 14f))
        copies = EditText(this).apply { setText("1"); inputType = 2; pdfSection.addView(this) }
        pdfSection.addView(button("Druckerfunktionen abfragen") { probe() })
        pdfSection.addView(primary("Vollständige Epson-Diagnose erstellen") { runFullDiagnostic() })
        pdfSection.addView(button("Diagnosebericht speichern") { saveDiagnostic() })
        pdfSection.addView(primary("PDF drucken") { printPdf() })
        status = title("Bitte PDF auswählen und Drucker verbinden.", 14f).apply { setTextIsSelectable(true) }
        pdfSection.addView(status)
        show(root)
        refreshAutoInfo()
        autoProbe()
    }
    private fun refreshAutoInfo() {
        if (!::automaticPaperInfo.isInitialized || !::paper.isInitialized) return
        val a3 = pdfWidth > 650f || pdfHeight > 900f
        val detected = if (a3) "A3 · 297 × 420 mm" else "A4 · 210 × 297 mm"
        automaticPaperInfo.text = when (paper.selectedItemPosition) {
            1 -> "Gewählt: A4 · 210 × 297 mm"
            2 -> "Gewählt: A3 · 297 × 420 mm"
            else -> if (document == null || pdfWidth <= 0f) "Automatisch · nach PDF-Auswahl ermitteln"
                    else "Automatisch → $detected · ${if (pdfWidth > pdfHeight) "Querformat" else "Hochformat"} (PDF)"
        }
        if (::automaticSourceInfo.isInitialized && ::source.isInitialized) {
            automaticSourceInfo.text = if (source.selectedItemPosition == 0)
                "Automatisch → $printerSourceDetail"
            else "Manuell → ${source.selectedItem}"
        }
    }
    private fun autoProbe() {
        val p = active ?: return
        val key = "${p.ip}:${p.port}${p.path}"
        if (printerProbeBusy || (printerProbeKey == key && discovered.isNotEmpty())) return
        probe()
    }
    private fun updateScaleDescription() {
        if (!::scaleInfo.isInitialized || !::scaleMode.isInitialized) return
        scaleInfo.text = when (scaleMode.selectedItemPosition) {
            0 -> "Originalgröße 100 %: PDF unverändert übertragen. Drucker-Randverhalten prüfen."
            1 -> "An Druckbereich anpassen: 5 mm Sicherheitsrand, proportionale Verkleinerung."
            2 -> "An Papierformat anpassen: proportional auf das Blattformat."
            3 -> if (borderlessSupported) "Randlos wird vom Drucker gemeldet. Achtung: Drucker kann intern überfüllen." else "Randlos: Druckerunterstützung noch nicht bestätigt."
            else -> "Benutzerdefiniert: ${if (::customScale.isInitialized) customScale.text else "100"} % des PDF-Originalmaßstabs."
        }
        renderPreview()
    }
    private fun renderPreview() {
        if (document == null || !::preview.isInitialized || !::scaleMode.isInitialized || !::paper.isInitialized) return
        val uri = document ?: return
        val generation = ++previewGeneration
        val selectedPage = previewPage
        val selectedPaper = paper.selectedItemPosition
        val selectedMode = scaleMode.selectedItemPosition
        val selectedPercent = if (::customScale.isInitialized) customScale.text.toString().toFloatOrNull() ?: 100f else 100f
        val widthPt = pdfWidth
        val heightPt = pdfHeight
        thread(name = "NovaPrint-PdfPreview") {
            try {
                val bitmap = buildPreviewBitmap(uri, selectedPage, selectedPaper, selectedMode, selectedPercent, widthPt, heightPt)
                runOnUiThread {
                    if (generation != previewGeneration || document != uri || isFinishing) {
                        bitmap.recycle()
                    } else {
                        previewBitmap = bitmap
                        preview.setImageBitmap(bitmap)
                        if (::pageLabel.isInitialized) pageLabel.text = "Seite ${selectedPage + 1} / $pageCount"
                    }
                }
            } catch (e: Exception) {
                runOnUiThread { if (generation == previewGeneration) update("Vorschau fehlgeschlagen: ${e.message}") }
            }
        }
    }
    private fun buildPreviewBitmap(uri: Uri, selectedPage: Int, selectedPaper: Int, selectedMode: Int, selectedPercent: Float, widthPt: Float, heightPt: Float): Bitmap {
        try {
            val mediaA3 = when (selectedPaper) {
                1 -> false
                2 -> true
                else -> widthPt > 650f || heightPt > 900f
            }
            val landscape = widthPt > heightPt
            val pw = if (mediaA3) 297f else 210f
            val ph = if (mediaA3) 420f else 297f
            val pageW = if (landscape) ph else pw
            val pageH = if (landscape) pw else ph
            val bitmap = Bitmap.createBitmap(520, (520f * pageH / pageW).toInt().coerceIn(200, 820), Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            canvas.drawColor(Color.rgb(223, 232, 242))
            val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
            val pad = 18f
            val paperRect = RectF(pad, pad, bitmap.width - pad, bitmap.height - pad)
            canvas.drawRect(paperRect, paint)
            val paperPxW = paperRect.width()
            val paperPxH = paperRect.height()
            val mode = selectedMode
            val custom = selectedPercent
            val margin = if (mode == 1) paperPxW * 5f / pageW else 0f
            val contentW = paperPxW - 2 * margin
            val contentH = paperPxH - 2 * margin
            contentResolver.openFileDescriptor(uri, "r")!!.use { fd ->
                PdfRenderer(fd).use { renderer ->
                    val index = selectedPage.coerceIn(0, renderer.pageCount - 1)
                    renderer.openPage(index).use { pg ->
                        val w = pg.width.toFloat()
                        val h = pg.height.toFloat()
                        val physicalScale = paperPxW / (pageW * 72f / 25.4f)
                        val factor = when (mode) {
                            1 -> min(contentW / w, contentH / h)
                            2, 3 -> min(paperPxW / w, paperPxH / h)
                            4 -> physicalScale * (custom / 100f)
                            else -> physicalScale
                        }
                        val targetW = w * factor
                        val targetH = h * factor
                        val left = paperRect.centerX() - targetW / 2
                        val top = paperRect.centerY() - targetH / 2
                        val img = Bitmap.createBitmap(pg.width.coerceAtMost(700), pg.height.coerceAtMost(1000), Bitmap.Config.ARGB_8888)
                        try {
                            img.eraseColor(Color.WHITE)
                            pg.render(img, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                            canvas.save()
                            canvas.clipRect(paperRect)
                            canvas.drawBitmap(img, null, RectF(left, top, left + targetW, top + targetH), Paint(Paint.FILTER_BITMAP_FLAG))
                            canvas.restore()
                        } finally { img.recycle() }
                        if (mode == 1) {
                            paint.color = Color.rgb(30, 140, 240)
                            paint.style = Paint.Style.STROKE
                            paint.strokeWidth = 2f
                            canvas.drawRect(paperRect.left + margin, paperRect.top + margin, paperRect.right - margin, paperRect.bottom - margin, paint)
                            paint.style = Paint.Style.FILL
                        }
                    }
                }
            }
            return bitmap
        } catch (e: Exception) { throw e }
    }
    private fun drawSaved() {
        printerList.removeAllViews()
        if (printers.isEmpty()) printerList.addView(title("Noch kein Drucker eingerichtet.", 14f))
        printers.forEach { p ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL; setPadding(dp(4),dp(10),dp(4),dp(10)) }
            row.addView(printerImage(82))
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            info.addView(title(p.name + if (p == active) "  ✓" else "", 16f))
            info.addView(title("${if (p.secure) "IPPS" else "IPP"} · ${p.ip}:${p.port} · ${p.path}", 12f))
            row.addView(info, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
            row.setOnClickListener { active = p; savePrinters(); home() }
            row.setOnLongClickListener { printerDetails(p); true }
            printerList.addView(row)
        }
    }
    private fun printerDetails(p: Printer) {
        val root = container()
        root.addView(button("← Zurück") { home() })
        root.addView(ImageView(this).apply { setImageResource(R.drawable.printer_device); layoutParams = LayoutParams(-1, 210) })
        root.addView(title(p.name, 22f))
        root.addView(title("${if (p.secure) "IPPS" else "IPP"} · ${p.ip}:${p.port}${p.path}", 14f))
        root.addView(button("Als Standarddrucker verwenden") { active = p; savePrinters(); home() })
        root.addView(button("Drucker entfernen") { printers.remove(p); if (active == p) active = printers.firstOrNull(); savePrinters(); home() })
        show(root)
    }
    private fun discoverScreen() {
        val root = container()
        root.addView(button("← Zurück") { stopDiscovery(); home() })
        root.addView(title("Drucker hinzufügen", 26f))
        val info = section(root,"📶  WLAN-Druckersuche")
        info.addView(title("IPP- und AirPrint-Drucker im gleichen WLAN werden automatisch erkannt.",14f))
        scanList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        info.addView(scanList)
        root.addView(primary("Erneut suchen") { startDiscovery() })
        root.addView(button("Drucker manuell hinzufügen") { stopDiscovery(); manualScreen() })
        show(root)
        startDiscovery()
    }
    private fun startDiscovery() {
        stopDiscovery(); candidates.clear(); scanList.removeAllViews()
        scanList.addView(title("Suche läuft …", 14f))
        listOf("_ipp._tcp.", "_ipps._tcp.").forEach { serviceType ->
            val listener = object : NsdManager.DiscoveryListener {
                override fun onDiscoveryStarted(regType: String) {}
                override fun onStartDiscoveryFailed(type: String, errorCode: Int) { runOnUiThread { scanList.addView(title("Suche nicht verfügbar: $errorCode", 14f)) } }
                override fun onStopDiscoveryFailed(type: String, errorCode: Int) {}
                override fun onDiscoveryStopped(type: String) {}
                override fun onServiceLost(service: NsdServiceInfo) {}
                override fun onServiceFound(service: NsdServiceInfo) {
                    try {
                        @Suppress("DEPRECATION")
                        nsd.resolveService(service, object : NsdManager.ResolveListener {
                            override fun onResolveFailed(info: NsdServiceInfo, code: Int) {}
                            override fun onServiceResolved(info: NsdServiceInfo) {
                                val ip = info.host?.hostAddress ?: return
                                val txt = info.attributes
                                val rp = txt["rp"]?.toString(Charsets.UTF_8)?.trim('/') ?: "ipp/print"
                                val model = txt["ty"]?.toString(Charsets.UTF_8)?.takeIf { it.isNotBlank() } ?: info.serviceName
                                val printer = Printer(model, ip, info.port, "/$rp", serviceType == "_ipps._tcp." || info.serviceType.startsWith("_ipps."))
                                runOnUiThread {
                                    val existing = candidates.indexOfFirst { it.ip == printer.ip }
                                    if (existing < 0) { candidates.add(printer); drawCandidates() }
                                    else if (printer.secure && !candidates[existing].secure) { candidates[existing] = printer; drawCandidates() }
                                }
                            }
                        })
                    } catch (_: Exception) { }
                }
            }
            listeners.add(listener)
            try { nsd.discoverServices(serviceType, NsdManager.PROTOCOL_DNS_SD, listener) }
            catch (e: Exception) { scanList.addView(title("Netzwerksuche: ${e.message}", 14f)) }
        }
    }
    private fun drawCandidates() {
        scanList.removeAllViews()
        candidates.forEach { p ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = android.view.Gravity.CENTER_VERTICAL; setPadding(0,dp(8),0,dp(8)) }
            row.addView(printerImage(72))
            val text = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            text.addView(title(p.name, 16f)); text.addView(title("${p.ip} · ${if (p.secure) "IPPS 🔒" else "IPP"}", 13f))
            row.addView(text, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
            row.addView(button("Hinzufügen") { verifyPrinter(p) })
            scanList.addView(row)
        }
    }
    private fun verifyPrinter(p: Printer) {
        scanList.addView(title("Prüfe ${p.name} …", 14f))
        thread { verifyAndOffer(p) }
    }
    private fun verifyAndOffer(p: Printer) {
        try {
            val actual = try {
                if (p.secure) p else {
                    try { ippRequest(0x000B, null, emptyList(), p); p }
                    catch (e: Exception) { if (e.message?.contains("426") == true) p.copy(secure = true) else throw e }
                }
            } catch (e: Exception) { throw e }
            if (actual.secure && actual.fingerprint.isBlank()) {
                val (cert, fp) = captureCertificate(actual)
                runOnUiThread { certificateDialog(actual, fp, cert) { approved ->
                    thread { verifyAndOffer(approved) }
                } }
                return
            }
            val response = ippRequest(0x000B, null, emptyList(), actual)
            val code = ((response[2].toInt() and 255) shl 8) or (response[3].toInt() and 255)
            if (code >= 0x0100) throw IllegalStateException("Drucker meldet IPP-Status 0x${code.toString(16)}")
            runOnUiThread {
                printers.removeAll { it.ip == actual.ip }
                printers.add(actual); active = actual; savePrinters(); stopDiscovery(); home()
            }
        } catch (e: Exception) { runOnUiThread {
            scanList.addView(title("Verbindung nicht möglich: ${e.message ?: "Unbekannter Netzwerkfehler"}",14f))
        } }
    }
    private fun manualScreen() {
        val root = container()
        root.addView(button("← Zurück") { discoverScreen() })
        root.addView(title("Drucker manuell hinzufügen", 22f))
        fun edit(label: String, value: String): EditText {
            root.addView(title(label, 14f))
            return EditText(this).apply { setText(value); root.addView(this) }
        }
        val name = edit("Name", "Epson WorkForce WF-7830DTWF")
        val ip = edit("IP-Adresse", "192.168.178.50")
        val port = edit("IPP-Port", "631")
        val path = edit("IPP-Pfad", "/ipp/print")
        val message = title("", 14f)
        root.addView(primary("Verbindung prüfen und hinzufügen") {
            val p = Printer(name.text.toString().trim(), ip.text.toString().trim(), port.text.toString().toIntOrNull() ?: 631, path.text.toString().trim())
            message.text = "Verbindung wird geprüft …"
            thread { verifyManual(p, message) }
        })
        root.addView(message)
        show(root)
    }
    private fun verifyManual(p: Printer, message: TextView) {
        try {
            val actual = if (p.secure) p else try { ippRequest(0x000B, null, emptyList(), p); p }
                catch (e: Exception) { if (e.message?.contains("426") == true) p.copy(secure = true) else throw e }
            if (actual.secure && actual.fingerprint.isBlank()) {
                val (cert, fp) = captureCertificate(actual)
                runOnUiThread { certificateDialog(actual, fp, cert) { approved -> thread { verifyManual(approved, message) } } }
                return
            }
            val response = ippRequest(0x000B, null, emptyList(), actual)
            val code = ((response[2].toInt() and 255) shl 8) or (response[3].toInt() and 255)
            if (code >= 0x0100) throw IllegalStateException("IPP-Status 0x${code.toString(16)}")
            runOnUiThread { printers.removeAll { it.ip == actual.ip }; printers.add(actual); active = actual; savePrinters(); home() }
        } catch (e: Exception) { runOnUiThread { message.text = "Verbindung fehlgeschlagen: ${e.message}" } }
    }
    private fun stopDiscovery() {
        listeners.forEach { try { nsd.stopServiceDiscovery(it) } catch (_: Exception) {} }
        listeners.clear()
    }
    override fun onDestroy() { stopDiscovery(); super.onDestroy() }

    @Deprecated("Legacy picker callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 10 && resultCode == RESULT_OK) data?.data?.let { setDocument(it) }
        if (requestCode == 81 && resultCode == RESULT_OK) data?.data?.let { uri ->
            try { contentResolver.openOutputStream(uri)?.use { it.write(diagnosticReport.toByteArray(Charsets.UTF_8)) }; update("Diagnosebericht gespeichert.") }
            catch (e: Exception) { update("Speichern fehlgeschlagen: ${e.message}") }
        }
    }
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); accept(intent) }
    private fun accept(i: Intent?) {
        val uri = when (i?.action) {
            Intent.ACTION_SEND -> if (android.os.Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java) else @Suppress("DEPRECATION") i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
            Intent.ACTION_VIEW -> i.data
            else -> null
        }
        if (uri != null) setDocument(uri)
    }
    private fun setDocument(uri: Uri) {
        document = uri
        val generation = ++documentGeneration
        ++previewGeneration
        pdfWidth = 0f
        pdfHeight = 0f
        pageCount = 0
        previewPage = 0
        if (::pdfInfo.isInitialized) pdfInfo.text = "PDF wird geladen …"
        if (::preview.isInitialized) preview.setImageDrawable(null)
        update("PDF wird im Hintergrund eingelesen …")
        thread(name = "NovaPrint-PdfOpen") {
            try {
                var name = "Dokument.pdf"
                try {
                    contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                        if (cursor.moveToFirst()) name = cursor.getString(0) ?: name
                    }
                } catch (_: Exception) {}
                var count = 0
                var width = 0f
                var height = 0f
                contentResolver.openFileDescriptor(uri, "r")!!.use { fd ->
                    PdfRenderer(fd).use { renderer ->
                        count = renderer.pageCount
                        if (count < 1) throw IllegalArgumentException("PDF enthält keine Seiten")
                        renderer.openPage(0).use { page ->
                            width = page.width.toFloat()
                            height = page.height.toFloat()
                        }
                    }
                }
                runOnUiThread {
                    if (generation != documentGeneration || document != uri || isFinishing) return@runOnUiThread
                    fileName = name
                    pageCount = count
                    pdfWidth = width
                    pdfHeight = height
                    if (::pdfInfo.isInitialized) pdfInfo.text =
                        "✓ $name · $count Seiten · ${"%.0f".format(width * 25.4 / 72)} × ${"%.0f".format(height * 25.4 / 72)} mm"
                    refreshAutoInfo()
                    renderPreview()
                    update("PDF geladen: $name · $count Seiten.")
                }
            } catch (e: Exception) {
                runOnUiThread { if (generation == documentGeneration) update("PDF konnte nicht geöffnet werden: ${e.message}") }
            }
        }
    }
    private fun scaledPdf(uri: Uri, media: String, mode: Int, percent: Double): ByteArray {
        val mmW = if (media.startsWith("iso_a3")) 297.0 else 210.0
        val mmH = if (media.startsWith("iso_a3")) 420.0 else 297.0
        val landscape = pdfWidth > pdfHeight
        val pageW = ((if (landscape) mmH else mmW) * 72 / 25.4).toInt()
        val pageH = ((if (landscape) mmW else mmH) * 72 / 25.4).toInt()
        val out = ByteArrayOutputStream()
        val result = PdfDocument()
        try {
            contentResolver.openFileDescriptor(uri, "r")!!.use { fd ->
                PdfRenderer(fd).use { renderer ->
                    for (index in 0 until renderer.pageCount) {
                        renderer.openPage(index).use { original ->
                            val info = PdfDocument.PageInfo.Builder(pageW, pageH, index + 1).create()
                            val page = result.startPage(info)
                            page.canvas.drawColor(Color.WHITE)
                            val margin = if (mode == 1) 5f * 72f / 25.4f else 0f
                            val factor = when (mode) {
                                1 -> min((pageW - 2 * margin) / original.width, (pageH - 2 * margin) / original.height)
                                2, 3 -> min(pageW.toFloat() / original.width, pageH.toFloat() / original.height)
                                else -> (percent / 100.0).toFloat()
                            }
                            val targetW = original.width * factor
                            val targetH = original.height * factor
                            val left = (pageW - targetW) / 2f
                            val top = (pageH - targetH) / 2f
                            val renderScale = 2.5f
                            val bw = (original.width * renderScale).toInt().coerceAtLeast(1)
                            val bh = (original.height * renderScale).toInt().coerceAtLeast(1)
                            val bitmap = Bitmap.createBitmap(bw, bh, Bitmap.Config.RGB_565)
                            try {
                                bitmap.eraseColor(Color.WHITE)
                                original.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                                page.canvas.drawBitmap(bitmap, null, RectF(left, top, left + targetW, top + targetH), null)
                            } finally { bitmap.recycle() }
                            result.finishPage(page)
                        }
                    }
                }
            }
            result.writeTo(out)
            return out.toByteArray()
        } finally { result.close() }
    }
    private fun update(msg: String) { runOnUiThread { status.text = msg } }
    private fun endpoint(p: Printer): String = "${if (p.secure) "https" else "http"}://${p.ip}:${p.port}${p.path.let { if (it.startsWith('/')) it else "/$it" }}"
    private fun probe() {
        val printer = active ?: return update("Bitte zuerst einen Drucker hinzufügen.")
        if (printerProbeBusy) return
        printerProbeBusy = true
        update("Druckerfunktionen werden im Hintergrund abgefragt …")
        thread {
            try {
                val response = ippRequest(0x000B, null, emptyList(), printer)
                val parsed = parseAttributes(response)
                discovered = parsed
                printerProbeKey = "${printer.ip}:${printer.port}${printer.path}"
                supportedPdf = hasPdfSupport(response)
                borderlessSupported = parsed.contains("borderless", true) || parsed.contains("randlos", true)
                borderlessMedia = Regex("""(?m)^media[^:]*: ([^\\n]*borderless[^\\n]*)""", RegexOption.IGNORE_CASE).find(parsed)?.groupValues?.get(1)?.trim()
                val sources = Regex("""(?m)^media-source-supported: (.+)$""").findAll(parsed).map { it.groupValues[1].trim() }.distinct().toList()
                printerSourceDetail = when {
                    sources.isEmpty() -> "Fachbelegung vom Drucker nicht gemeldet"
                    sources.size == 1 -> "${sources.first()} (vom Drucker gemeldet; Papierbelegung unbekannt)"
                    else -> "${sources.joinToString(", ")} verfügbar; belegtes Fach nicht ermittelbar"
                }
                runOnUiThread { refreshAutoInfo() }
                update("Druckerabfrage abgeschlossen. PDF-Direktdruck: ${if (supportedPdf) "unterstützt" else "nicht bestätigt"}. Papierzufuhr: $printerSourceDetail")
            } catch (e: Exception) { supportedPdf = false; update("IPP-Abfrage fehlgeschlagen: ${e.message}") }
            finally { printerProbeBusy = false }
        }
    }

    private fun saveDiagnostic() {
        if (diagnosticReport.isBlank()) return update("Bitte zuerst die vollständige Diagnose durchführen.")
        startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/json"
            putExtra(Intent.EXTRA_TITLE, "Nova-Print-Epson-Diagnose.json")
        }, 81)
    }

    // Read-only discovery. No settings are changed and no print jobs are submitted.
    private fun runFullDiagnostic() {
        val p = active ?: return update("Bitte zuerst einen Drucker auswählen.")
        update("Vollständige Diagnose läuft: IPP, SNMP, HTTP, Scanner und Netzwerk …")
        thread(name = "NovaPrint-DeviceDiagnostic") {
            val report = JSONObject()
            report.put("schema", "Nova-Print device diagnostics v1")
            report.put("timestamp", java.time.Instant.now().toString())
            report.put("printer", JSONObject().put("name", p.name).put("address", p.ip).put("ippPort", p.port).put("ippPath", p.path))
            val ports = JSONObject()
            for (port in listOf(80, 443, 515, 631, 9100, 5357, 1865, 2968, 3289)) {
                ports.put(port.toString(), try {
                    java.net.Socket().use { sock -> sock.connect(java.net.InetSocketAddress(p.ip, port), 950); "open" }
                } catch (_: Exception) { "closed-or-filtered" })
            }
            report.put("tcpPorts", ports)
            try {
                val raw = ippRequest(0x000B, null, emptyList(), p)
                report.put("ipp", JSONObject()
                    .put("statusCode", ((raw[2].toInt() and 255) shl 8) or (raw[3].toInt() and 255))
                    .put("attributes", fullIppAttributes(raw))
                    .put("rawResponseBase64", android.util.Base64.encodeToString(raw, android.util.Base64.NO_WRAP)))
            } catch (e: Exception) { report.put("ippError", e.toString()) }
            val snmp = JSONObject()
            // Standard MIB-II + Printer-MIB supply, input tray, status and identity tables.
            for ((label, oid) in listOf(
                "systemDescription" to "1.3.6.1.2.1.1.1.0",
                "systemName" to "1.3.6.1.2.1.1.5.0",
                "printerStatus" to "1.3.6.1.2.1.25.3.5.1.1.1",
                "printerDetectedError" to "1.3.6.1.2.1.25.3.5.1.2.1",
                "printerGeneral" to "1.3.6.1.2.1.43.5.1.1.16.1",
                "inputTrayName1" to "1.3.6.1.2.1.43.8.2.1.13.1.1",
                "inputTrayName2" to "1.3.6.1.2.1.43.8.2.1.13.1.2",
                "inputTrayLevel1" to "1.3.6.1.2.1.43.8.2.1.10.1.1",
                "inputTrayLevel2" to "1.3.6.1.2.1.43.8.2.1.10.1.2",
                "supplyDescription1" to "1.3.6.1.2.1.43.11.1.1.6.1.1",
                "supplyLevel1" to "1.3.6.1.2.1.43.11.1.1.9.1.1",
                "supplyMax1" to "1.3.6.1.2.1.43.11.1.1.8.1.1"
            )) snmp.put(label, snmpGet(p.ip, oid))
            report.put("snmp", snmp)
            val http = JSONObject()
            for (path in listOf("/", "/eSCL/ScannerCapabilities", "/eSCL/ScannerStatus", "/DevMgmt/ProductConfigDyn.xml")) {
                http.put(path, httpDiagnostic(p.ip, path))
            }
            report.put("httpAndScan", http)
            diagnosticReport = report.toString(2)
            runOnUiThread {
                update("Diagnose abgeschlossen. IPP, SNMP, Netzwerk und Scan-Schnittstellen geprüft. Bitte auf ‚Diagnosebericht speichern‘ tippen und die JSON-Datei hier hochladen. Keine Drucker-Einstellungen verändert.")
            }
        }
    }

    private fun httpDiagnostic(host: String, path: String): JSONObject {
        val result = JSONObject()
        try {
            val conn = URL("http://$host$path").openConnection() as HttpURLConnection
            conn.connectTimeout = 2000; conn.readTimeout = 2500
            conn.instanceFollowRedirects = false
            try {
                result.put("status", conn.responseCode)
                result.put("contentType", conn.contentType ?: "")
                val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
                result.put("body", stream?.use { String(it.readNBytes(65536), Charsets.UTF_8) } ?: "")
            } finally { conn.disconnect() }
        } catch (e: Exception) { result.put("error", e.toString()) }
        return result
    }

    private fun fullIppAttributes(bytes: ByteArray): JSONArray {
        val array = JSONArray(); var i = 8; var name = ""; var group = 0; var count = 0
        while (i < bytes.size && count < 3000) {
            val tag = bytes[i++].toInt() and 255
            if (tag == 3) break
            if (tag <= 0x0f) { group = tag; continue }
            if (i + 4 > bytes.size) break
            val nl = ((bytes[i].toInt() and 255) shl 8) or (bytes[i+1].toInt() and 255); i += 2
            if (i + nl + 2 > bytes.size) break
            if (nl > 0) name = String(bytes, i, nl, Charsets.UTF_8)
            i += nl
            val vl = ((bytes[i].toInt() and 255) shl 8) or (bytes[i+1].toInt() and 255); i += 2
            if (i + vl > bytes.size) break
            val data = bytes.copyOfRange(i, i + vl); i += vl; count++
            val value = when {
                tag == 0x21 || tag == 0x23 -> if (vl == 4) ByteBuffer.wrap(data).order(ByteOrder.BIG_ENDIAN).int.toString() else "invalid integer"
                tag == 0x32 && vl == 9 -> "${ByteBuffer.wrap(data, 0, 4).int}x${ByteBuffer.wrap(data, 4, 4).int} dpi/unit:${data[8].toInt() and 255}"
                tag == 0x22 && vl == 1 -> (data[0].toInt() != 0).toString()
                tag in 0x30..0x3f || tag == 0x34 || tag == 0x4a -> "base64:" + android.util.Base64.encodeToString(data, android.util.Base64.NO_WRAP)
                else -> String(data, Charsets.UTF_8)
            }
            array.put(JSONObject().put("group", group).put("tag", tag).put("name", name).put("value", value))
        }
        return array
    }

    private fun snmpGet(host: String, oid: String): JSONObject {
        val result = JSONObject()
        try {
            fun len(n: Int): ByteArray = if (n < 128) byteArrayOf(n.toByte()) else byteArrayOf(0x82.toByte(), (n shr 8).toByte(), n.toByte())
            fun tlv(tag: Int, data: ByteArray): ByteArray = byteArrayOf(tag.toByte()) + len(data.size) + data
            val arcs = oid.split('.').map { it.toLong() }
            val oidBytes = ByteArrayOutputStream(); oidBytes.write((arcs[0] * 40 + arcs[1]).toInt())
            for (arc in arcs.drop(2)) {
                var v = arc; val parts = mutableListOf((v and 127).toInt()); v = v shr 7
                while (v > 0) { parts.add(0, ((v and 127) or 128).toInt()); v = v shr 7 }
                parts.forEach { oidBytes.write(it) }
            }
            val varbind = tlv(0x30, tlv(0x06, oidBytes.toByteArray()) + tlv(0x05, byteArrayOf()))
            val request = tlv(0xA0, tlv(0x02, byteArrayOf(1)) + tlv(0x02, byteArrayOf(0)) + tlv(0x02, byteArrayOf(0)) + tlv(0x30, varbind))
            val message = tlv(0x30, tlv(0x02, byteArrayOf(0)) + tlv(0x04, "public".toByteArray()) + request)
            java.net.DatagramSocket().use { sock ->
                sock.soTimeout = 750
                sock.send(java.net.DatagramPacket(message, message.size, InetAddress.getByName(host), 161))
                val buffer = ByteArray(8192); val packet = java.net.DatagramPacket(buffer, buffer.size)
                sock.receive(packet)
                result.put("responseBase64", android.util.Base64.encodeToString(buffer.copyOf(packet.length), android.util.Base64.NO_WRAP))
            }
        } catch (e: Exception) { result.put("error", e.javaClass.simpleName + ": " + (e.message ?: "")) }
        return result
    }

    private fun hasPdfSupport(bytes: ByteArray): Boolean {
        var i = 8; var name = ""
        while (i < bytes.size) {
            val tag = bytes[i++].toInt() and 255
            if (tag == 3) break
            if (tag <= 0x0f) continue
            if (i + 4 > bytes.size) break
            val nl = ((bytes[i].toInt() and 255) shl 8) or (bytes[i+1].toInt() and 255); i += 2
            if (i + nl + 2 > bytes.size) break
            if (nl > 0) name = String(bytes, i, nl, Charsets.UTF_8)
            i += nl
            val vl = ((bytes[i].toInt() and 255) shl 8) or (bytes[i+1].toInt() and 255); i += 2
            if (i + vl > bytes.size) break
            if (name == "document-format-supported" && String(bytes, i, vl, Charsets.UTF_8).equals("application/pdf", true)) return true
            i += vl
        }
        return false
    }
    private fun printPdf() {
        val printer = active ?: return update("Bitte zuerst einen Drucker hinzufügen.")
        val uri = document ?: return update("Bitte zuerst ein PDF auswählen.")
        if (!supportedPdf) return update("Druck gestoppt: Direkter PDF-Druck über IPP wurde noch nicht bestätigt. Erst Druckerfunktionen abfragen. Keine automatische Verkleinerung als Ersatz.")
        val mode = scaleMode.selectedItemPosition
        val percent = customScale.text.toString().toDoubleOrNull()
        if (mode == 4 && (percent == null || percent < 10 || percent > 400)) return update("Bitte Skalierung zwischen 10 und 400 % eingeben.")
        if (mode == 3 && !borderlessSupported) return update("Randlos wird in den IPP-Druckerfunktionen nicht als unterstützt gemeldet. Bitte eine andere Skalierung wählen.")
        update("PDF wird vorbereitet …")
        val selectedPaper = paper.selectedItemPosition
        val selectedQuality = quality.selectedItemPosition
        val selectedColor = color.selectedItemPosition
        val selectedDuplex = duplex.selectedItemPosition
        val selectedSource = source.selectedItemPosition
        val n = copies.text.toString().toIntOrNull()?.coerceIn(1, 99) ?: 1
        thread {
            try {
                val selectedMedia = when (selectedPaper) { 1 -> "iso_a4_210x297mm"; 2 -> "iso_a3_297x420mm"; else -> if (pdfWidth > 650 || pdfHeight > 900) "iso_a3_297x420mm" else "iso_a4_210x297mm" }
                val bytes = if (mode == 0) contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                    else scaledPdf(uri, selectedMedia, mode, percent ?: 100.0)
                if (bytes.size < 5 || String(bytes.copyOfRange(0, 5)) != "%PDF-") throw IllegalArgumentException("Keine gültige PDF-Datei")
                val attrs = mutableListOf<Triple<Int, String, Any>>()
                attrs += Triple(0x49, "document-format", "application/pdf")
                attrs += Triple(0x44, "print-color-mode", if (selectedColor == 0) "color" else "monochrome")
                attrs += Triple(0x44, "sides", when (selectedDuplex) { 1 -> "two-sided-long-edge"; 2 -> "two-sided-short-edge"; else -> "one-sided" })
                attrs += Triple(0x23, "print-quality", when (selectedQuality) { 1 -> 3; 2 -> 5; else -> 4 })
                attrs += Triple(0x21, "copies", n)
                val media = if (mode == 3) borderlessMedia ?: selectedMedia else selectedMedia
                attrs += Triple(0x44, "media", media)
                if (selectedSource != 0) attrs += Triple(0x44, "media-source", when (selectedSource) { 1 -> "tray-1"; 2 -> "tray-2"; else -> "manual" })
                val response = ippRequest(0x0002, bytes, attrs, printer)
                val code = ((response[2].toInt() and 255) shl 8) or (response[3].toInt() and 255)
                update(if (code < 0x0100) "Druckauftrag angenommen (IPP 0x${code.toString(16)}). ${if (mode == 0) "Original-PDF unverändert übertragen." else "Skalierte PDF erstellt und übertragen."} Maßhaltigkeit am Ausdruck prüfen." else "Drucker hat Auftrag abgelehnt: IPP 0x${code.toString(16)}\n${parseAttributes(response)}")
            } catch (e: Exception) { update("Druck fehlgeschlagen: ${e.message}") }
        }
    }
    private fun ippRequest(operation: Int, pdf: ByteArray?, jobAttrs: List<Triple<Int, String, Any>>, printer: Printer): ByteArray {
        val out = ByteArrayOutputStream()
        fun byte(v: Int) { out.write(v and 255) }
        fun short(v: Int) { byte(v shr 8); byte(v) }
        fun integer(v: Int) { byte(v shr 24); byte(v shr 16); byte(v shr 8); byte(v) }
        fun attr(tag: Int, name: String, value: Any) {
            val key = name.toByteArray(Charsets.UTF_8)
            val data = if (value is Int) ByteBuffer.allocate(4).order(ByteOrder.BIG_ENDIAN).putInt(value).array() else value.toString().toByteArray(Charsets.UTF_8)
            byte(tag); short(key.size); out.write(key); short(data.size); out.write(data)
        }
        short(0x0200); short(operation); integer(1)
        byte(0x01)
        attr(0x47, "attributes-charset", "utf-8")
        attr(0x48, "attributes-natural-language", "en")
        attr(0x45, "printer-uri", "${if (printer.secure) "ipps" else "ipp"}://${printer.ip}:${printer.port}${printer.path.let { if (it.startsWith('/')) it else "/$it" }}")
        if (operation == 0x000B) attr(0x44, "requested-attributes", "all")
        if (operation == 0x0002) { attr(0x42, "requesting-user-name", "Nova-Print"); attr(0x42, "job-name", "Nova-Print PDF"); byte(0x02); jobAttrs.forEach { (t, n, v) -> attr(t, n, v) } }
        byte(0x03)
        if (pdf != null) out.write(pdf)
        val conn = URL(endpoint(printer)).openConnection() as HttpURLConnection
        if (conn is HttpsURLConnection && printer.fingerprint.isNotBlank()) {
            conn.sslSocketFactory = pinnedFactory(printer.fingerprint)
            conn.hostnameVerifier = javax.net.ssl.HostnameVerifier { host, _ -> host == printer.ip }
        }
        conn.requestMethod = "POST"; conn.connectTimeout = 6000; conn.readTimeout = 30000
        conn.setRequestProperty("Content-Type", "application/ipp")
        conn.doOutput = true
        conn.outputStream.use { it.write(out.toByteArray()) }
        val httpCode = conn.responseCode
        if (httpCode == 426) {
            conn.disconnect()
            throw IllegalStateException("HTTP 426: Drucker verlangt eine verschlüsselte IPPS-Verbindung")
        }
        val result = (if (httpCode in 200..299) conn.inputStream else conn.errorStream)?.use { it.readBytes() } ?: byteArrayOf()
        conn.disconnect()
        if (result.size < 8 || (result[0].toInt() != 2 && result[0].toInt() != 1))
            throw IllegalStateException("Ungültige IPP-Antwort (HTTP $httpCode, ${result.size} Bytes, ${if (printer.secure) "IPPS" else "IPP"}).")
        return result
    }
    private fun parseAttributes(bytes: ByteArray): String {
        val sb = StringBuilder(); var i = 8; var name = ""; var count = 0
        while (i < bytes.size && count < 350) {
            val tag = bytes[i++].toInt() and 255
            if (tag == 3) break
            if (tag <= 0x0f) continue
            if (i + 4 > bytes.size) break
            val nl = ((bytes[i].toInt() and 255) shl 8) or (bytes[i+1].toInt() and 255); i += 2
            if (i + nl + 2 > bytes.size) break
            if (nl > 0) name = String(bytes, i, nl, Charsets.UTF_8)
            i += nl
            val vl = ((bytes[i].toInt() and 255) shl 8) or (bytes[i+1].toInt() and 255); i += 2
            if (i + vl > bytes.size) break
            val v = if (tag == 0x21 || tag == 0x23) { if (vl == 4) ByteBuffer.wrap(bytes, i, 4).order(ByteOrder.BIG_ENDIAN).int.toString() else "(Zahl)" } else String(bytes, i, vl, Charsets.UTF_8).filter { it >= ' ' }.take(160)
            i += vl; count++
            if (name.contains("document-format") || name.contains("media") || name.contains("tray") || name.contains("supply") || name.contains("printer-state") || name.contains("print-quality") || name.contains("color") || name.contains("sides") || name.contains("resolution")) sb.append(name).append(": ").append(v).append('\n')
        }
        return if (sb.isEmpty()) "Keine auswertbaren relevanten Attribute erhalten." else sb.toString().take(14000)
    }
}
