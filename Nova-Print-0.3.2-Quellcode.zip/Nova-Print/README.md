# Nova-Print 0.3.0
Private Android-App: A3/A4-PDF als mehrseitiges PWG-Raster über IPPS, 100 % ohne automatische Skalierung, 300/600 dpi, geprüfte IPP-Collections, Duplextransformation, Live-Status und Druckprotokoll.

Build: JDK 17, Android SDK 35, Gradle 8.9.

```sh
sh tests/run.sh
gradle :app:assembleDebug :app:lintDebug --no-daemon
```

Optionaler unabhängiger Rastertest mit Python und libcups:

```sh
python3 tests/cups_validate.py
```

APK: app/build/outputs/apk/debug/app-debug.apk. Universeller Workflow in .github/workflows/android.yml. Anleitungen, technische Details, Testbericht und Messvorlagen unter docs/.

Druckerannahme und physische Maßhaltigkeit benötigen einen Hardwaretest. Scannen/Kopieren sind noch nicht implementiert; Dienstsuche ist vorhanden. Quellpaket mit privatem Debug-Schlüssel vertraulich aufbewahren.
