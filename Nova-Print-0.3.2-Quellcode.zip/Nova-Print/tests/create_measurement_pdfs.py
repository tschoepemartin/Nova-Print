from reportlab.pdfgen import canvas
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from pathlib import Path
font=Path('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf')
if font.exists():pdfmetrics.registerFont(TTFont('PrintFont',str(font)));family='PrintFont'
else:family='Helvetica'
for fmt,w,h in [('A4',210,297),('A3',297,420)]:
 c=canvas.Canvas(f'output/Nova-Print-Masstest-{fmt}.pdf',pagesize=(w*mm,h*mm))
 for page in range(2):
  W,H=(w,h) if page==0 else (h,w);c.setPageSize((W*mm,H*mm));c.setStrokeColorRGB(.03,.15,.25);c.setFillColorRGB(.03,.15,.25)
  c.setFont(family,18);c.drawString(20*mm,(H-25)*mm,f'Nova-Print | {fmt} | 100 %')
  c.setFont(family,10);c.drawString(20*mm,(H-33)*mm,f'Seite {page+1}/2 - '+('Hochformat' if page==0 else 'Querformat')+' - Version 0.3.0')
  c.setFont(family,9);c.drawString(20*mm,(H-42)*mm,'Originalgröße wählen. Nach dem Druck mit einem Lineal messen.')
  x,y=30*mm,(H-160)*mm;c.setLineWidth(.2*mm);c.rect(x,y,100*mm,100*mm)
  c.setFont(family,12);c.drawCentredString(x+50*mm,y+50*mm,'100,00 × 100,00 mm')
  c.setFont(family,8);c.drawCentredString(x+50*mm,y+43*mm,'Zwischen den Linienmitten messen')
  for i in range(101):
   t=(4 if i%10==0 else 2 if i%5==0 else 1)*mm
   c.line(x+i*mm,y-10*mm,x+i*mm,y-10*mm-t);c.line(x+110*mm,y+i*mm,x+110*mm+t,y+i*mm)
   if i%10==0:c.drawCentredString(x+i*mm,y-19*mm,str(i))
  c.line(x,y-10*mm,x+100*mm,y-10*mm);c.line(x+110*mm,y,x+110*mm,y+100*mm)
  c.setFont(family,9);c.drawString(20*mm,23*mm,'Messwerte: waagerecht ______ mm    senkrecht ______ mm')
  c.setFont(family,7);c.drawString(20*mm,16*mm,'Richtwert: 100,0 mm ± 0,5 mm. Abweichung dokumentieren; keine automatische Korrektur.')
  c.showPage()
 c.save()
