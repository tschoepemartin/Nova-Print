import ctypes as C,os,struct
lib=C.CDLL('libcups.so.2');lib.cupsRasterOpen.argtypes=[C.c_int,C.c_int];lib.cupsRasterOpen.restype=C.c_void_p
lib.cupsRasterReadHeader2.argtypes=[C.c_void_p,C.c_void_p];lib.cupsRasterReadHeader2.restype=C.c_uint
lib.cupsRasterReadPixels.argtypes=[C.c_void_p,C.c_void_p,C.c_uint];lib.cupsRasterReadPixels.restype=C.c_uint;lib.cupsRasterClose.argtypes=[C.c_void_p]
fd=os.open('build/protocol/sample.pwg',os.O_RDONLY);r=lib.cupsRasterOpen(fd,0)
try:
 for p in range(2):
  h=C.create_string_buffer(1796);assert lib.cupsRasterReadHeader2(r,h)==1;assert struct.unpack_from('=II',h.raw,372)==(100,120)
  for y in range(120):
   row=C.create_string_buffer(300);assert lib.cupsRasterReadPixels(r,row,300)==300;assert row.raw==bytes(v for x in range(100) for v in (x,y,p))
 assert lib.cupsRasterReadHeader2(r,h)==0
 print('PASS: libcups decoded both PWG pages and all 24,000 pixels exactly.')
finally:lib.cupsRasterClose(r);os.close(fd)
