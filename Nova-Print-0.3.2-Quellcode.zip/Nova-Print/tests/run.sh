#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p build/protocol/classes
javac -d build/protocol/classes app/src/main/java/de/novaprint/app/*.java tests/ProtocolTest.java
java -cp build/protocol/classes de.novaprint.app.ProtocolTest tests/fixtures
