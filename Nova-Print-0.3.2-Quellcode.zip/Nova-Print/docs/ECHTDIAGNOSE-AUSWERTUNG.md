# Analyse der echten Eingangsdiagnose

Historischer Zeitpunkt: 2026-10-22T21:26:21.515396Z

Die unveränderte binäre IPP-Antwort wird durch den produktiven Parser getestet. Vier media-col-ready-Collections: A4/main und A3/alternate, jeweils 3 mm und Nullrand. Keine verifizierte physische Kassettennummerierung.

- document-format-supported: application/octet-stream, image/pwg-raster, image/urf, image/jpeg, application/vnd.epson.escpr
- pwg-raster-document-type-supported: sgray_8, srgb_8
- pwg-raster-document-resolution-supported: 300x300 dpi/unit:3, 600x600 dpi/unit:3
- pwg-raster-document-sheet-back: rotated
- media-ready: iso_a4_210x297mm, iso_a3_297x420mm
- media-source-supported: auto, main, alternate
- sides-supported: one-sided, two-sided-short-edge, two-sided-long-edge
- print-scaling-supported: auto, auto-fit, fill, fit, none
- operations-supported: 2, 4, 5, 6, 8, 9, 10, 11, 59, 60
- job-creation-attributes-supported: copies, finishings, ipp-attribute-fidelity, job-name, media, media-col, orientation-requested, output-bin, print-quality, printer-resolution, sides, print-color-mode, print-content-optimize, print-scaling, job-mandatory-attributes

## Alle SNMP-Eingangsantworten
Alle 12 BER-Pakete dekodiert: EPSON-Netzwerkserver, WF-7830 Series; Status 3, Fehlerbitmap 00; Sheet feeder bin 1/2; beide Fachfüllstände -2 = unbekannt; Black Ink Cartridge 405/405XL/405XXL 96 von 100. Weitere Farben wurden im Eingang nicht abgefragt. Neue App liest den ganzen Printer-MIB-Teilbaum.

## Netzwerk und HTTP
- TCP 80: open
- TCP 443: open
- TCP 515: closed-or-filtered
- TCP 631: open
- TCP 9100: closed-or-filtered
- TCP 5357: closed-or-filtered
- TCP 1865: open
- TCP 2968: closed-or-filtered
- TCP 3289: closed-or-filtered
- /: HTTP 307
- /eSCL/ScannerCapabilities: HTTP 404
- /eSCL/ScannerStatus: HTTP 404
- /DevMgmt/ProductConfigDyn.xml: HTTP 404

307 ohne gespeicherte Location im alten Bericht, daher Ziel nicht rekonstruierbar. Neue Diagnose speichert Location. 404 beweist keine fehlende Scanunterstützung. Offener Port 1865 allein reicht nicht für eine implementierte Epson-Scanschnittstelle.
Original-JSON liegt vollständig im Eingangspaket. Tests enthalten alle unveränderten binären IPP-/SNMP-Antworten.