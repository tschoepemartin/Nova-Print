# Nova-Print 0.3.0 – Implementierung und Grenzen

PDF → Android PdfRenderer → 128-Zeilen-ARGB-Streifen → verlustfreies PWG-Raster → ein IPPS-Print-Job für alle Seiten. Originalgröße setzt explizit dpi/72 Pixel je PDF-Punkt, ohne Fit/Fill. Zentrierung verschiebt nur; nicht bedruckbare Ränder können abgeschnitten werden. A4 210 × 297 mm, A3 297 × 420 mm. Die Autoerkennung toleriert 1,2 mm wegen ganzzahliger PdfRenderer-Seitenmaße, ohne den Inhalt zu skalieren. Papierpixel werden auf den nächsten Pixel gerundet; der Maßstab bleibt fest. Querformat wird im Inhalt um 90° gedreht, Raster bleibt in physischer Blattorientierung.

PWG 5102.4: RaS2, 1796-Byte-Header pro Seite, Big Endian, sRGB24/sGray8, 300/600 dpi aus Live-Fähigkeiten, PackBits auf Pixelebene. Maximal ca. 3,6 MB je A3/600-dpi-Renderstreifen, zuzüglich PDF-Renderer, Vorschau und Zeilenpuffer. Der private Dateispool wird im finally-Block entfernt. Bei Speicher-/Netzwerkfehlern kein automatisches erneutes Senden. Fotos können große Spooldateien erzeugen.

Duplex verwendet pwg-raster-document-sheet-back. Die Pixelmatrix und CrossFeed/Feed-Headerwerte werden gemeinsam transformiert. Epson meldet rotated: Rückseiten bei langer Kante werden um 180° gedreht. Unbekannte Rückseitenkonventionen werden abgelehnt. Geräteprüfung weiterhin notwendig.

IPP: RFC-8010-Codec mit RFC-3382-Collections; document-format und ipp-attribute-fidelity in der Operationsgruppe. Manuelle Quelle als media-source innerhalb media-col, keine freien erfundenen tray-Attribute. Automatische Quelle nutzt media. Validate-Job prüft vor dem Senden, sofern unterstützt. Ein HTTP-Upload mit Content-Length für das ganze Dokument. Request-ID und Statuscode werden geprüft; Get-Job-Attributes meldet wartend/verarbeitet/gestoppt/abgebrochen/fehlgeschlagen/laut Gerät abgeschlossen. Ein Geräteabschluss ist keine Messung auf Papier. PWG-Auflösung kommt aus dem Rasterheader; kein vom Epson unzulässiges printer-resolution=300.

Zertifikate: bestehende bewusste SHA-256-Pin-Bestätigung bleibt erhalten. Der erste Handshake dient nur der Zertifikatsanzeige, sendet keine Druck-/HTTP-Daten. Danach wird der bestätigte Pin geprüft, ein Wechsel abgelehnt. Diese bewusst benutzerdefinierten TrustManager erzeugen Lint-Warnungen. Client-Zertifikate werden abgelehnt. Privates Protokoll bleibt nach App-Neustart exportierbar. Backup und Android-12+-Gerätetransfer privater Daten sind deaktiviert.

SNMP: Read-only SNMPv1 GETNEXT für Printer-MIB-v1/v2, BER-Dekodierung mit negativen Integern, Request-ID-Prüfung, verbundenem UDP-Socket, numerischer OID-Reihenfolge, zwei Versuchen je Abfrage. Komplettwalk von 1.3.6.1.2.1.43; Diagnose zusätzlich 1.3.6.1.2.1.25.3. Grenzen 45 s/2048 Einträge je Teilbaum; Limits und Timeouts werden als Teilresultat angezeigt. Patrone/Fach anhand Tabellenindex statt nur erstem Eintrag. -2 = unbekannt, -3 = Rest vorhanden/Menge unbekannt. Balken nur bei tatsächlich auswertbarem Level/Maximum. Fachstatus/Alerts mit Originaldaten. Keine historischen Diagnosedaten als Livewerte.

## Bewusst offene Punkte
- Kein Zugriff auf das lokale Epson-Gerät: Annahme, Papierquellen, Duplexausrichtung und physische Maßhaltigkeit ungetestet.
- Kein Samsung-/Emulator-UI-Test. App beim Rendern/Senden offen lassen; kein Foreground-Service und keine Fortsetzungsgarantie nach Prozessbeendigung.
- Pro Job ein gemeinsames Zielformat. Gemischtes A3/A4 wird im Automatikmodus vor dem Upload abgelehnt. Explizite Wahl eines Zielformats möglich; Originalmodus skaliert auch dann nicht.
- Randlos nicht freigegeben, weil Hersteller-Überfüllung den Maßstab verändern könnte.
- main/alternate nicht ungeprüft mit Kassette 1/2 gleichgesetzt. Live media-col-ready zeigt die Meldung des Geräts.
- Scannen/Kopieren nicht implementiert. mDNS-Dienstsuche _uscan/_uscans/_scanner einschließlich TXT-Daten, HTTP-Diagnose speichert Redirect-Ziel. Kein vollständiger WSD-/Epson-Scanclient. 404 oder fehlende mDNS-Treffer beweisen keine fehlende Scanunterstützung.

## Quellen
- https://ftp.pwg.org/pub/pwg/candidates/cs-ippraster10-20120420-5102.4.pdf
- https://www.rfc-editor.org/rfc/rfc8010
- https://www.rfc-editor.org/rfc/rfc3382
- https://www.rfc-editor.org/rfc/rfc3805
- https://openprinting.github.io/cups/doc/api-raster.html
