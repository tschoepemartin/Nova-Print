# Bedienung Nova-Print 0.3.0

1. APK als Update installieren; Paketname und bisheriger Signierschlüssel bleiben gleich. Epson im selben WLAN wählen, bei Neueinrichtung dessen Zertifikat bewusst bestätigen.
2. Zuerst die A4-, danach die A3-Messvorlage wählen. Originalgröße 100 %, Normal 300 dpi, automatische Papierquelle, zunächst einseitig. A4/A3 müssen am Drucker korrekt als eingelegtes Format registriert sein. Jede Vorlage enthält Hoch-/Querformat. Quadrat zwischen Linienmitten in beiden Richtungen messen: Soll 100 mm, erster praktischer Richtwert ±0,5 mm. Bei Abweichung Messwerte und Druckprotokoll sichern, nicht mit Fit-to-page kaschieren.

Die App unterscheidet vorbereitet, vom Drucker angenommen (Job-ID), laut Drucker abgeschlossen. Keine Meldung ersetzt die Messung auf Papier. Bei unklarem Upload vor Wiederholung die Drucker-Auftragsliste prüfen. Netzwerkfehler nach Annahme bedeutet nicht, dass nicht gedruckt wurde.

CAD: Originalgröße beibehalten. Andere Skalierungsoptionen verändern den Maßstab ausdrücklich. Randinhalte können abgeschnitten werden. Hoch verwendet 600 dpi. main/alternate sind die Druckerbezeichnungen, ihre Kassettentasten-Zuordnung ist noch zu prüfen. Druckprotokoll bleibt auch nach Neustart exportierbar. App während Rendern/Senden offen lassen.

## GitHub
android-universell.yml einmal unter .github/workflows/android.yml verwenden. Danach erkennt der Workflow die höchste numerische Nova-Print-X.Y.Z-Quellcode.zip im Repository-Stamm selbst. Ohne ZIP baut er den direkten Projektbaum.

Dieses vollständige Quellpaket enthält den bisherigen privaten Debug-Schlüssel für Update-Kompatibilität. Nicht öffentlich hochladen. Für ein öffentliches Repository den Schlüssel separat über Actions-Secrets bereitstellen; ein neuer Schlüssel würde Updates verhindern. Die gelieferte APK kann direkt installiert werden und braucht keinen GitHub-Lauf.
