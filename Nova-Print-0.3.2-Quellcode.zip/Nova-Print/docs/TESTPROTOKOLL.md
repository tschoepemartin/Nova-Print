# Nova-Print 0.3.0 – Testprotokoll

## Tatsächlich ausgeführter Android-Build

`assembleDebug` und `lintDebug`: **BUILD SUCCESSFUL**, Exitcode 0, 45 Tasks ausgeführt. JDK 17.0.18, Gradle 8.9, Android SDK 35. Lint: **0 Fehler, 23 Warnungen** (u.a. Übersetzbarkeit, vorhandene Icons, bewusster Zertifikats-Bootstrap/Pin-TrustManager). Keine Warnungen als Hardwarefreigabe interpretieren.

APK de.novaprint.app, versionName 0.3.0, versionCode 30, minSdk 26, targetSdk 35. APK-v2-Signatur verifiziert; Signerzertifikat mit ursprünglichem Keystore verglichen; ursprünglicher Keystore byte-identisch erhalten. SHA-256 siehe apk-verification.txt. Die ausgelieferte APK ist die tatsächliche Builddatei, keine umbenannte ältere Version.

| Nachweis | Ergebnis |
|---|---|
| Kompiliert und APK erzeugt | Ja |
| Neuer Auftrag vom echten Epson angenommen | Nicht getestet |
| Physischer Ausdruck maßhaltig | Nicht getestet |

## Automatisierte Prüfungen
- 885 erfolgreiche Assertions mit den produktiven Java-Klassen: IPP-Collections und Operations-/Jobgruppen, Boolean-Kodierung, fehlerhafte/trunkierte Antworten, echte Epson-IPP-Antwort, alle 12 BER-SNMP-Antworten, negative Füllstände, numerische OID-Reihenfolge, PWG-Header/Stride/Farbraum/Seitenanzahl, RLE-Rundlauf mit Zufalls-/Wiederholungspixeln und Lauflängengrenzen.
- 100-mm-Maßstab mit derselben Matrixberechnung wie die App geprüft: 300/600 dpi, Hoch-/Querformat, beide Achsen der Duplextransformation.
- Lokaler Mock-HTTP/IPP-Server: Request-ID, Job-ID und abgeschlossener Job-State. Das ist kein Druckerzugriff.
- Unabhängige libcups-Bibliothek dekodiert zwei synthetische Rasterseiten und alle 24.000 Pixel exakt. Das ersetzt keinen Android-PdfRenderer-/Hardwaretest.
- A4-/A3-Test-PDF: vier Seiten visuell kontrolliert, MediaBox bestätigt 210×297, 297×210, 297×420 und 420×297 mm. Quadratkanten nominell 100 mm.
- Universelle Workflow-YAML syntaktisch geprüft; numerische ZIP-Versionsauswahl statt festem Versionsnamen.

885 zählt Assertions einschließlich Schleifen, nicht 885 unterschiedliche Testszenarien. Protokolltestausgabe: protocol-test.log.

## Klare Grenzen
- Druckerannahme des neuen PWG-Auftrags: nicht getestet, kein Zugriff auf das lokale Gerät.
- Physische Maßhaltigkeit: nicht getestet, Linealmessung erforderlich.
- Samsung-/Emulator-Oberflächentest: nicht durchgeführt.
- Scanner/Kopierer: noch nicht implementiert. Dienstsuche vorhanden, keine erfundenen Fähigkeiten.
- Fachzuordnung, beidseitige Ausrichtung und reale Tinten-/Fachwerte der neuen App benötigen Hardwareprüfung.

## Bedienung für den Ersttest
APK als Update installieren. A4- und A3-Messvorlage in Originalgröße, Normal 300 dpi, automatischer Quelle, zunächst einseitig drucken. Beide 100-mm-Kanten zwischen den Linienmitten messen; erster praktischer Richtwert ±0,5 mm. Bei Ablehnung das eingebaute Druckprotokoll speichern. Bei unklarer Annahme vor erneutem Senden vorhandene Druckeraufträge prüfen.

## Reproduzieren
JDK 17, Gradle 8.9, Android SDK 35. `sh tests/run.sh`, optional `python3 tests/cups_validate.py`, `gradle :app:assembleDebug :app:lintDebug --no-daemon`. Lokale SDK-/Proxy-Pfade sind nicht im Quellpaket enthalten. Kein GitHub-Actions-Erfolg wird behauptet; der Build erfolgt lokal.
