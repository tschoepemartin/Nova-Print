package de.novaprint.app;
import java.io.*;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.*;
/** RFC 8010 including nested RFC 3382 collections. */
public final class Ipp {
 public static final class Attr {
  public final int tag; public final String name; public final Object value;
  public Attr(int t,String n,Object v){tag=t;name=n;value=v;}
  public String toString(){return name+"="+value;}
 }
 public static final class Response {
  public int status,id; public final Map<Integer,List<Attr>> groups=new LinkedHashMap<>();
  public List<Attr> attrs(){List<Attr>a=new ArrayList<>();for(List<Attr> g:groups.values())a.addAll(g);return a;}
  public List<Object> values(String n){List<Object>v=new ArrayList<>();for(Attr a:attrs())if(a.name.equals(n))v.add(a.value);return v;}
  public boolean has(String n,Object v){return values(n).contains(v);}
  public int integer(String n,int fallback){for(Object v:values(n))if(v instanceof Integer)return (Integer)v;return fallback;}
  public String text(String n){return values(n).toString();}
  public void requireSuccess(){if(status>=256)throw new IllegalStateException("IPP 0x"+Integer.toHexString(status)+" "+attrs());}
 }
 public static Attr a(int t,String n,Object v){return new Attr(t,n,v);}
 static void field(DataOutputStream o,int t,String n,byte[]v)throws IOException{byte[]k=n.getBytes(StandardCharsets.UTF_8);o.writeByte(t);o.writeShort(k.length);o.write(k);o.writeShort(v.length);o.write(v);}
 public static void write(DataOutputStream o,Attr a)throws IOException{
  if(a.tag==0x34){field(o,a.tag,a.name,new byte[0]);for(Attr m:(List<Attr>)a.value){field(o,0x4a,"",m.name.getBytes(StandardCharsets.UTF_8));write(o,new Attr(m.tag,"",m.value));}field(o,0x37,"",new byte[0]);return;}
  byte[]v=a.value instanceof Integer?ByteBuffer.allocate(4).putInt((Integer)a.value).array():a.value instanceof Boolean?new byte[]{(byte)((Boolean)a.value?1:0)}:a.value instanceof byte[]?(byte[])a.value:a.value.toString().getBytes(StandardCharsets.UTF_8);field(o,a.tag,a.name,v);
 }
 public static byte[] request(int operation,int id,String uri,List<Attr>op,List<Attr>job)throws IOException{
  ByteArrayOutputStream b=new ByteArrayOutputStream();DataOutputStream o=new DataOutputStream(b);o.writeShort(0x0200);o.writeShort(operation);o.writeInt(id);o.writeByte(1);
  write(o,a(0x47,"attributes-charset","utf-8"));write(o,a(0x48,"attributes-natural-language","en"));write(o,a(0x45,"printer-uri",uri));
  for(Attr a:op)write(o,a);if(!job.isEmpty()){o.writeByte(2);for(Attr a:job)write(o,a);}o.writeByte(3);return b.toByteArray();
 }
 static byte[] bytes(DataInputStream i,int n)throws IOException{if(n<0||n>65535)throw new IOException("IPP length");byte[]b=new byte[n];i.readFully(b);return b;}
 static String string(byte[]b){return new String(b,StandardCharsets.UTF_8);}
 static Object value(DataInputStream i,int tag,int depth)throws IOException{
  if(depth>16)throw new IOException("IPP collection nesting");byte[]b=bytes(i,i.readUnsignedShort());
  if(tag==0x34){if(b.length!=0)throw new IOException("IPP collection length");List<Attr>c=new ArrayList<>();String member="";
   while(true){int t=i.readUnsignedByte();if(i.readUnsignedShort()!=0)throw new IOException("IPP member name");
    if(t==0x37){if(i.readUnsignedShort()!=0)throw new IOException("IPP end collection");return c;}
    if(t==0x4a)member=string(bytes(i,i.readUnsignedShort()));else{if(member.isEmpty())throw new IOException("IPP missing member");c.add(a(t,member,value(i,t,depth+1)));}
   }
  }
  if(tag==0x21||tag==0x23){if(b.length!=4)throw new IOException("IPP integer");return ByteBuffer.wrap(b).getInt();}
  if(tag==0x22){if(b.length!=1)throw new IOException("IPP boolean");return b[0]!=0;}
  if(tag==0x32){if(b.length!=9)throw new IOException("IPP resolution");ByteBuffer q=ByteBuffer.wrap(b);return q.getInt()+"x"+q.getInt()+"/"+(q.get()&255);}
  if(tag>=0x40)return string(b);return b;
 }
 public static Response parse(byte[]b)throws IOException{
  if(b.length<9)throw new IOException("Short IPP response");DataInputStream i=new DataInputStream(new ByteArrayInputStream(b));int version=i.readUnsignedShort();if(version!=0x100&&version!=0x101&&version!=0x200)throw new IOException("IPP version");
  Response r=new Response();r.status=i.readUnsignedShort();r.id=i.readInt();List<Attr>g=null;String name="";boolean ended=false;
  while(i.available()>0){int t=i.readUnsignedByte();if(t==3){ended=true;break;}if(t<16){g=r.groups.computeIfAbsent(t,k->new ArrayList<>());name="";continue;}
   if(g==null)throw new IOException("IPP missing group");String n=string(bytes(i,i.readUnsignedShort()));if(!n.isEmpty())name=n;if(name.isEmpty())throw new IOException("IPP missing name");g.add(a(t,name,value(i,t,0)));
  }if(!ended)throw new IOException("IPP truncated response");return r;
 }
 public static Object member(List<Attr>attrs,String n){for(Attr a:attrs)if(a.name.equals(n))return a.value;return null;}
}
