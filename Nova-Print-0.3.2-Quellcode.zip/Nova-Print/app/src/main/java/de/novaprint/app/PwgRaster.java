package de.novaprint.app;
import java.io.*;
import java.nio.*;
import java.nio.charset.StandardCharsets;
/** PWG 5102.4: full-sheet network-order header and lossless pixel PackBits. */
public final class PwgRaster {
 public static int pixels(double mm,int dpi){return (int)Math.round(mm*dpi/25.4);}
 public static byte[] header(int width,int height,int dpi,int colors,int pages,int quality,String media,int source,int sides,int cross,int feed){
  ByteBuffer b=ByteBuffer.allocate(1796).order(ByteOrder.BIG_ENDIAN);putString(b,0,"PwgRaster");putString(b,128,"stationery");putString(b,1732,media);
  b.putInt(272,sides==0?0:1);b.putInt(276,dpi);b.putInt(280,dpi);b.putInt(324,source);b.putInt(340,1);b.putInt(352,(int)Math.round(width*72.0/dpi));b.putInt(356,(int)Math.round(height*72.0/dpi));b.putInt(368,sides==2?1:0);
  b.putInt(372,width);b.putInt(376,height);b.putInt(384,8);b.putInt(388,8*colors);b.putInt(392,width*colors);b.putInt(400,colors==1?18:19);b.putInt(420,colors);b.putInt(452,pages);b.putInt(456,cross);b.putInt(460,feed);b.putInt(484,quality);return b.array();
 }
 static void putString(ByteBuffer b,int at,String s){byte[]v=s.getBytes(StandardCharsets.US_ASCII);for(int i=0;i<Math.min(63,v.length);i++)b.put(at+i,v[i]);}
 static boolean same(byte[]p,int a,int b,int c){for(int k=0;k<c;k++)if(p[a*c+k]!=p[b*c+k])return false;return true;}
 public static void row(OutputStream out,byte[]p,int colors)throws IOException{
  out.write(0);int pixels=p.length/colors,i=0;
  while(i<pixels){int run=1;while(i+run<pixels&&run<128&&same(p,i,i+run,colors))run++;
   if(run>1){out.write(run-1);out.write(p,i*colors,colors);i+=run;}
   else{int start=i++;while(i<pixels&&i-start<128){if(i+1<pixels&&same(p,i,i+1,colors))break;i++;}int count=i-start;out.write(count==1?0:257-count);out.write(p,start*colors,count*colors);}
  }
 }
 public static int[] backTransform(String sheetBack,int sides,boolean back){
  if(!back||sides==0)return new int[]{1,1};
  switch(sheetBack){case "normal":return new int[]{1,1};case "rotated":return sides==1?new int[]{-1,-1}:new int[]{1,1};case "flipped":return sides==1?new int[]{1,-1}:new int[]{-1,1};case "manual-tumble":return sides==2?new int[]{-1,-1}:new int[]{1,1};default:throw new IllegalArgumentException("Unbekannte Duplex-Rückseitentransformation");}
 }
}
