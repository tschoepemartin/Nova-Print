package de.novaprint.app;
import java.io.*;import java.net.*;import java.math.BigInteger;import java.nio.charset.StandardCharsets;import java.util.*;
/** Read-only SNMPv1 GETNEXT for Printer-MIB v1/v2 with bounded BER parsing. */
public final class Snmp {
 public static final class Value{public final String oid;public final int tag;public final Object value;Value(String o,int t,Object v){oid=o;tag=t;value=v;}}
 static final class T{int tag;byte[]b;T(int t,byte[]v){tag=t;b=v;}}
 static T read(ByteArrayInputStream i)throws IOException{int t=i.read(),n=i.read();if(t<0||n<0)throw new EOFException();if(n>=128){int c=n&127;if(c==0||c>4)throw new IOException("BER length");n=0;while(c-->0){int k=i.read();if(k<0)throw new EOFException();n=(n<<8)|k;}}if(n<0||n>i.available())throw new IOException("BER truncated");byte[]b=new byte[n];if(i.read(b)!=n&&n!=0)throw new EOFException();return new T(t,b);}
 static List<T>children(T t)throws IOException{List<T>v=new ArrayList<>();ByteArrayInputStream i=new ByteArrayInputStream(t.b);while(i.available()>0)v.add(read(i));return v;}
 static byte[]join(byte[]...v)throws IOException{ByteArrayOutputStream o=new ByteArrayOutputStream();for(byte[]b:v)o.write(b);return o.toByteArray();}
 static byte[]tlv(int t,byte[]b)throws IOException{ByteArrayOutputStream o=new ByteArrayOutputStream();o.write(t);if(b.length<128)o.write(b.length);else{o.write(0x82);o.write(b.length>>8);o.write(b.length);}o.write(b);return o.toByteArray();}
 static byte[]integer(int v)throws IOException{return tlv(2,BigInteger.valueOf(v).toByteArray());}
 static void arc(ByteArrayOutputStream b,long v){int n=1;long q=v;while((q>>=7)>0)n++;for(int i=n-1;i>=0;i--)b.write((int)((v>>(i*7))&127)|(i==0?0:128));}
 static byte[]oid(String s)throws IOException{String[]a=s.split("\\.");ByteArrayOutputStream b=new ByteArrayOutputStream();arc(b,Long.parseLong(a[0])*40+Long.parseLong(a[1]));for(int i=2;i<a.length;i++)arc(b,Long.parseLong(a[i]));return tlv(6,b.toByteArray());}
 static String decodeOid(byte[]b)throws IOException{List<Long>a=new ArrayList<>();long v=0;boolean end=true;for(byte k:b){v=(v<<7)|(k&127);end=(k&128)==0;if(end){a.add(v);v=0;}}if(!end||a.isEmpty())throw new IOException("BER OID");long f=a.remove(0);StringBuilder s=new StringBuilder(f<40?"0.":f<80?"1.":"2.");s.append(f<40?f:f<80?f-40:f-80);for(long x:a)s.append('.').append(x);return s.toString();}
 public static List<Value>decode(byte[]b,int expected)throws IOException{
  List<T>m=children(read(new ByteArrayInputStream(b)));if(m.size()!=3||m.get(2).tag!=0xa2)throw new IOException("SNMP response");List<T>p=children(m.get(2));if(p.size()!=4)throw new IOException("SNMP PDU");
  if(new BigInteger(p.get(0).b).intValue()!=expected)throw new IOException("SNMP request id");int err=new BigInteger(p.get(1).b).intValue();if(err==2)return Collections.emptyList();if(err!=0)throw new IOException("SNMP error "+err);
  List<Value>r=new ArrayList<>();for(T vb:children(p.get(3))){List<T>x=children(vb);if(x.size()!=2)throw new IOException("SNMP varbind");T v=x.get(1);Object value;
   if(v.tag==2)value=new BigInteger(v.b).longValue();else if(v.tag>=0x41&&v.tag<=0x46)value=new BigInteger(1,v.b).longValue();else if(v.tag==4)value=new String(v.b,StandardCharsets.UTF_8);else if(v.tag==6)value=decodeOid(v.b);else{StringBuilder s=new StringBuilder();for(byte k:v.b)s.append(String.format("%02x",k&255));value=s.toString();}
   r.add(new Value(decodeOid(x.get(0).b),v.tag,value));}return r;
 }
 public static int compare(String a,String b){String[]x=a.split("\\."),y=b.split("\\.");for(int i=0;i<Math.min(x.length,y.length);i++){int c=Long.compare(Long.parseLong(x[i]),Long.parseLong(y[i]));if(c!=0)return c;}return Integer.compare(x.length,y.length);}
 public static final class Walk{public final List<Value>values=new ArrayList<>();public boolean complete;public String reason="";}
 public static Walk walk(String host,String root){Walk result=new Walk();String current=root;long deadline=System.currentTimeMillis()+45000;
  try(DatagramSocket s=new DatagramSocket()){s.connect(InetAddress.getByName(host),161);s.setSoTimeout(1000);
   for(int id=1;id<=2048;id++){
    if(System.currentTimeMillis()>deadline){result.reason="Zeitlimit; Teilresultat";return result;}
    byte[]vb=tlv(0x30,join(oid(current),tlv(5,new byte[0]))),pdu=tlv(0xa1,join(integer(id),integer(0),integer(0),tlv(0x30,vb))),req=tlv(0x30,join(integer(0),tlv(4,"public".getBytes(StandardCharsets.US_ASCII)),pdu));List<Value>vals=null;
    for(int retry=0;retry<2;retry++){try{s.send(new DatagramPacket(req,req.length));byte[]buf=new byte[65507];DatagramPacket packet=new DatagramPacket(buf,buf.length);s.receive(packet);vals=decode(Arrays.copyOf(buf,packet.getLength()),id);break;}catch(SocketTimeoutException e){if(retry==1)throw e;}}
    if(vals==null||vals.isEmpty()){result.complete=true;result.reason="MIB-Ende";return result;}Value v=vals.get(0);
    if(v.tag>=0x80||!v.oid.startsWith(root+".")){result.complete=true;result.reason="Teilbaum vollständig";return result;}
    if(compare(v.oid,current)<=0)throw new IOException("Nicht aufsteigende OID");result.values.add(v);current=v.oid;
   }result.reason="Eintragslimit; Teilresultat";
  }catch(Exception e){result.reason=e.toString();}return result;
 }
 public static String level(Object v){if(!(v instanceof Number))return "unbekannt";long n=((Number)v).longValue();return n==-2?"unbekannt":n==-3?"Rest vorhanden, Menge unbekannt":n<0?"nicht bestimmbar":Long.toString(n);}
}
