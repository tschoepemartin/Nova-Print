package de.novaprint.app;
/** Shared PDF-points -> raster-pixels affine transform, tested independently. */
public final class PrintGeometry {
 public static float[] matrix(int width,int height,int dpi,int pageWidth,int pageHeight,int mode,double percent,int cross,int feed){
  boolean landscape=pageWidth>pageHeight;int logicalW=landscape?height:width,logicalH=landscape?width:height;
  double scale=dpi/72.0,margin=mode==1?5.0*dpi/25.4:0;
  if(mode==1)scale=Math.min((logicalW-2*margin)/pageWidth,(logicalH-2*margin)/pageHeight);else if(mode==2)scale=Math.min((double)logicalW/pageWidth,(double)logicalH/pageHeight);else if(mode==4)scale*=percent/100.0;
  double dx=(logicalW-pageWidth*scale)/2,dy=(logicalH-pageHeight*scale)/2;
  double a=landscape?0:scale,b=landscape?-scale:0,c=landscape?width-dy:dx,d=landscape?scale:0,e=landscape?0:scale,f=landscape?dx:dy;
  return new float[]{(float)(a*cross),(float)(b*cross),(float)(c*cross+(cross<0?width:0)),(float)(d*feed),(float)(e*feed),(float)(f*feed+(feed<0?height:0)),0,0,1};
 }
}
