package de.novaprint.app

import android.print.PrintAttributes
import android.print.PrinterCapabilitiesInfo
import android.print.PrinterId
import android.print.PrinterInfo
import android.printservice.PrintJob
import android.printservice.PrintService
import android.printservice.PrinterDiscoverySession
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.pdf.PdfRenderer
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.os.Handler
import android.os.Looper
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference
import org.json.JSONArray
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicInteger
import kotlin.concurrent.thread

/** Android framework printing entry point. Uses the same PWG raster and IPP codec as the app. */
class NovaPrintService : PrintService() {
    private data class Device(val key:String,val name:String,val host:String,val port:Int,val path:String,val secure:Boolean,val fingerprint:String)
    private val ids=AtomicInteger(4000)
    private val mainHandler=Handler(Looper.getMainLooper())
    private val cancellations=java.util.concurrent.ConcurrentHashMap<String,AtomicBoolean>()

    // Android PrintJob API is main-thread-only. Keep all rendering and IPP I/O off main.
    private fun <T> onMain(block:()->T):T {
        if(Looper.myLooper()==Looper.getMainLooper())return block()
        val done=CountDownLatch(1)
        val result=AtomicReference<Result<T>>()
        mainHandler.post {
            try {result.set(Result.success(block()))}
            catch(t:Throwable){result.set(Result.failure(t))}
            finally {done.countDown()}
        }
        check(done.await(30,TimeUnit.SECONDS)){"Android Hauptthread antwortet nicht"}
        return result.get().getOrThrow()
    }
    private fun finish(job:PrintJob,action:String,reason:String="") {
        try {onMain {
            when(action){
                "complete"->if(!job.isCancelled)job.complete()
                "cancel"->if(!job.isCancelled)job.cancel()
                "fail"->if(!job.isCancelled)job.fail(reason.take(180))
            }
        }}catch(t:Throwable){diagnostic("Android job $action failed",t)}
    }

    private fun saved():List<Device> {
        val a=JSONArray(getSharedPreferences("printers",MODE_PRIVATE).getString("items","[]"))
        return (0 until a.length()).mapNotNull { i ->
            try {val o=a.getJSONObject(i); Device("${o.optString("ip")}:${o.optInt("port",631)}:${o.optString("path","/ipp/print")}",o.optString("name","Epson"),o.getString("ip"),o.optInt("port",631),o.optString("path","/ipp/print"),o.optBoolean("secure"),o.optString("fingerprint",""))}catch(_:Exception){null}
        }
    }
    override fun onCreatePrinterDiscoverySession():PrinterDiscoverySession = object:PrinterDiscoverySession(){
        override fun onStartPrinterDiscovery(priorityList:MutableList<PrinterId>) {safePublish();probe()}
        override fun onStopPrinterDiscovery() {}
        override fun onValidatePrinters(printerIds:MutableList<PrinterId>) {safePublish();probe()}
        override fun onStartPrinterStateTracking(printerId:PrinterId) {safePublish();probe()}
        override fun onStopPrinterStateTracking(printerId:PrinterId) {}
        override fun onDestroy() {disposed = true}
        private var disposed = false
        private val states = java.util.concurrent.ConcurrentHashMap<String,Int>()
        private val failures = java.util.concurrent.ConcurrentHashMap<String,Int>()
        private val probeGeneration = AtomicInteger(0)
        private fun probe() {
            val devices = try { saved() } catch(t:Throwable) {diagnostic("Printer probe initialization",t);return}
            val generation = probeGeneration.incrementAndGet()
            thread(name="NovaPrint-PrinterProbe") {
                devices.forEach { d ->
                    // Get-Printer-Attributes can fail on Epson even while Print-Job works.
                    // A failed status query is not proof that the printer is offline.
                    val result = try {
                        exchange(d, 11, listOf(Ipp.a(0x44,"requested-attributes","printer-state")))
                        "IPP status OK"
                    } catch (e: Exception) {
                        "IPP status inconclusive: ${e.javaClass.simpleName}: ${e.message}"
                    }
                    val ok = result == "IPP status OK"
                    if (ok) {
                        failures[d.key] = 0
                        states[d.key] = PrinterInfo.STATUS_IDLE
                    } else {
                        failures[d.key] = (failures[d.key] ?: 0) + 1
                        // Preserve last-known-online status. A status probe cannot
                        // invalidate a printer whose actual print path is working.
                        if (!states.containsKey(d.key)) states[d.key] = PrinterInfo.STATUS_IDLE
                    }
                    getSharedPreferences("print_service_diagnostics",MODE_PRIVATE).edit()
                        .putString("last_probe_${d.key}","$result; failures=${failures[d.key]}")
                        .apply()
                }
                android.os.Handler(android.os.Looper.getMainLooper()).post {
                    if (!disposed && generation == probeGeneration.get()) safePublish()
                }
            }
        }
        private fun safePublish() {
            try { publish() } catch(t:Throwable) { diagnostic("Printer discovery callback",t) }
        }
        private fun publish(){
            val devices=saved(); if(devices.isEmpty())return
            val printers=devices.map { d ->
                val id=generatePrinterId(d.key)
                val a4=PrintAttributes.MediaSize.ISO_A4
                val caps=PrinterCapabilitiesInfo.Builder(id)
                    .addMediaSize(a4,true)
                    .addResolution(PrintAttributes.Resolution("300","300 dpi",300,300),true)
                    .setColorModes(PrintAttributes.COLOR_MODE_COLOR or PrintAttributes.COLOR_MODE_MONOCHROME,PrintAttributes.COLOR_MODE_COLOR)
                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                    .setDuplexModes(PrintAttributes.DUPLEX_MODE_NONE, PrintAttributes.DUPLEX_MODE_NONE)
                // Only advertise A3 when the model is known to support it.
                if(d.name.contains("7830",true))caps.addMediaSize(PrintAttributes.MediaSize.ISO_A3,false)
                PrinterInfo.Builder(id,d.name,states[d.key] ?: PrinterInfo.STATUS_IDLE).setCapabilities(caps.build()).build()
            }
            addPrinters(printers)
        }
    }
    private fun diagnostic(stage:String,t:Throwable?=null) {
        android.util.Log.i("NovaPrintService",stage,t)
        try {
            val prefs=getSharedPreferences("print_service_diagnostics",MODE_PRIVATE)
            val time=java.text.SimpleDateFormat("dd.MM. HH:mm:ss",java.util.Locale.GERMANY).format(java.util.Date())
            val trace=t?.let {"\n"+android.util.Log.getStackTraceString(it)} ?: ""
            val entry="$time | $stage$trace"
            val previous=prefs.getString("service_events","").orEmpty()
            prefs.edit().putString("service_events",(entry+"\n\n"+previous).take(28000))
                .putString("last_service_error",entry)
                .putLong("last_service_error_time",System.currentTimeMillis()).apply()
        } catch(_:Throwable) {}
    }
    override fun onRequestCancelPrintJob(job:PrintJob) {
        try {
            cancellations[job.id.toString()]?.set(true)
            job.cancel() // Android invokes this callback on the main thread.
            diagnostic("Android job cancelled by user")
        }catch(t:Throwable){diagnostic("Cancel job",t)}
    }
    override fun onPrintJobQueued(job:PrintJob) {
        val device=try {saved().firstOrNull { generatePrinterId(it.key)==job.info.printerId }}
            catch(t:Throwable){diagnostic("Print job lookup",t);try{job.fail("Druckerzuordnung fehlgeschlagen")}catch(_:Throwable){};return}
        if(device==null){try{job.fail("Drucker nicht gespeichert. Bitte zuerst in Nova-Print verbinden.")}catch(_:Throwable){};return}
        // Capture PrintJob metadata on main before entering the worker thread.
        val label:String
        val attrs:PrintAttributes
        val document:ParcelFileDescriptor
        val key=job.id.toString()
        val cancelled=AtomicBoolean(false)
        try {
            label=job.info.label
            attrs=job.info.attributes ?: PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).build()
            if(!job.start()) {
                diagnostic("Android rejected job.start()")
                finish(job,"fail","Android konnte Druckauftrag nicht starten")
                return
            }
            document=job.document.data ?: error("Android hat keine Druckdaten geliefert")
            cancellations[key]=cancelled
            diagnostic("Android job started: $label")
        }catch(t:Throwable){diagnostic("Android job initialization",t);finish(job,"fail",t.message ?: "Druckauftrag nicht lesbar");return}
        thread(name="NovaPrint-AndroidPrint") {
            var spool:File?=null
            var localPdf:File?=null
            try {
                if(cancelled.get())return@thread
                val media=attrs.mediaSize ?: PrintAttributes.MediaSize.ISO_A4
                val isA3=media.id==PrintAttributes.MediaSize.ISO_A3.id
                if(isA3 && !device.name.contains("7830",true))error("A3 für diesen Drucker nicht freigegeben")
                val portrait=media.isPortrait
                val mmW=if(isA3){if(portrait)297 else 420}else{if(portrait)210 else 297}
                val mmH=if(isA3){if(portrait)420 else 297}else{if(portrait)297 else 210}
                val mediaName=if(isA3)"iso_a3_297x420mm" else "iso_a4_210x297mm"
                val gray=attrs.colorMode==PrintAttributes.COLOR_MODE_MONOCHROME
                val dpi=300;val w=PwgRaster.pixels(mmW.toDouble(),dpi);val h=PwgRaster.pixels(mmH.toDouble(),dpi)
                val channels=if(gray)1 else 3
                // Do not make printing depend on optional Get-Printer-Attributes
                // replies. The direct Nova-Print path already proved this printer
                // accepts PWG raster; the Print-Job response is authoritative.
                getSharedPreferences("print_service_diagnostics",MODE_PRIVATE).edit()
                    .putString("last_print_target", "${device.name} ${device.host}:${device.port}${device.path}")
                    .apply()
                diagnostic("Opening Android spool PDF")
                diagnostic("Android PDF descriptor received")
                // Android's print spooler can return a pipe or another non-seekable
                // descriptor. PdfRenderer requires a seekable file descriptor.
                // Stream the entire document into our own regular cache file first.
                localPdf=File.createTempFile("nova-android-pdf-",".pdf",cacheDir)
                document.fileDescriptor.let {source->
                    java.io.FileInputStream(source).use {input->
                        localPdf!!.outputStream().buffered(65536).use {output->
                            val buffer=ByteArray(65536)
                            while(true){
                                if(cancelled.get())throw InterruptedException("Druckauftrag abgebrochen")
                                val n=input.read(buffer)
                                if(n<0)break
                                output.write(buffer,0,n)
                            }
                        }
                    }
                }
                diagnostic("Android PDF copied to seekable cache: ${localPdf!!.length()} bytes")
                check(localPdf!!.length()>0){"Android hat ein leeres PDF geliefert"}
                spool=File.createTempFile("nova-service-",".pwg",cacheDir)
                ParcelFileDescriptor.open(localPdf!!,ParcelFileDescriptor.MODE_READ_ONLY).use {fd->
                    PdfRenderer(fd).use {renderer->
                        check(renderer.pageCount>0){"Leeres Dokument"}
                        diagnostic("PDF opened: ${renderer.pageCount} page(s)")
                        spool!!.outputStream().buffered(65536).use {out->
                            out.write("RaS2".toByteArray(Charsets.US_ASCII))
                            for(i in 0 until renderer.pageCount){
                                diagnostic("Rendering PDF page ${i+1}/${renderer.pageCount}")
                                if(cancelled.get())throw InterruptedException("Druckauftrag abgebrochen")
                                renderer.openPage(i).use {pg->
                                    out.write(PwgRaster.header(w,h,dpi,channels,renderer.pageCount,4,mediaName,0,0,1,1))
                                    // Android supplies a print-ready PDF. Do not silently fit-to-page:
                                    // preserve its physical page size and crop outside target media.
                                    val transform=Matrix().apply {setScale(dpi/72f,dpi/72f)}
                                    val pixels=IntArray(w);val row=ByteArray(w*channels)
                                    var y=0
                                    while(y<h){
                                        if(cancelled.get())throw InterruptedException("Druckauftrag abgebrochen")
                                        val rows=minOf(128,h-y)
                                        val bmp=Bitmap.createBitmap(w,rows,Bitmap.Config.ARGB_8888)
                                        try {
                                            bmp.eraseColor(Color.WHITE)
                                            val band=Matrix(transform).apply {postTranslate(0f,-y.toFloat())}
                                            pg.render(bmp,null,band,PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                                            for(line in 0 until rows){
                                                bmp.getPixels(pixels,0,w,0,line,w,1)
                                                for(x in 0 until w){val v=pixels[x];val r=(v ushr 16) and 255;val g=(v ushr 8) and 255;val b=v and 255
                                                    if(gray)row[x]=((r*77+g*150+b*29+128) shr 8).toByte()
                                                    else {row[x*3]=r.toByte();row[x*3+1]=g.toByte();row[x*3+2]=b.toByte()}
                                                }
                                                PwgRaster.row(out,row,channels)
                                            }
                                        }finally{bmp.recycle()}
                                        y+=rows
                                        if(y % 1024 < rows || y==h) diagnostic("Page ${i+1}: $y/$h raster lines")
                                    }
                                }
                            }
                        }
                    }
                }
                if(cancelled.get())return@thread
                diagnostic("PWG ready: ${spool?.length()} bytes; sending to ${device.name}")
                val op=listOf(Ipp.a(0x42,"requesting-user-name","Nova-Print"),Ipp.a(0x42,"job-name",label),Ipp.a(0x49,"document-format","image/pwg-raster"),Ipp.a(0x22,"ipp-attribute-fidelity",true))
                val jobAttrs=mutableListOf(Ipp.a(0x21,"copies",1),Ipp.a(0x44,"media",mediaName),Ipp.a(0x44,"print-scaling","none"),Ipp.a(0x44,"sides","one-sided"))
                val caps=exchange(device,11,listOf(Ipp.a(0x49,"document-format","image/pwg-raster"),Ipp.a(0x44,"requested-attributes","all")))
                check(caps.has("document-format-supported","image/pwg-raster")){"PWG-Raster nicht unterstützt"}
                check(caps.has("pwg-raster-document-resolution-supported","${dpi}x$dpi/3")){"PWG-Auflösung nicht unterstützt"}
                check(caps.has("pwg-raster-document-type-supported",if(gray)"sgray_8" else "srgb_8")){"PWG-Farbraum nicht unterstützt"}
                check(caps.has("sides-supported","one-sided")){"Einseitiger Druck nicht unterstützt"}
                check(caps.has("print-scaling-supported","none")){"print-scaling=none nicht unterstützt"}
                val colorName=if(gray)"monochrome" else "color"
                if(caps.has("print-color-mode-supported",colorName))jobAttrs+=Ipp.a(0x44,"print-color-mode",colorName)
                if(caps.has("print-quality-supported",4))jobAttrs+=Ipp.a(0x23,"print-quality",4)
                if(caps.has("operations-supported",4)){
                    val validation=exchange(device,4,op,jobAttrs)
                    check(validation.status==0){"Druckparameter abgewiesen: ${validation.attrs()}"}
                }
                diagnostic("IPP parameters validated; ${device.host}:${device.port}${device.path}; secure=${device.secure}")
                diagnostic("Starting IPP Print-Job transfer")
                val response=exchange(device,2,op,jobAttrs,spool)
                diagnostic("IPP Print-Job accepted, status=${response.status}")
                val printerJobId=response.integer("job-id",0)
                if(printerJobId<=0){
                    // Some Epson firmwares accept Print-Job but omit a job-id.
                    // IPP success is an accepted transfer, not proof of physical output.
                    diagnostic("IPP accepted without job-id; completing Android transfer")
                    diagnostic("Android job.complete() called (no IPP job-id)")
                    finish(job,"complete")
                }else{
                    var terminal=false
                    var pollFailed=false
                    for(attempt in 0 until 30){
                        if(cancelled.get()){terminal=true;break}
                        val r=try {exchange(device,9,listOf(Ipp.a(0x21,"job-id",printerJobId),Ipp.a(0x42,"requesting-user-name","Nova-Print")))}
                            catch(t:Throwable){diagnostic("IPP job status unavailable",t);pollFailed=true;break}
                        when(r.integer("job-state",0)){
                            9->{diagnostic("Printer reports completed; Android complete");finish(job,"complete");terminal=true}
                            7->{finish(job,"cancel");terminal=true}
                            8->{finish(job,"fail","Drucker meldet einen Fehler");terminal=true}
                        }
                        if(terminal)break
                        Thread.sleep(2000)
                    }
                    if(!terminal){
                        // The raster has been accepted by IPP; never leave an Android job
                        // indefinitely queued just because Epson does not expose status.
                        diagnostic(if(pollFailed)"IPP accepted; status polling unsupported" else "IPP accepted; polling timed out")
                        diagnostic("Android job.complete() after IPP status check")
                        finish(job,"complete")
                    }
                }
            }catch(e:InterruptedException){try{finish(job,"cancel")}catch(_:Throwable){}}
            catch(t:Throwable){
                diagnostic("Android print pipeline",t)
                try {if(!cancelled.get())finish(job,"fail","Nova-Print: ${t.javaClass.simpleName}: ${t.message}")}
                catch(reportError:Throwable){diagnostic("Reporting print failure",reportError)}
            }
            finally{
                cancellations.remove(key)
                try{document.close()}catch(_:Throwable){}
                try{spool?.delete()}catch(_:Throwable){}
                try{localPdf?.delete()}catch(_:Throwable){}
            }
        }
    }
    private fun fingerprint(cert:java.security.cert.X509Certificate):String =
        java.security.MessageDigest.getInstance("SHA-256").digest(cert.encoded)
            .joinToString(":") { "%02X".format(it.toInt() and 255) }

    private fun pinnedFactory(expected:String):javax.net.ssl.SSLSocketFactory {
        val trust=object:javax.net.ssl.X509TrustManager {
            override fun getAcceptedIssuers():Array<java.security.cert.X509Certificate> = emptyArray()
            override fun checkClientTrusted(chain:Array<java.security.cert.X509Certificate>,authType:String) {
                throw java.security.cert.CertificateException("Client certificates not supported")
            }
            override fun checkServerTrusted(chain:Array<java.security.cert.X509Certificate>,authType:String) {
                if(chain.isEmpty() || fingerprint(chain[0])!=expected)
                    throw java.security.cert.CertificateException("Druckerzertifikat geändert. Bitte in Nova-Print neu bestätigen.")
            }
        }
        return javax.net.ssl.SSLContext.getInstance("TLS").apply {
            init(null,arrayOf<javax.net.ssl.TrustManager>(trust),java.security.SecureRandom())
        }.socketFactory
    }

    private fun exchange(d:Device,operation:Int,op:List<Ipp.Attr> = emptyList(),attrs:List<Ipp.Attr> = emptyList(),file:File?=null):Ipp.Response {
        // Same transport and pinned certificate as the proven in-app direct-print path.
        val scheme=if(d.secure)"ipps" else "ipp"
        val uri="$scheme://${d.host}:${d.port}/${d.path.trimStart('/')}"
        val id=ids.incrementAndGet()
        val header=Ipp.request(operation,id,uri,op,attrs)
        val conn=URL("${if(d.secure)"https" else "http"}://${d.host}:${d.port}/${d.path.trimStart('/')}").openConnection() as HttpURLConnection
        if(conn is javax.net.ssl.HttpsURLConnection && d.fingerprint.isNotBlank()){
            conn.sslSocketFactory=pinnedFactory(d.fingerprint)
            conn.hostnameVerifier=javax.net.ssl.HostnameVerifier {host,_->host==d.host}
        }
        conn.instanceFollowRedirects=false
        conn.requestMethod="POST";conn.doOutput=true
        conn.connectTimeout=7000;conn.readTimeout=60000
        conn.setRequestProperty("Content-Type","application/ipp")
        conn.setFixedLengthStreamingMode(header.size.toLong()+(file?.length() ?: 0L))
        try {
            conn.outputStream.buffered().use {out->out.write(header);file?.inputStream()?.use {it.copyTo(out)}}
            val code=conn.responseCode
            if(code !in 200..299){
                val detail=try{conn.errorStream?.bufferedReader()?.use{it.readText().take(350)}}catch(_:Throwable){null}
                diagnostic("IPP operation $operation HTTP $code; endpoint=$uri; response=${detail ?: "(empty)"}")
                throw java.io.IOException("IPP HTTP $code; ${detail?.take(90) ?: "keine Fehlerdetails"}")
            }
            val response=Ipp.parse(conn.inputStream.use {it.readBytes()})
            check(response.id==id){"IPP Request-ID stimmt nicht überein"}
            diagnostic("IPP operation $operation: status=0x${response.status.toString(16)} ${response.text("status-message")}")
            response.requireSuccess()
            return response
        }finally{conn.disconnect()}
    }
}
