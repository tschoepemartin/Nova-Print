# Nova-Print 0.1.3

Neue Druckerverwaltung: IPP/AirPrint-Suche über Android NSD, Drucker mit Modellname und Bild anzeigen, per IPP-Funktionsabfrage verbinden, mehrere Drucker speichern und Standarddrucker wählen. Manuelle Einrichtung als Fallback.

App-Icon: das generierte blaue Nova-Print-Druckerbild.

Hinweis: Ein echter IPP-Druck muss mit dem WF-7830DTWF getestet werden. Keine Garantie für 100 % physische Maßhaltigkeit oder Unterstützung von PDF-Direktdruck. Die App sendet PDF-Bytes unverändert.
