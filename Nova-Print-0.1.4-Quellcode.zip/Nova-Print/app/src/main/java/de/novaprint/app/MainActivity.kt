package de.novaprint.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.view.View
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.widget.LinearLayout.LayoutParams
import org.json.JSONArray
import org.json.JSONObject
import java.net.InetAddress
import android.widget.*
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var status: TextView
    private data class Printer(val name: String, val ip: String, val port: Int, val path: String)
    private val printers = mutableListOf<Printer>()
    private val candidates = mutableListOf<Printer>()
    private var active: Printer? = null
    private lateinit var printerList: LinearLayout
    private lateinit var scanList: LinearLayout
    private lateinit var nsd: NsdManager
    private val listeners = mutableListOf<NsdManager.DiscoveryListener>()
    private var currentScreen: LinearLayout? = null
    private lateinit var paper: Spinner
    private lateinit var quality: Spinner
    private lateinit var color: Spinner
    private lateinit var duplex: Spinner
    private lateinit var source: Spinner
    private lateinit var copies: EditText
    private var document: Uri? = null
    private var pdfWidth = 0f
    private var pdfHeight = 0f
    private var supportedPdf = false
    private var discovered = ""

    private fun title(value: String, size: Float = 18f): TextView = TextView(this).apply {
        text = value; textSize = size; setTextColor(Color.rgb(24, 39, 58)); setPadding(0, 12, 0, 12)
    }
    private fun button(value: String, click: () -> Unit): Button = Button(this).apply {
        text = value; setAllCaps(false); setOnClickListener { click() }
    }
    private fun container(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; setPadding(24, 22, 24, 30)
    }
    private fun show(content: LinearLayout) {
        currentScreen = content
        setContentView(ScrollView(this).apply { isFillViewport = true; addView(content) })
    }
    private fun loadPrinters() {
        val saved = getSharedPreferences("printers", MODE_PRIVATE)
        val arr = JSONArray(saved.getString("items", "[]"))
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            printers.add(Printer(o.optString("name"), o.optString("ip"), o.optInt("port", 631), o.optString("path", "/ipp/print")))
        }
        val idx = saved.getInt("active", 0)
        active = printers.getOrNull(idx)
    }
    private fun savePrinters() {
        val arr = JSONArray()
        printers.forEach { arr.put(JSONObject().put("name", it.name).put("ip", it.ip).put("port", it.port).put("path", it.path)) }
        getSharedPreferences("printers", MODE_PRIVATE).edit().putString("items", arr.toString())
            .putInt("active", printers.indexOf(active).coerceAtLeast(0)).apply()
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        nsd = getSystemService(Context.NSD_SERVICE) as NsdManager
        loadPrinters()
        home()
        accept(intent)
    }
    private fun home() {
        val root = container()
        root.addView(title("Nova-Print", 30f))
        root.addView(title("Meine Drucker", 20f))
        root.addView(button("+ Drucker hinzufügen") { discoverScreen() })
        printerList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(printerList)
        drawSaved()
        root.addView(title("PDF drucken", 20f))
        root.addView(button("PDF auswählen") {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                type = "application/pdf"; addCategory(Intent.CATEGORY_OPENABLE)
            }, 10)
        })
        fun spin(label: String, entries: List<String>): Spinner {
            root.addView(title(label, 14f))
            return Spinner(this).apply {
                adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, entries)
                root.addView(this)
            }
        }
        paper = spin("Papierformat", listOf("Automatisch", "A4", "A3"))
        quality = spin("Qualität", listOf("Normal", "Entwurf", "Hoch"))
        color = spin("Farbe", listOf("Farbe", "Schwarzweiß"))
        duplex = spin("Duplex", listOf("Einseitig", "Lange Kante", "Kurze Kante"))
        source = spin("Papierzufuhr", listOf("Automatisch", "Kassette 1", "Kassette 2", "Hinterer Einzug"))
        root.addView(title("Exemplare", 14f))
        copies = EditText(this).apply { setText("1"); inputType = 2; root.addView(this) }
        root.addView(button("Druckerfunktionen abfragen") { probe() })
        root.addView(button("PDF 100 % drucken") { printPdf() })
        status = title("Bitte PDF auswählen und Drucker verbinden.", 14f).apply { setTextIsSelectable(true) }
        root.addView(status)
        show(root)
    }
    private fun drawSaved() {
        printerList.removeAllViews()
        if (printers.isEmpty()) printerList.addView(title("Noch kein Drucker eingerichtet.", 14f))
        printers.forEach { p ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(6, 14, 6, 14) }
            row.addView(ImageView(this).apply {
                setImageResource(R.drawable.printer_device)
                layoutParams = LayoutParams(100, 100)
                scaleType = ImageView.ScaleType.FIT_CENTER
            })
            val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            info.addView(title(p.name + if (p == active) "  ✓" else "", 16f))
            info.addView(title("${p.ip}:${p.port} · ${p.path}", 12f))
            row.addView(info, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
            row.setOnClickListener { active = p; savePrinters(); home() }
            row.setOnLongClickListener { printerDetails(p); true }
            printerList.addView(row)
        }
    }
    private fun printerDetails(p: Printer) {
        val root = container()
        root.addView(button("← Zurück") { home() })
        root.addView(ImageView(this).apply { setImageResource(R.drawable.printer_device); layoutParams = LayoutParams(-1, 210) })
        root.addView(title(p.name, 22f))
        root.addView(title("${p.ip}:${p.port}${p.path}", 14f))
        root.addView(button("Als Standarddrucker verwenden") { active = p; savePrinters(); home() })
        root.addView(button("Drucker entfernen") { printers.remove(p); if (active == p) active = printers.firstOrNull(); savePrinters(); home() })
        show(root)
    }
    private fun discoverScreen() {
        val root = container()
        root.addView(button("← Zurück") { stopDiscovery(); home() })
        root.addView(title("Drucker hinzufügen", 24f))
        root.addView(title("Drucker im gleichen WLAN suchen (IPP / AirPrint)", 14f))
        scanList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(scanList)
        root.addView(button("Erneut suchen") { startDiscovery() })
        root.addView(button("Manuell hinzufügen") { stopDiscovery(); manualScreen() })
        show(root)
        startDiscovery()
    }
    private fun startDiscovery() {
        stopDiscovery(); candidates.clear(); scanList.removeAllViews()
        scanList.addView(title("Suche läuft …", 14f))
        listOf("_ipp._tcp.", "_ipps._tcp.").forEach { serviceType ->
            val listener = object : NsdManager.DiscoveryListener {
                override fun onDiscoveryStarted(regType: String) {}
                override fun onStartDiscoveryFailed(type: String, errorCode: Int) { runOnUiThread { scanList.addView(title("Suche nicht verfügbar: $errorCode", 14f)) } }
                override fun onStopDiscoveryFailed(type: String, errorCode: Int) {}
                override fun onDiscoveryStopped(type: String) {}
                override fun onServiceLost(service: NsdServiceInfo) {}
                override fun onServiceFound(service: NsdServiceInfo) {
                    try {
                        @Suppress("DEPRECATION")
                        nsd.resolveService(service, object : NsdManager.ResolveListener {
                            override fun onResolveFailed(info: NsdServiceInfo, code: Int) {}
                            override fun onServiceResolved(info: NsdServiceInfo) {
                                val ip = info.host?.hostAddress ?: return
                                val txt = info.attributes
                                val rp = txt["rp"]?.toString(Charsets.UTF_8)?.trim('/') ?: "ipp/print"
                                val model = txt["ty"]?.toString(Charsets.UTF_8)?.takeIf { it.isNotBlank() } ?: info.serviceName
                                val printer = Printer(model, ip, info.port, "/$rp")
                                runOnUiThread {
                                    if (candidates.none { it.ip == printer.ip && it.path == printer.path }) {
                                        candidates.add(printer); drawCandidates()
                                    }
                                }
                            }
                        })
                    } catch (_: Exception) { }
                }
            }
            listeners.add(listener)
            try { nsd.discoverServices(serviceType, NsdManager.PROTOCOL_DNS_SD, listener) }
            catch (e: Exception) { scanList.addView(title("Netzwerksuche: ${e.message}", 14f)) }
        }
    }
    private fun drawCandidates() {
        scanList.removeAllViews()
        candidates.forEach { p ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(ImageView(this).apply { setImageResource(R.drawable.printer_device); layoutParams = LayoutParams(95, 95) })
            val text = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            text.addView(title(p.name, 16f)); text.addView(title(p.ip, 13f))
            row.addView(text, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
            row.addView(button("Hinzufügen") { verifyPrinter(p) })
            scanList.addView(row)
        }
    }
    private fun verifyPrinter(p: Printer) {
        scanList.addView(title("Prüfe ${p.name} …", 14f))
        thread {
            try {
                val reply = ippRequest(0x000B, null, emptyList(), p)
                val code = ((reply[2].toInt() and 255) shl 8) or (reply[3].toInt() and 255)
                if (code >= 0x0100) throw IllegalStateException("IPP-Status 0x${code.toString(16)}")
                runOnUiThread {
                    if (printers.none { it.ip == p.ip && it.path == p.path }) printers.add(p)
                    active = p; savePrinters(); stopDiscovery(); home()
                }
            } catch (e: Exception) { runOnUiThread { scanList.addView(title("Verbindung fehlgeschlagen: ${e.message}", 14f)) } }
        }
    }
    private fun manualScreen() {
        val root = container()
        root.addView(button("← Zurück") { discoverScreen() })
        root.addView(title("Drucker manuell hinzufügen", 22f))
        fun edit(label: String, value: String): EditText {
            root.addView(title(label, 14f))
            return EditText(this).apply { setText(value); root.addView(this) }
        }
        val name = edit("Name", "Epson WorkForce WF-7830DTWF")
        val ip = edit("IP-Adresse", "192.168.178.50")
        val port = edit("IPP-Port", "631")
        val path = edit("IPP-Pfad", "/ipp/print")
        val message = title("", 14f)
        root.addView(button("Verbindung prüfen und hinzufügen") {
            val p = Printer(name.text.toString().trim(), ip.text.toString().trim(), port.text.toString().toIntOrNull() ?: 631, path.text.toString().trim())
            message.text = "Verbindung wird geprüft …"
            thread {
                try {
                    val response = ippRequest(0x000B, null, emptyList(), p)
                    val code = ((response[2].toInt() and 255) shl 8) or (response[3].toInt() and 255)
                    if (code >= 0x0100) throw IllegalStateException("IPP-Status 0x${code.toString(16)}")
                    runOnUiThread { printers.add(p); active = p; savePrinters(); home() }
                } catch (e: Exception) { runOnUiThread { message.text = "Verbindung fehlgeschlagen: ${e.message}" } }
            }
        })
        root.addView(message)
        show(root)
    }
    private fun stopDiscovery() {
        listeners.forEach { try { nsd.stopServiceDiscovery(it) } catch (_: Exception) {} }
        listeners.clear()
    }
    override fun onDestroy() { stopDiscovery(); super.onDestroy() }

    @Deprecated("Legacy picker callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 10 && resultCode == RESULT_OK) data?.data?.let { setDocument(it) }
    }
    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); accept(intent) }
    private fun accept(i: Intent?) {
        val uri = when (i?.action) {
            Intent.ACTION_SEND -> if (android.os.Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java) else @Suppress("DEPRECATION") i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
            Intent.ACTION_VIEW -> i.data
            else -> null
        }
        if (uri != null) setDocument(uri)
    }
    private fun setDocument(uri: Uri) {
        document = uri
        try {
            contentResolver.openFileDescriptor(uri, "r")!!.use { fd ->
                PdfRenderer(fd).use { renderer ->
                    val p = renderer.openPage(0)
                    pdfWidth = p.width.toFloat(); pdfHeight = p.height.toFloat(); p.close()
                    update("PDF geladen: ${renderer.pageCount} Seite(n), erste Seite ca. ${pdfWidth} × ${pdfHeight} pt. Originaldatei bleibt unverändert.")
                }
            }
        } catch (e: Exception) { update("PDF-Metadaten konnten nicht gelesen werden: ${e.message}") }
    }
    private fun update(msg: String) { runOnUiThread { status.text = msg } }
    private fun endpoint(p: Printer): String = "http://${p.ip}:${p.port}${p.path.let { if (it.startsWith('/')) it else "/$it" }}"
    private fun probe() {
        val printer = active ?: return update("Bitte zuerst einen Drucker hinzufügen.")
        update("Frage IPP-Funktionen ab …")
        thread {
            try {
                val response = ippRequest(0x000B, null, emptyList(), printer)
                val parsed = parseAttributes(response)
                discovered = parsed
                supportedPdf = parsed.contains("application/pdf", true)
                update("IPP-Antwort:\n$parsed\n\nPDF-Direktdruck: ${if (supportedPdf) "vom Drucker gemeldet" else "NICHT bestätigt"}.\nPapierformat/-quelle werden nur angezeigt, wenn IPP sie liefert.")
            } catch (e: Exception) { supportedPdf = false; update("IPP-Abfrage fehlgeschlagen: ${e.message}\nPrüfe IP-Adresse, IPP-Pfad und WLAN.") }
        }
    }
    private fun printPdf() {
        val printer = active ?: return update("Bitte zuerst einen Drucker hinzufügen.")
        val uri = document ?: return update("Bitte zuerst ein PDF auswählen.")
        if (!supportedPdf) return update("Druck gestoppt: Direkter PDF-Druck über IPP wurde noch nicht bestätigt. Erst Druckerfunktionen abfragen. Keine automatische Verkleinerung als Ersatz.")
        update("Übertrage PDF unverändert per IPP …")
        val selectedPaper = paper.selectedItemPosition
        val selectedQuality = quality.selectedItemPosition
        val selectedColor = color.selectedItemPosition
        val selectedDuplex = duplex.selectedItemPosition
        val selectedSource = source.selectedItemPosition
        val n = copies.text.toString().toIntOrNull()?.coerceIn(1, 99) ?: 1
        thread {
            try {
                val bytes = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                if (bytes.size < 5 || String(bytes.copyOfRange(0, 5)) != "%PDF-") throw IllegalArgumentException("Keine gültige PDF-Datei")
                val attrs = mutableListOf<Triple<Int, String, Any>>()
                attrs += Triple(0x49, "document-format", "application/pdf")
                attrs += Triple(0x44, "print-color-mode", if (selectedColor == 0) "color" else "monochrome")
                attrs += Triple(0x44, "sides", when (selectedDuplex) { 1 -> "two-sided-long-edge"; 2 -> "two-sided-short-edge"; else -> "one-sided" })
                attrs += Triple(0x23, "print-quality", when (selectedQuality) { 1 -> 3; 2 -> 5; else -> 4 })
                attrs += Triple(0x21, "copies", n)
                val media = when (selectedPaper) { 1 -> "iso_a4_210x297mm"; 2 -> "iso_a3_297x420mm"; else -> if (pdfWidth > 650 || pdfHeight > 900) "iso_a3_297x420mm" else "iso_a4_210x297mm" }
                attrs += Triple(0x44, "media", media)
                if (selectedSource != 0) attrs += Triple(0x44, "media-source", when (selectedSource) { 1 -> "tray-1"; 2 -> "tray-2"; else -> "manual" })
                val response = ippRequest(0x0002, bytes, attrs, printer)
                val code = ((response[2].toInt() and 255) shl 8) or (response[3].toInt() and 255)
                update(if (code < 0x0100) "Druckauftrag vom Drucker angenommen (IPP 0x${code.toString(16)}). PDF wurde unverändert übertragen. Maßhaltigkeit bitte am vorhandenen Plan prüfen." else "Drucker hat Auftrag abgelehnt: IPP 0x${code.toString(16)}\n${parseAttributes(response)}")
            } catch (e: Exception) { update("Druck fehlgeschlagen: ${e.message}") }
        }
    }
    private fun ippRequest(operation: Int, pdf: ByteArray?, jobAttrs: List<Triple<Int, String, Any>>, printer: Printer): ByteArray {
        val out = ByteArrayOutputStream()
        fun byte(v: Int) { out.write(v and 255) }
        fun short(v: Int) { byte(v shr 8); byte(v) }
        fun integer(v: Int) { byte(v shr 24); byte(v shr 16); byte(v shr 8); byte(v) }
        fun attr(tag: Int, name: String, value: Any) {
            val key = name.toByteArray(Charsets.UTF_8)
            val data = if (value is Int) ByteBuffer.allocate(4).order(ByteOrder.BIG_ENDIAN).putInt(value).array() else value.toString().toByteArray(Charsets.UTF_8)
            byte(tag); short(key.size); out.write(key); short(data.size); out.write(data)
        }
        short(0x0200); short(operation); integer(1)
        byte(0x01)
        attr(0x47, "attributes-charset", "utf-8")
        attr(0x48, "attributes-natural-language", "en")
        attr(0x45, "printer-uri", "ipp://${printer.ip}:${printer.port}${printer.path.let { if (it.startsWith('/')) it else "/$it" }}")
        if (operation == 0x000B) attr(0x44, "requested-attributes", "all")
        if (operation == 0x0002) { attr(0x42, "requesting-user-name", "Nova-Print"); attr(0x42, "job-name", "Nova-Print PDF"); byte(0x02); jobAttrs.forEach { (t, n, v) -> attr(t, n, v) } }
        byte(0x03)
        if (pdf != null) out.write(pdf)
        val conn = URL(endpoint(printer)).openConnection() as HttpURLConnection
        conn.requestMethod = "POST"; conn.connectTimeout = 6000; conn.readTimeout = 30000
        conn.setRequestProperty("Content-Type", "application/ipp")
        conn.doOutput = true
        conn.outputStream.use { it.write(out.toByteArray()) }
        val result = (if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream).use { it.readBytes() }
        conn.disconnect()
        if (result.size < 8 || result[0].toInt() != 2 && result[0].toInt() != 1)
            throw IllegalStateException("Ungültige IPP-Antwort (HTTP ${conn.responseCode}, ${result.size} Bytes). Prüfe den erkannten IPP-Pfad.")
        return result
    }
    private fun parseAttributes(bytes: ByteArray): String {
        val sb = StringBuilder(); var i = 8; var name = ""; var count = 0
        while (i < bytes.size && count < 350) {
            val tag = bytes[i++].toInt() and 255
            if (tag == 3) break
            if (tag <= 0x0f) continue
            if (i + 4 > bytes.size) break
            val nl = ((bytes[i].toInt() and 255) shl 8) or (bytes[i+1].toInt() and 255); i += 2
            if (i + nl + 2 > bytes.size) break
            if (nl > 0) name = String(bytes, i, nl, Charsets.UTF_8)
            i += nl
            val vl = ((bytes[i].toInt() and 255) shl 8) or (bytes[i+1].toInt() and 255); i += 2
            if (i + vl > bytes.size) break
            val v = if (tag == 0x21 || tag == 0x23) { if (vl == 4) ByteBuffer.wrap(bytes, i, 4).order(ByteOrder.BIG_ENDIAN).int.toString() else "(Zahl)" } else String(bytes, i, vl, Charsets.UTF_8).filter { it >= ' ' }.take(160)
            i += vl; count++
            if (name.contains("document-format") || name.contains("media") || name.contains("tray") || name.contains("supply") || name.contains("printer-state") || name.contains("print-quality") || name.contains("color") || name.contains("sides") || name.contains("resolution")) sb.append(name).append(": ").append(v).append('\n')
        }
        return if (sb.isEmpty()) "Keine auswertbaren relevanten Attribute erhalten." else sb.toString().take(14000)
    }
}
